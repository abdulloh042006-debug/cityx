# CityX — Phase 0.4.2 Frontend Build & Verification Audit (`FINAL_AUDIT.md`)

**Release:** `cityx-phase042-delivery.zip` (incremental update from `cityx-phase041-delivery.zip`; project was NOT rebuilt from scratch)
**Container Runtime:** Python 3.10.16 + stdlib `sqlite3`. No `node`, `npm`, `pnpm`, `tsc`, `psql`, `docker`, `fastapi`, `httpx`, or `pytest` installed in this container, and no external network egress is available.

---

## 1. Phase 0.4.2 Frontend Form Audit & Hardening (All 7 Required Forms)

Every required form was audited line-by-line and hardened without removing existing features or introducing fake success states:

| # | Form & File | Issues Discovered in Phase 0.4.1 | Fixes Applied in Phase 0.4.2 |
| :- | :--- | :--- | :--- |
| 1 | **Registration & Login** (`apps/web/src/pages/AuthPage.tsx`) | No client-side regex/length validation on trimmed username (`3–24`) or password (`>=8`); no loading text on submit buttons; switching tabs left password fields populated. | Added client-side validation (`^[a-zA-Z0-9._]{3,24}$`, password `>=8`), per-action `busyAction` loading labels, `role="alert"`/`role="status"` banners, `htmlFor`/`id` accessibility labels, and password reset on tab switch. |
| 2 | **Password Recovery** (`apps/web/src/pages/AuthPage.tsx`) | No client-side check for recovery identifier (`>=3`) or token length (`>=16`); no loading text during request/confirm. | Added strict validation, per-action loading states, and preserved honest backend `delivery_notice` (never pretends email was sent when `SMTP_HOST` is unset). |
| 3 | **User Profile & Home Editor** (`apps/web/src/pages/ProfilePage.tsx`) | **Critical UX bug:** save errors set top-level `error` which unmounted the entire form (`if (error) return <ErrorBox />`); missing `savingProfile`/`savingHome` loading & `disabled` states (double-click race). | Split `loadError` vs inline `formError` so validation/save errors never unmount the form; added `savingProfile` and `savingHome` disabled/loading states, background reload without wiping status banners, and `displayName` (2–48) / `bio` (<=240) validation. |
| 4 | **Payment Selection (Separate Visa & Uzcard)** (`apps/web/src/pages/PaymentsPage.tsx`) | Generated a brand-new `Date.now()` idempotency key on every click (risking duplicate pending orders on retry); could not resume an existing `pending` order after page reload. | Added stable per-attempt `pendingIdemKeyRef` (reset on method/package change or success), `aria-pressed` state on both independent card buttons (`uzum_visa` / `Abdullox Arslonov` / `****8421` and `uzcard` / `Arslonov Abdulloh` / `****8244`), and a **Resume (`Davom ettirish`)** action on `pending` orders in order history. |
| 5 | **Payment Receipt & Reference Submission** (`apps/web/src/pages/PaymentsPage.tsx`) | Missing client-side 5 MB size & MIME type check (`PNG/JPEG/WebP/PDF`); file `<input>` not cleared after upload; missing client-side URL/script rejection on `txRef`. | Added 5 MB & MIME pre-validation, `fileInputRef` reset after upload/rejection, client-side `UNSAFE_REF_RE` (`http(s)://`, `javascript:`, `data:`, `file://`) guard, and per-action `busyAction` loading labels. |
| 6 | **Event Registration & Elections** (`apps/web/src/pages/PlacesPage.tsx`) | Missing `busyKey` loading/disabled states on RSVP and Vote buttons (double-click race); missing `setError(null)` before actions; guests saw no login cue on events. | Added `busyKey` per-event/per-election loading & disabled states, cleared stale errors before each request, preserved success banner during background refresh, and added a guest sign-in link on event cards. |
| 7 | **Admin Payment Approval & Rejection** (`apps/web/src/pages/AdminPage.tsx`) | Missing `busyAction` disabled/loading states on Approve/Reject buttons (double-click could trigger 409 flash over success); `load()` unmounted the page and hid the success banner; reject reason wasn't cleared after rejection. | Added per-order `busyAction` locking all row buttons during submission, converted rejection row to a validated `<form>`, cleared `rejectReasons[orderId]` on success, and used background `load(false)` so the approval/rejection confirmation banner stays visible. |

---

## 2. Preserved Security & Phase 0.4.1 Guarantees

- **Two separate manual payment methods preserved:**
  - **Uzum Bank — Visa** (`uzum_visa`), recipient **Abdullox Arslonov**, masked card ending `8421`.
  - **Uzcard** (`uzcard`), recipient **Arslonov Abdulloh**, masked card ending `8244`, issuing bank remains `null` until verified.
- **Zero full card numbers exposed:** Full card numbers remain server-side environment variables only; 0 occurrences in frontend code, API responses, docs, logs, or ZIP archive.
- **Manual admin verification only:** Zero automated payment providers (Click, Payme, Uzum webhooks, Telegram Stars, TON), zero OCR approval, and zero bank scraping.
- **All Phase 0.4.1 fixes preserved:** Portable PostgreSQL `= TRUE` comparisons, `vite-env.d.ts`, strict `TranslationTree` interface, `vitest/config` import, all 12 `/app/*` Telegram Mini App deep-link routes, Three.js GPU disposal, WebGL context loss/restoration, stabilized `onSelectLandmarkRef`, and two-finger touch pinch zoom & pan.

---

## 3. Honest Readiness Verdict

**NOT PRODUCTION READY — FRONTEND BUILD & INTEGRATION CHECKS REMAIN BLOCKED IN THIS CONTAINER.**
All 22 Python regression tests and all static frontend/security/API-contract checks **PASS**, and `apps/web/src/__tests__/app.test.tsx` was expanded to test the hardened forms. However, because `node`, `npm`, `tsc`, `vitest`, `vite`, `pytest`, `fastapi`, `psql`, and `docker` are not installed in this sandbox, those runtime suites are strictly marked **BLOCKED (NOT RUN)** and must be executed in a Node.js 20+ / Python / PostgreSQL environment before deployment.
