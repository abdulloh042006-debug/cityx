from __future__ import annotations

import hmac
from typing import Any, Dict, Optional

from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from apps.api.auth.tokens import AuthSecurity
from apps.api.config import AppConfig
from apps.api.db.store import CityXStore
from apps.api.domain.services import CityXDomainService, DomainError
from apps.api.payments.receipts import MAX_RECEIPT_BYTES
from apps.api.telegram.adapter import TelegramBotAdapter


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class MiniAppAuthRequest(StrictModel):
    initData: str = Field(..., min_length=1, max_length=16384)


class LocalRegisterRequest(StrictModel):
    username: str = Field(..., min_length=3, max_length=24)
    password: str = Field(..., min_length=8, max_length=128)
    instagram_handle: str = Field(default="", max_length=64)
    district_id: str = Field(default="residential", max_length=32)


class LocalLoginRequest(StrictModel):
    username: str = Field(..., min_length=3, max_length=24)
    password: str = Field(..., min_length=1, max_length=128)


class RecoveryRequestBody(StrictModel):
    identifier: str = Field(..., min_length=3, max_length=128)


class RecoveryConfirmBody(StrictModel):
    token: str = Field(..., min_length=16, max_length=128)
    new_password: str = Field(..., min_length=8, max_length=128)


class ProfileUpdateRequest(StrictModel):
    display_name: Optional[str] = Field(default=None, min_length=2, max_length=48)
    bio: Optional[str] = Field(default=None, max_length=240)
    instagram_handle: Optional[str] = Field(default=None, max_length=32)
    avatar_url: Optional[str] = Field(default=None, max_length=300)
    district_id: Optional[str] = Field(default=None, max_length=32)


class SettingsUpdateRequest(StrictModel):
    language: Optional[str] = Field(default=None, pattern="^(uz|ru|en)$")
    classic_mode: Optional[bool] = None
    notify_prefs: Optional[Dict[str, bool]] = None


class CreatePaymentOrderRequest(StrictModel):
    package_id: str = Field(..., min_length=1, max_length=64)
    payment_method_code: str = Field(..., pattern="^(uzum_visa|uzcard)$")
    idempotency_key: str = Field(..., min_length=4, max_length=200)


class SubmitPaymentProofRequest(StrictModel):
    submitted_reference: str = Field(..., min_length=3, max_length=128)


class RejectPaymentRequest(StrictModel):
    rejection_reason: str = Field(..., min_length=3, max_length=300)


class BanUserRequest(StrictModel):
    reason: str = Field(..., min_length=3, max_length=300)


class TaxiRequest(StrictModel):
    destination_district_id: str = Field(..., min_length=2, max_length=32)
    request_id: str = Field(..., min_length=4, max_length=128)


class VoteRequest(StrictModel):
    candidate_id: str = Field(..., min_length=1, max_length=64)


class UpdateHomeRequest(StrictModel):
    floors: int = Field(..., ge=1, le=50)
    has_pool: bool = False
    has_helipad: bool = False


class AcquireObjectRequest(StrictModel):
    expected_version: int = Field(..., ge=1)


class FriendRequestBody(StrictModel):
    target_username: str = Field(..., min_length=3, max_length=32)


class EventRsvpBody(StrictModel):
    join: bool = True


def create_app(config: Optional[AppConfig] = None, store: Optional[CityXStore] = None) -> FastAPI:
    cfg = config or AppConfig.from_env()
    db_store = store or CityXStore(database_url=cfg.database_url, sqlite_path=cfg.sqlite_path or ":memory:")
    security = AuthSecurity(bot_token=cfg.bot_token, signing_secret=cfg.signing_secret)
    domain = CityXDomainService(config=cfg, store=db_store)
    telegram_adapter = TelegramBotAdapter(config=cfg, domain=domain, security=security)

    app = FastAPI(title="CityX Unified API", version="0.4.0")
    app.state.config = cfg
    app.state.store = db_store
    app.state.domain = domain
    app.state.security = security
    app.state.telegram = telegram_adapter

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(cfg.cors_origins),
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @app.exception_handler(DomainError)
    async def domain_error_handler(_: Request, exc: DomainError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content={"ok": False, "error": str(exc)})

    def _decode_auth_context(authorization: str) -> tuple[Dict[str, Any], Dict[str, Any]]:
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Missing bearer token.")
        token = authorization[7:].strip()
        try:
            claims = security.verify_jwt(token)
        except ValueError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        user = domain.get_active_user_for_token(claims["sub"], claims["jti"])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired, revoked, or banned.")
        return user, claims

    def require_user(authorization: str = Header(default="")) -> Dict[str, Any]:
        user, _ = _decode_auth_context(authorization)
        return user

    def require_user_with_claims(authorization: str = Header(default="")) -> tuple[Dict[str, Any], Dict[str, Any]]:
        return _decode_auth_context(authorization)

    def optional_user(authorization: str = Header(default="")) -> Optional[Dict[str, Any]]:
        if not authorization.startswith("Bearer "):
            return None
        try:
            user, _ = _decode_auth_context(authorization)
            return user
        except HTTPException:
            return None

    def require_admin(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        if user.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Administrator access required.")
        return user

    @app.get("/health")
    @app.get("/__health")
    def health() -> Dict[str, Any]:
        return {
            "status": "ok",
            "version": "0.4.0",
            "environment": cfg.environment,
            "database_backend": db_store.backend,
            "payment_mode": "manual_bank_transfer_only",
            "active_payment_methods": [c.code for c in cfg.active_manual_cards()],
            "ton_wallet_enabled": False,
        }

    @app.get("/api/city/overview")
    def city_overview() -> Dict[str, Any]:
        return {"ok": True, "overview": domain.get_public_overview()}

    @app.post("/api/miniapp/auth")
    def miniapp_auth(body: MiniAppAuthRequest) -> Dict[str, Any]:
        try:
            tg_user = security.verify_miniapp_init_data(body.initData, max_age_seconds=300)
        except ValueError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        user, is_new = domain.get_or_create_telegram_user(tg_user)
        access_token, jti, exp = security.issue_jwt(user["id"], user["role"], ttl_seconds=3600)
        domain.create_session(user["id"], jti, exp)
        return {"ok": True, "isNew": is_new, "accessToken": access_token, "expiresAt": exp, "user": user}

    @app.post("/api/auth/register", status_code=201)
    def register_local(body: LocalRegisterRequest) -> Dict[str, Any]:
        res = domain.register_local_user(
            username=body.username,
            password=body.password,
            instagram_handle=body.instagram_handle,
            district_id=body.district_id,
        )
        u = res["user"]
        access_token, jti, exp = security.issue_jwt(u["id"], u["role"], ttl_seconds=3600)
        domain.create_session(u["id"], jti, exp)
        return {"ok": True, "accessToken": access_token, "expiresAt": exp, **res}

    @app.post("/api/auth/login")
    def login_local(body: LocalLoginRequest) -> Dict[str, Any]:
        u = domain.authenticate_local_user(body.username, body.password)
        access_token, jti, exp = security.issue_jwt(u["id"], u["role"], ttl_seconds=3600)
        domain.create_session(u["id"], jti, exp)
        return {"ok": True, "accessToken": access_token, "expiresAt": exp, "user": u}

    @app.post("/api/auth/logout")
    def logout_session(ctx: tuple[Dict[str, Any], Dict[str, Any]] = Depends(require_user_with_claims)) -> Dict[str, Any]:
        user, claims = ctx
        domain.revoke_session(user["id"], claims["jti"])
        return {"ok": True, "revoked": True}

    @app.post("/api/auth/recovery/request")
    def recovery_request(body: RecoveryRequestBody) -> Dict[str, Any]:
        return {"ok": True, **domain.request_password_recovery(body.identifier)}

    @app.post("/api/auth/recovery/confirm")
    def recovery_confirm(body: RecoveryConfirmBody) -> Dict[str, Any]:
        return {"ok": True, **domain.confirm_password_recovery(body.token, body.new_password)}

    @app.post("/telegram/webhook")
    async def telegram_webhook(
        request: Request,
        x_telegram_bot_api_secret_token: str = Header(default=""),
    ) -> Dict[str, Any]:
        if not cfg.webhook_secret or not hmac.compare_digest(x_telegram_bot_api_secret_token, cfg.webhook_secret):
            raise HTTPException(status_code=403, detail="Invalid Telegram webhook secret.")
        payload = await request.json()
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="Update payload must be a JSON object.")
        telegram_adapter.handle_update(payload)
        return {"ok": True}

    @app.get("/api/profile/me")
    def get_my_profile(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.get_profile_bundle(user["id"])}

    @app.patch("/api/profile/me")
    def patch_my_profile(body: ProfileUpdateRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        updated = domain.update_profile(
            user["id"],
            display_name=body.display_name,
            bio=body.bio,
            instagram_handle=body.instagram_handle,
            avatar_url=body.avatar_url,
            district_id=body.district_id,
        )
        return {"ok": True, "user": updated}

    @app.get("/api/dashboard")
    def get_dashboard(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.get_dashboard_summary(user["id"])}

    @app.get("/api/settings")
    def get_my_settings(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "settings": domain.get_settings(user["id"])}

    @app.patch("/api/settings")
    def patch_my_settings(body: SettingsUpdateRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        updated = domain.update_settings(
            user["id"],
            language=body.language,
            classic_mode=body.classic_mode,
            notify_prefs=body.notify_prefs,
        )
        return {"ok": True, "settings": updated}

    @app.get("/api/notifications")
    def get_notifications(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "notifications": domain.list_notifications(user["id"])}

    @app.post("/api/notifications/{notification_id}/read")
    def read_notification(notification_id: str, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "notification": domain.mark_notification_read(user["id"], notification_id)}

    @app.get("/api/wallet")
    def get_wallet(limit: int = Query(default=50, ge=1, le=100), user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.get_wallet(user["id"], limit=limit)}

    @app.get("/api/payments/methods")
    def get_payment_methods(_: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "methods": domain.list_payment_methods()}

    @app.get("/api/payments/packages")
    def get_payment_packages(_: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "packages": domain.list_payment_packages()}

    @app.post("/api/payments/orders", status_code=201)
    def create_payment_order(body: CreatePaymentOrderRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        result = domain.create_manual_payment_order(
            user_id=user["id"],
            package_id=body.package_id,
            payment_method_code=body.payment_method_code,
            idempotency_key=body.idempotency_key,
        )
        return {"ok": True, **result}

    @app.get("/api/payments/orders")
    def list_my_orders(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "orders": domain.list_user_payment_orders(user["id"])}

    @app.post("/api/payments/orders/{order_id}/receipt")
    async def upload_payment_receipt(
        order_id: str,
        file: UploadFile = File(...),
        user: Dict[str, Any] = Depends(require_user),
    ) -> Dict[str, Any]:
        raw = await file.read(MAX_RECEIPT_BYTES + 1)
        if len(raw) > MAX_RECEIPT_BYTES:
            raise HTTPException(status_code=413, detail="Receipt exceeds 5 MB limit.")
        order = domain.upload_manual_payment_receipt(order_id=order_id, user_id=user["id"], raw_bytes=raw)
        return {"ok": True, "order": order}

    @app.post("/api/payments/orders/{order_id}/submit")
    def submit_payment_proof(order_id: str, body: SubmitPaymentProofRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        order = domain.submit_manual_payment_proof(
            order_id=order_id, user_id=user["id"], submitted_reference=body.submitted_reference
        )
        return {"ok": True, "order": order}

    @app.post("/api/payments/orders/{order_id}/cancel")
    def cancel_payment_order(order_id: str, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "order": domain.cancel_manual_payment_order(order_id=order_id, user_id=user["id"])}

    @app.get("/api/city/map")
    def get_city_map(user: Optional[Dict[str, Any]] = Depends(optional_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.get_city_map(user["id"] if user else None)}

    @app.post("/api/economy/daily-claim")
    def daily_claim(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.claim_daily_reward(user["id"])}

    @app.post("/api/city/taxi")
    def city_taxi(body: TaxiRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.book_taxi(user["id"], body.destination_district_id, body.request_id)}

    @app.post("/api/homes/me")
    def update_my_home(body: UpdateHomeRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "home": domain.update_home(user["id"], body.floors, body.has_pool, body.has_helipad)}

    @app.post("/api/objects/{object_id}/acquire")
    def acquire_landmark(object_id: str, body: AcquireObjectRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.acquire_object(user["id"], object_id, body.expected_version)}

    @app.get("/api/social/profiles")
    def social_discover(
        q: str = Query(default="", max_length=64),
        district_id: Optional[str] = Query(default=None, max_length=32),
        _: Optional[Dict[str, Any]] = Depends(optional_user),
    ) -> Dict[str, Any]:
        return {"ok": True, "profiles": domain.discover_profiles(query=q, district_id=district_id)}

    @app.get("/api/social/profiles/{username}")
    def social_profile_detail(username: str) -> Dict[str, Any]:
        return {"ok": True, **domain.get_public_profile(username)}

    @app.get("/api/social/friends")
    def social_friends(user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "friends": domain.list_friends(user["id"])}

    @app.post("/api/social/friends/request", status_code=201)
    def social_friend_request(body: FriendRequestBody, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "friendship": domain.request_friendship(user["id"], body.target_username)}

    @app.post("/api/social/friends/{friendship_id}/accept")
    def social_friend_accept(friendship_id: str, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, "friendship": domain.accept_friendship(user["id"], friendship_id)}

    @app.post("/api/social/homes/{home_id}/like")
    def social_like_home(home_id: str, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.like_home(user["id"], home_id)}

    @app.get("/api/places")
    def get_places(
        district_id: Optional[str] = Query(default=None, max_length=32),
        category: Optional[str] = Query(default=None, max_length=32),
    ) -> Dict[str, Any]:
        return {"ok": True, "places": domain.list_places(district_id=district_id, category=category)}

    @app.get("/api/events")
    def get_events(user: Optional[Dict[str, Any]] = Depends(optional_user)) -> Dict[str, Any]:
        return {"ok": True, "events": domain.list_events(user["id"] if user else None)}

    @app.post("/api/events/{event_id}/rsvp")
    def rsvp_event(event_id: str, body: EventRsvpBody, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.toggle_event_rsvp(user["id"], event_id, join=body.join)}

    @app.get("/api/elections")
    def get_elections(user: Optional[Dict[str, Any]] = Depends(optional_user)) -> Dict[str, Any]:
        return {"ok": True, "elections": domain.list_elections(user["id"] if user else None)}

    @app.post("/api/elections/{election_id}/vote")
    def cast_vote(election_id: str, body: VoteRequest, user: Dict[str, Any] = Depends(require_user)) -> Dict[str, Any]:
        return {"ok": True, **domain.cast_election_vote(user["id"], election_id, body.candidate_id)}

    @app.get("/api/admin/overview")
    def admin_overview(admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, "overview": domain.get_admin_overview(admin["id"])}

    @app.get("/api/admin/payments")
    def admin_list_payments(
        status: Optional[str] = Query(default=None),
        method: Optional[str] = Query(default=None),
        admin: Dict[str, Any] = Depends(require_admin),
    ) -> Dict[str, Any]:
        return {"ok": True, "orders": domain.list_admin_payment_orders(admin_user_id=admin["id"], status_filter=status, method_filter=method)}

    @app.post("/api/admin/payments/{order_id}/approve")
    def admin_approve_payment(order_id: str, admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, **domain.approve_manual_payment_order(order_id=order_id, admin_user_id=admin["id"])}

    @app.post("/api/admin/payments/{order_id}/reject")
    def admin_reject_payment(order_id: str, body: RejectPaymentRequest, admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, "order": domain.reject_manual_payment_order(order_id=order_id, admin_user_id=admin["id"], rejection_reason=body.rejection_reason)}

    @app.get("/api/admin/users")
    def admin_users(admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, "users": domain.list_admin_users(admin["id"])}

    @app.post("/api/admin/users/{user_id}/ban")
    def admin_ban(user_id: str, body: BanUserRequest, admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, **domain.admin_ban_user(admin["id"], user_id, body.reason)}

    @app.post("/api/admin/users/{user_id}/recovery-token")
    def admin_issue_recovery(user_id: str, admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, **domain.issue_recovery_token_for_admin(admin["id"], user_id)}

    @app.get("/api/admin/audit-logs")
    def admin_audit_logs(admin: Dict[str, Any] = Depends(require_admin)) -> Dict[str, Any]:
        return {"ok": True, **domain.list_admin_audit_logs(admin["id"])}

    return app


if __name__ == "__main__":
    import uvicorn

    cfg = AppConfig.from_env()
    uvicorn.run(create_app(cfg), host=cfg.host, port=cfg.port)
