from __future__ import annotations

import contextlib
import json
import os
import sqlite3
import threading
import time
from typing import Any, Dict, Iterator, List, Optional, Sequence

CANONICAL_DISTRICTS = [
    ("residential",   "Residential District",   "RES", "Foydalanuvchilar uylari va mahallalar", -400,  400),
    ("university",    "University District",    "UNI", "TATU, OzMU, Inha universitetlari",         0,  400),
    ("business",      "Business District",      "BIZ", "Savdo markazlari va dokonlar",           400,  400),
    ("nature",        "Nature District",        "NAT", "Yangi Ozbekiston bogi, kol va chinorlar",-400,   0),
    ("downtown",      "Downtown",               "DTW", "Nest One va biznes osmonoparlari",         0,    0),
    ("entertainment", "Entertainment District", "ENT", "Humo Arena, Magic City va oyin zali",    400,    0),
    ("transport",     "Transport District",     "TRN", "Halqa yoli metrosi, vokzal va aeroport", -400, -400),
    ("vip",           "VIP District",           "VIP", "Islom Sivilizatsiyasi Markazi va noyob binolar", 0, -400),
]

DEFAULT_CITY_OBJECTS = [
    ("obj_tvtower", "downtown",      "Toshkent Teleminorasi (375m)", "landmark", "Markaziy ramz",           1, 5000, 5000,   0, 0,   0),
    ("obj_nestone", "downtown",      "Nest One (266.5m)",            "landmark", "51 qavatli osmonopar",    1, 4500, 4500,  38, 0, -38),
    ("obj_minor",   "vip",           "Minor Masjidi",                "landmark", "Oq marmar va firuza",     1, 3500, 3500, -38, 0, -38),
    ("obj_chorsu",  "business",      "Chorsu Bozori",                "landmark", "86m firuza gumbaz",       1, 3000, 3000, -38, 0,   2),
    ("obj_humo",    "entertainment", "Humo Arena",                   "stadium",  "Humo qanoti muz saroyi",  1, 2500, 2500,  38, 0,   2),
    ("obj_cic",     "vip",           "Islom Sivilizatsiyasi Markazi","landmark", "65m mozaika gumbaz",      1, 6000, 6000,   0, 0, -42),
]

DEFAULT_GAMES = [
    ("game_snake",  "snake",  "CityX Snake",  18.0),
    ("game_bounce", "bounce", "CityX Bounce", 22.0),
]


DEFAULT_PLACES = [
    ("plc_tvtower",   "downtown",      "Toshkent Teleminorasi",           "landmark",      "375 metrli markaziy kuzatuv minorasi va ramziy inshoot", "Downtown, Markaziy aylanma",       0,    0),
    ("plc_nestone",   "downtown",      "Nest One Biznes Markazi",         "business",      "51 qavatli zamonaviy osmonopar va ofis majmuasi",        "Downtown, Tashkent City",         38,  -38),
    ("plc_tcmall",    "downtown",      "Tashkent City Mall",              "business",      "Savdo, ovqatlanish va dam olish majmuasi",               "Downtown, Markaziy xiyobon",     -28,   30),
    ("plc_chorsu",    "business",      "Chorsu Bozori",                   "business",      "Firuza gumbazli tarixiy savdo markazi",                  "Business, Eski shahar qismi",    400,  400),
    ("plc_humo",      "entertainment", "Humo Arena",                      "entertainment", "Konsert, sport va muz saroyi majmuasi",                  "Entertainment, Markaziy maydon", 400,    0),
    ("plc_magiccity", "entertainment", "Magic City Parki",                "entertainment", "Oilaviy madaniy va ko‘ngilochar hudud",                  "Entertainment, Janubiy qism",    440,   45),
    ("plc_tatu",      "university",    "TATU Kampusi",                    "education",     "Axborot texnologiyalari universiteti va talabalar bog‘i","University, Shimoliy xiyobon",     0,  400),
    ("plc_uzmu",      "university",    "O‘zMU Kampusi",                   "education",     "Milliy universitet o‘quv va ilmiy majmuasi",             "University, G‘arbiy qism",       -45,  420),
    ("plc_inha",      "university",    "Inha Universiteti",               "education",     "Muhandislik va dasturiy ta’minot fakulteti",             "University, Sharqiy qism",        50,  420),
    ("plc_lake",      "nature",        "Chinorlar Bog‘i va Sun’iy Ko‘l",  "nature",        "Piyodalar ko‘prigi, choyxona va dam olish maskani",      "Nature, G‘arbiy sohil",         -400,    0),
    ("plc_minor",     "vip",           "Minor Masjidi",                   "landmark",      "Oq marmar va firuza gumbazli me’moriy ansambl",          "VIP, Anhor bo‘yi",               -38, -400),
    ("plc_cic",       "vip",           "Islom Sivilizatsiyasi Markazi",   "landmark",      "65 metrli mozaika gumbazli madaniy markaz",              "VIP, Hazrati Imom hududi",         0, -400),
    ("plc_metrohub",  "transport",     "Toshkent Yerusti Metro Bekati",   "transport",     "4 yo‘nalishli tezkor metro va avtobus tuguni",           "Transport, Halqa yo‘li",        -400, -400),
    ("plc_taxihub",   "transport",     "CityX Taksi va Xizmat Markazi",   "service",       "Tumanlararo tezkor qatnov va shahar xizmatlari",         "Transport, Markaziy bekat",     -360, -370),
    ("plc_mahalla",   "residential",   "Yangi Mahalla Fuqarolar Markazi", "service",       "Uchastka ro‘yxatga olish va mahalla xizmatlari",         "Residential, A-02 hududi",      -400,  400),
]

DEFAULT_PACKAGES = [
    ("gems_100",    "100 CityX Gems",     "gems",   100,  25000),
    ("gems_500",    "500 CityX Gems",     "gems",   500, 115000),
    ("coins_10000", "10,000 CityX Coins", "coins", 10000, 20000),
]


def is_unique_violation(exc: Exception) -> bool:
    if isinstance(exc, sqlite3.IntegrityError):
        return "UNIQUE" in str(exc).upper() or "PRIMARY KEY" in str(exc).upper()
    sqlstate = getattr(exc, "sqlstate", None) or getattr(exc, "pgcode", None)
    return sqlstate == "23505"


class TransactionCursor:
    def __init__(self, backend: str, cursor: Any) -> None:
        self.backend = backend
        self._cur = cursor

    def _sql(self, query: str) -> str:
        if self.backend == "postgres":
            return query.replace("?", "%s")
        return query.replace(" FOR UPDATE", "")

    def execute(self, query: str, params: Sequence[Any] = ()) -> Any:
        self._cur.execute(self._sql(query), tuple(params))
        return self._cur

    @property
    def rowcount(self) -> int:
        return int(self._cur.rowcount)

    def fetchone(self, query: str, params: Sequence[Any] = ()) -> Optional[Dict[str, Any]]:
        self.execute(query, params)
        row = self._cur.fetchone()
        if row is None:
            return None
        if isinstance(row, dict):
            return dict(row)
        if hasattr(row, "keys"):
            return {k: row[k] for k in row.keys()}
        cols = [d[0] for d in self._cur.description]
        return dict(zip(cols, row))

    def fetchall(self, query: str, params: Sequence[Any] = ()) -> List[Dict[str, Any]]:
        self.execute(query, params)
        rows = self._cur.fetchall()
        out: List[Dict[str, Any]] = []
        for row in rows:
            if isinstance(row, dict):
                out.append(dict(row))
            elif hasattr(row, "keys"):
                out.append({k: row[k] for k in row.keys()})
            else:
                cols = [d[0] for d in self._cur.description]
                out.append(dict(zip(cols, row)))
        return out


class CityXStore:
    """
    Unified persistence store supporting:
    - PostgreSQL (production via psycopg_pool + SELECT ... FOR UPDATE)
    - SQLite (isolated local/CI tests via BEGIN IMMEDIATE + engine triggers)
    """

    def __init__(self, database_url: str = "", sqlite_path: str = ":memory:") -> None:
        self.backend = "postgres" if database_url else "sqlite"
        self.database_url = database_url
        self.sqlite_path = sqlite_path or ":memory:"
        self._sqlite_lock = threading.RLock()
        self._sqlite_conn: Optional[sqlite3.Connection] = None
        self._pg_pool: Any = None

        if self.backend == "postgres":
            import psycopg_pool  # type: ignore
            from psycopg.rows import dict_row  # type: ignore

            self._pg_pool = psycopg_pool.ConnectionPool(
                conninfo=self.database_url,
                min_size=1,
                max_size=10,
                kwargs={"row_factory": dict_row},
            )
        else:
            self._sqlite_conn = sqlite3.connect(
                self.sqlite_path,
                check_same_thread=False,
                isolation_level=None,
                timeout=30.0,
            )
            self._sqlite_conn.row_factory = sqlite3.Row
            self._init_sqlite_schema()

    def close(self) -> None:
        if self._pg_pool is not None:
            self._pg_pool.close()
            self._pg_pool = None
        if self._sqlite_conn is not None:
            self._sqlite_conn.close()
            self._sqlite_conn = None

    @contextlib.contextmanager
    def transaction(self) -> Iterator[TransactionCursor]:
        if self.backend == "postgres":
            with self._pg_pool.connection() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        yield TransactionCursor("postgres", cur)
        else:
            assert self._sqlite_conn is not None
            with self._sqlite_lock:
                cur = self._sqlite_conn.cursor()
                cur.execute("BEGIN IMMEDIATE")
                try:
                    yield TransactionCursor("sqlite", cur)
                    cur.execute("COMMIT")
                except Exception:
                    cur.execute("ROLLBACK")
                    raise
                finally:
                    cur.close()

    def _init_sqlite_schema(self) -> None:
        assert self._sqlite_conn is not None
        schema_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "..", "db", "sqlite", "test_phase04_schema.sql")
        )
        with open(schema_path, "r", encoding="utf-8") as f:
            ddl = f.read()

        with self._sqlite_lock:
            cur = self._sqlite_conn.cursor()
            if self.sqlite_path != ":memory:":
                cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("PRAGMA busy_timeout=30000;")
            cur.executescript(ddl)
            self._seed_sqlite_defaults(cur)
            cur.close()

    def _seed_sqlite_defaults(self, cur: sqlite3.Cursor) -> None:
        for row in CANONICAL_DISTRICTS:
            cur.execute(
                """
                INSERT OR IGNORE INTO districts (id, name, code, description, center_x, center_z)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                row,
            )
        for obj in DEFAULT_CITY_OBJECTS:
            cur.execute(
                """
                INSERT OR IGNORE INTO city_objects
                (id, district_id, name, category, description, is_unique,
                 base_price_coins, current_price_coins, pos_x, pos_y, pos_z)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                obj,
            )
        for game in DEFAULT_GAMES:
            cur.execute(
                "INSERT OR IGNORE INTO games (id, code, name, max_score_per_sec) VALUES (?, ?, ?, ?)",
                game,
            )
        for plc in DEFAULT_PLACES:
            cur.execute(
                """
                INSERT OR IGNORE INTO city_places
                (id, district_id, name, category, description, address_label, pos_x, pos_z, is_open)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                """,
                plc,
            )
        for pid, title, rcur, ramt, price in DEFAULT_PACKAGES:
            cur.execute(
                """
                INSERT OR IGNORE INTO payment_packages
                (id, title, reward_currency, reward_amount, price_uzs, is_active)
                VALUES (?, ?, ?, ?, ?, 1)
                """,
                (pid, title, rcur, ramt, price),
            )
        cur.execute(
            """
            INSERT OR IGNORE INTO events (id, title, event_type, location, start_ts, status)
            VALUES (?, ?, 'racing', ?, ?, 'active')
            """,
            (
                "evt_neon_grandprix",
                "Neon Grand Prix & District Expo",
                "Central Plaza 3D Arena",
                int(time.time()) + 21600,
            ),
        )
        cur.execute(
            """
            INSERT OR IGNORE INTO elections (election_id, title, status, candidates_json)
            VALUES (?, ?, 'open', ?)
            """,
            (
                "elec_2026_q4",
                "CityX Council Election 2026",
                json.dumps(
                    [
                        {"id": "cand_aziza", "name": "Aziza K.", "platform": "Green Mobility & Tech Grants"},
                        {"id": "cand_timur", "name": "Timur R.", "platform": "Racing League & Lower Property Tax"},
                        {"id": "cand_sardor", "name": "Sardor M.", "platform": "Harbor Expansion & Builder Rewards"},
                    ]
                ),
            ),
        )
