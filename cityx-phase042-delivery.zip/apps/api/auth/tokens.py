from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import time
import urllib.parse
import uuid
from typing import Any, Dict, Tuple

_B64URL_RE = re.compile(r"^[A-Za-z0-9_-]+$")
_VALID_ROLES = frozenset({"user", "moderator", "admin"})
JWT_ISSUER = "cityx-api"
JWT_AUDIENCE = "cityx-client"
MAX_JWT_BYTES = 4096
MAX_JWT_TTL_SECONDS = 86400
CLOCK_SKEW_SECONDS = 30


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64url_decode(encoded: str) -> bytes:
    pad = "=" * ((4 - len(encoded) % 4) % 4)
    return base64.urlsafe_b64decode(encoded + pad)


def hash_password_pbkdf2(password: str) -> str:
    """Preserves PBKDF2-SHA256 password hashing from legacy backend/service.py."""
    salt = os.urandom(16).hex()
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 100_000).hex()
    return f"{salt}:{dk}"


def verify_password_pbkdf2(password: str, stored: str) -> bool:
    if not stored or ":" not in stored:
        return False
    try:
        salt, dk = stored.split(":", 1)
        cand = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 100_000).hex()
        return hmac.compare_digest(cand, dk)
    except Exception:
        return False


class AuthSecurity:
    """
    Preserves official Telegram Mini App initData HMAC-SHA256 validation and
    signed callback verification from CityX_Telegram_Bot_cleaned.py, and adds
    strictly validated HS256 JWTs for unified Web + Mini App sessions.
    """

    def __init__(self, bot_token: str, signing_secret: str) -> None:
        self.bot_token = bot_token
        self.signing_secret = signing_secret

    def verify_miniapp_init_data(self, init_data: str, max_age_seconds: int = 300) -> Dict[str, Any]:
        if not self.bot_token:
            raise ValueError("BOT_TOKEN is not configured.")
        if not isinstance(init_data, str) or not init_data:
            raise ValueError("Missing initData.")
        if len(init_data.encode("utf-8")) > 16_384:
            raise ValueError("initData is too large.")

        pairs = urllib.parse.parse_qsl(
            init_data, keep_blank_values=True, strict_parsing=True, max_num_fields=64
        )
        if len({k for k, _ in pairs}) != len(pairs):
            raise ValueError("Duplicate initData fields.")

        parsed = dict(pairs)
        received_hash = parsed.pop("hash", "")
        if not received_hash:
            raise ValueError("Missing hash in initData.")

        data_check_string = "\n".join(f"{k}={parsed[k]}" for k in sorted(parsed.keys()))
        secret_key = hmac.new(b"WebAppData", self.bot_token.encode("utf-8"), hashlib.sha256).digest()
        computed_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()

        if not hmac.compare_digest(computed_hash, received_hash):
            raise ValueError("Invalid initData HMAC signature.")

        try:
            auth_date = int(parsed.get("auth_date", "0"))
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid initData auth_date.") from exc

        now = int(time.time())
        if max_age_seconds <= 0 or auth_date > now + CLOCK_SKEW_SECONDS or now - auth_date > max_age_seconds:
            raise ValueError("Expired initData session.")

        user_raw = parsed.get("user")
        if not user_raw:
            raise ValueError("Missing user object in initData.")
        try:
            user_obj = json.loads(user_raw)
        except json.JSONDecodeError as exc:
            raise ValueError("Malformed user JSON in initData.") from exc
        if not isinstance(user_obj, dict) or "id" not in user_obj:
            raise ValueError("Malformed user object in initData.")
        return user_obj

    def issue_jwt(self, user_id: str, role: str, ttl_seconds: int = 3600) -> Tuple[str, str, int]:
        if len(self.signing_secret) < 16:
            raise RuntimeError("CITYX_SIGNING_SECRET must be at least 16 characters.")
        if role not in _VALID_ROLES:
            raise ValueError("Invalid role for JWT.")
        if type(ttl_seconds) is not int or not (1 <= ttl_seconds <= MAX_JWT_TTL_SECONDS):
            raise ValueError("JWT TTL must be between 1 and 86400 seconds.")

        now = int(time.time())
        exp = now + ttl_seconds
        jti = uuid.uuid4().hex
        header = {"alg": "HS256", "typ": "JWT"}
        payload = {
            "iss": JWT_ISSUER,
            "aud": JWT_AUDIENCE,
            "sub": user_id,
            "role": role,
            "iat": now,
            "nbf": now,
            "exp": exp,
            "jti": jti,
        }
        h_b64 = _b64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
        p_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
        signing_input = f"{h_b64}.{p_b64}".encode("ascii")
        sig = hmac.new(self.signing_secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
        return f"{h_b64}.{p_b64}.{_b64url_encode(sig)}", jti, exp

    def verify_jwt(self, token: str) -> Dict[str, Any]:
        """Strict HS256 JWT validator: verifies signature BEFORE JSON parsing and validates every claim type."""
        if not isinstance(token, str) or not token or len(token.encode("utf-8")) > MAX_JWT_BYTES:
            raise ValueError("Invalid JWT size or type.")
        parts = token.split(".")
        if len(parts) != 3 or not all(_B64URL_RE.match(p) for p in parts):
            raise ValueError("Malformed JWT structure.")

        h_b64, p_b64, s_b64 = parts

        # 1. Cryptographic signature check BEFORE parsing untrusted JSON.
        signing_input = f"{h_b64}.{p_b64}".encode("ascii")
        expected_sig = _b64url_encode(
            hmac.new(self.signing_secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
        )
        if not hmac.compare_digest(expected_sig, s_b64):
            raise ValueError("Invalid JWT signature.")

        # 2. Decode JSON objects strictly.
        try:
            header = json.loads(_b64url_decode(h_b64).decode("utf-8"))
            payload = json.loads(_b64url_decode(p_b64).decode("utf-8"))
        except (binascii.Error, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise ValueError("Malformed JWT encoding.") from exc

        if not isinstance(header, dict) or not isinstance(payload, dict):
            raise ValueError("JWT header and payload must be JSON objects.")
        if header.get("alg") != "HS256" or header.get("typ") != "JWT":
            raise ValueError("Unsupported JWT header.")

        # 3. Validate claims and exact types (explicitly reject bool masquerading as int).
        sub = payload.get("sub")
        jti = payload.get("jti")
        role = payload.get("role")
        iss = payload.get("iss")
        aud = payload.get("aud")
        iat = payload.get("iat")
        exp = payload.get("exp")
        nbf = payload.get("nbf")

        if type(sub) is not str or not sub.strip() or len(sub) > 128:
            raise ValueError("Invalid JWT 'sub' claim.")
        if type(jti) is not str or not jti.strip() or len(jti) > 128:
            raise ValueError("Invalid JWT 'jti' claim.")
        if type(role) is not str or role not in _VALID_ROLES:
            raise ValueError("Invalid JWT 'role' claim.")
        if iss != JWT_ISSUER or aud != JWT_AUDIENCE:
            raise ValueError("Invalid JWT issuer or audience.")
        if type(iat) is not int or type(exp) is not int:
            raise ValueError("JWT 'iat' and 'exp' must be integers.")
        if nbf is not None and type(nbf) is not int:
            raise ValueError("JWT 'nbf' must be an integer.")

        now = int(time.time())
        if exp <= iat or (exp - iat) > MAX_JWT_TTL_SECONDS:
            raise ValueError("Invalid JWT lifetime.")
        if iat > now + CLOCK_SKEW_SECONDS:
            raise ValueError("JWT issued in the future.")
        if nbf is not None and nbf > now + CLOCK_SKEW_SECONDS:
            raise ValueError("JWT is not active yet.")
        if exp <= now:
            raise ValueError("Expired JWT.")

        return payload

    def sign_callback(self, action: str, entity_id: str = "", ttl_seconds: int = 3600) -> str:
        if not self.signing_secret:
            raise RuntimeError("CITYX_SIGNING_SECRET must be configured.")
        if not action or ":" in action or ":" in entity_id:
            raise ValueError("Callback action and entity_id must be colon-free.")
        if not (1 <= ttl_seconds <= 7 * 24 * 3600):
            raise ValueError("Callback lifetime must be between 1 second and 7 days.")
        exp = int(time.time()) + ttl_seconds
        base = f"v1:{action}:{entity_id}:{exp}"
        sig = hmac.new(self.signing_secret.encode("utf-8"), base.encode("utf-8"), hashlib.sha256).hexdigest()[:20]
        token = f"{base}:{sig}"
        if len(token.encode("utf-8")) > 64:
            raise ValueError("Signed callback exceeds 64-byte Telegram limit.")
        return token

    def verify_callback(self, data: str) -> Tuple[bool, str, str, str]:
        if not isinstance(data, str) or not self.signing_secret or len(data.encode("utf-8")) > 64:
            return False, "", "", "Invalid callback configuration or size."
        parts = data.split(":")
        if len(parts) != 5 or parts[0] != "v1":
            return False, "", "", "Invalid callback format."
        _, action, entity_id, exp_str, sig = parts
        base = f"v1:{action}:{entity_id}:{exp_str}"
        expected = hmac.new(self.signing_secret.encode("utf-8"), base.encode("utf-8"), hashlib.sha256).hexdigest()[:20]
        if not hmac.compare_digest(sig, expected):
            return False, "", "", "Tampered callback signature."
        try:
            exp = int(exp_str)
        except ValueError:
            return False, "", "", "Malformed callback expiration."
        if int(time.time()) >= exp:
            return False, action, entity_id, "Expired action. Please refresh."
        return True, action, entity_id, ""
