from __future__ import annotations

import datetime
import json
import logging
import os
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

from apps.api.auth.tokens import AuthSecurity
from apps.api.config import AppConfig
from apps.api.domain.services import CityXDomainService, DomainError, TAXI_FARES_BY_DISTRICT
from apps.api.telegram.widgets import MAX_WIDGET_QUERY_BYTES, WIDGET_TEMPLATES, validate_all_widget_templates

logger = logging.getLogger("cityx.telegram")

PRIVATE_TOPICS: List[Tuple[str, str]] = [
    ("home", "CityX Home"),
    ("profile", "My Profile"),
    ("city", "Virtual City"),
    ("properties", "My Properties"),
    ("garage", "Garage"),
    ("games", "Games"),
    ("economy", "Economy"),
    ("events", "Events"),
    ("support", "Support"),
]

# Canonical district subset exposed inside the 4-slot Taxi widget (strictly matches DB districts.id)
TAXI_WIDGET_DESTINATIONS: List[Dict[str, Any]] = [
    {"id": "downtown", "name": "Downtown", "fare": TAXI_FARES_BY_DISTRICT["downtown"][0], "eta": TAXI_FARES_BY_DISTRICT["downtown"][1]},
    {"id": "business", "name": "Business", "fare": TAXI_FARES_BY_DISTRICT["business"][0], "eta": TAXI_FARES_BY_DISTRICT["business"][1]},
    {"id": "entertainment", "name": "Entertainment", "fare": TAXI_FARES_BY_DISTRICT["entertainment"][0], "eta": TAXI_FARES_BY_DISTRICT["entertainment"][1]},
    {"id": "vip", "name": "VIP", "fare": TAXI_FARES_BY_DISTRICT["vip"][0], "eta": TAXI_FARES_BY_DISTRICT["vip"][1]},
]

RACING_TRACKS = [
    {
        "name": "Sprint",
        "record": "01:12.44",
        "top3": [{"u": "@aziza_gt", "t": "01:12.44"}, {"u": "@timur_x", "t": "01:13.08"}, {"u": "@bek_uz", "t": "01:14.21"}],
    },
    {
        "name": "Drift",
        "record": "48,900 pts",
        "top3": [{"u": "@drift_king", "t": "48,900"}, {"u": "@sardor_m", "t": "46,200"}, {"u": "@malika_v", "t": "44,750"}],
    },
    {
        "name": "Circuit",
        "record": "02:38.19",
        "top3": [{"u": "@timur_x", "t": "02:38.19"}, {"u": "@aziza_gt", "t": "02:39.05"}, {"u": "@jasur_99", "t": "02:41.60"}],
    },
]

# Preserved command surface (with /stars replaced by /topup manual bank transfer flow)
SUPPORTED_COMMANDS = (
    "/start",
    "/dashboard",
    "/property",
    "/garage",
    "/racing",
    "/battle",
    "/event",
    "/taxi",
    "/tx",
    "/election",
    "/topup",
    "/topics",
    "/classic",
    "/help",
)


class CapabilityRegistry:
    """Preserved Bot API 10.5 capability registry with automated payment gateways & TON disabled."""

    BOT_API_BASELINE = "10.5"

    def __init__(self, environment: str) -> None:
        self.is_test_server = environment == "test_server"
        self.flags: Dict[str, bool] = {
            "widgets_private_chat": os.getenv("CAP_WIDGETS_PRIVATE", "true").lower() == "true",
            "rich_messages": os.getenv("CAP_RICH_MESSAGES", "true").lower() == "true",
            "ephemeral_group_messages": os.getenv("CAP_EPHEMERAL", "true").lower() == "true",
            "private_chat_topics": os.getenv("CAP_PRIVATE_TOPICS", "true").lower() == "true",
            "programmatic_settings": os.getenv("CAP_SET_MY_SETTINGS", "true").lower() == "true",
            "widgets_groups": self.is_test_server,
            "widgets_inline": self.is_test_server,
            "widgets_shared_forwards": self.is_test_server,
            "ton_wallet": False,
        }

    def enabled(self, feature: str) -> bool:
        return bool(self.flags.get(feature, False))

    def can_send_widget_in_chat(self, chat_type: str) -> bool:
        if chat_type == "private":
            return self.enabled("widgets_private_chat")
        if chat_type in ("group", "supergroup"):
            return self.enabled("widgets_groups")
        return False


class TelegramAPIError(Exception):
    def __init__(self, method: str, error_code: int, description: str) -> None:
        super().__init__(f"Telegram API error on {method} [{error_code}]: {description}")
        self.method = method
        self.error_code = error_code
        self.description = description


class TelegramBotClient:
    """Zero-dependency Telegram Bot API 10.5 client (Stars invoice methods removed)."""

    def __init__(self, bot_token: str, api_base_url: str = "https://api.telegram.org") -> None:
        self.bot_token = bot_token
        self.base_url = f"{api_base_url.rstrip('/')}/bot{bot_token}"

    def call(self, method: str, payload: Optional[Dict[str, Any]] = None, timeout: int = 25) -> Any:
        if not self.bot_token:
            raise RuntimeError("BOT_TOKEN is not configured.")
        url = f"{self.base_url}/{method}"
        body = json.dumps(payload or {}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            url, data=body, headers={"Content-Type": "application/json; charset=utf-8"}, method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                parsed = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            raise TelegramAPIError(method, exc.code, err_body) from exc
        except urllib.error.URLError as exc:
            raise TelegramAPIError(method, 0, f"Network error: {exc.reason}") from exc
        if not parsed.get("ok"):
            raise TelegramAPIError(method, parsed.get("error_code", 0), parsed.get("description", "Unknown error"))
        return parsed.get("result")

    def send_widget(
        self,
        chat_id: int,
        html: str,
        *,
        chat_data: Optional[Dict[str, Any]] = None,
        public_data: Optional[Dict[str, Any]] = None,
        caption: Optional[str] = None,
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "chat_id": chat_id,
            "html": html,
            "width": 0,
            "height": 0,
            "allow_queries": True,
        }
        if chat_data is not None:
            payload["chat_data"] = json.dumps(chat_data, ensure_ascii=False, separators=(",", ":"))
        if public_data is not None:
            payload["public_data"] = json.dumps(public_data, ensure_ascii=False, separators=(",", ":"))
        if caption:
            payload["caption"] = caption
            payload["parse_mode"] = "HTML"
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if message_thread_id:
            payload["message_thread_id"] = message_thread_id
        return self.call("sendWidget", payload)

    def send_message(
        self,
        chat_id: int,
        text: str,
        *,
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if message_thread_id:
            payload["message_thread_id"] = message_thread_id
        return self.call("sendMessage", payload)

    def answer_widget_query(self, widget_query_id: str, text: str = "") -> bool:
        payload: Dict[str, Any] = {"widget_query_id": widget_query_id}
        if text:
            payload["text"] = text[:200]
        return bool(self.call("answerWidgetQuery", payload))

    def edit_message_widget_data(
        self,
        *,
        chat_id: Optional[int] = None,
        message_id: Optional[int] = None,
        inline_message_id: Optional[str] = None,
        chat_data: Optional[Dict[str, Any]] = None,
        public_data: Optional[Dict[str, Any]] = None,
    ) -> Any:
        payload: Dict[str, Any] = {}
        if inline_message_id:
            payload["inline_message_id"] = inline_message_id
        else:
            payload["chat_id"] = chat_id
            payload["message_id"] = message_id
        if chat_data is not None:
            payload["chat_data"] = json.dumps(chat_data, ensure_ascii=False, separators=(",", ":"))
        if public_data is not None:
            payload["public_data"] = json.dumps(public_data, ensure_ascii=False, separators=(",", ":"))
        return self.call("editMessageWidgetData", payload)

    def answer_callback_query(self, callback_query_id: str, text: str = "", show_alert: bool = False) -> bool:
        payload: Dict[str, Any] = {"callback_query_id": callback_query_id, "show_alert": show_alert}
        if text:
            payload["text"] = text[:200]
        return bool(self.call("answerCallbackQuery", payload))

    def create_forum_topic(self, chat_id: int, name: str) -> Dict[str, Any]:
        return self.call("createForumTopic", {"chat_id": chat_id, "name": name[:128]})

    def set_my_settings(self, settings: Dict[str, Any]) -> bool:
        return bool(self.call("setMySettings", settings))


class TelegramBotAdapter:
    """
    Unified Telegram adapter preserving all 10 HTML widgets, 9 private topics,
    fallback pipelines, and existing commands — backed directly by CityXDomainService
    and the canonical database (zero separate SQLite bot state).
    """

    def __init__(
        self,
        config: AppConfig,
        domain: CityXDomainService,
        security: AuthSecurity,
        client: Optional[TelegramBotClient] = None,
    ) -> None:
        self.config = config
        self.domain = domain
        self.security = security
        self.client = client or TelegramBotClient(config.bot_token)
        self.caps = CapabilityRegistry(config.environment)
        # Mandatory startup widget validation
        self.widget_report = validate_all_widget_templates()

    def miniapp_link(self, startapp: str = "home") -> str:
        return f"https://t.me/{self.config.bot_username}/{self.config.miniapp_short_name}?startapp={startapp}"

    def _today_utc5(self) -> str:
        tz_uz = datetime.timezone(datetime.timedelta(hours=5))
        return datetime.datetime.now(tz_uz).strftime("%Y-%m-%d")

    def _acquire_update_idempotency(self, key: str, ttl_seconds: int = 3600) -> bool:
        now = int(time.time())
        try:
            with self.domain.store.transaction() as tx:
                tx.execute("DELETE FROM idempotency_keys WHERE created_at < ?", (now - ttl_seconds,))
                tx.execute("INSERT INTO idempotency_keys (idem_key, created_at) VALUES (?, ?)", (key, now))
            return True
        except Exception:
            return False

    def _get_topic_thread(self, telegram_user_id: int, topic_key: str) -> Optional[int]:
        with self.domain.store.transaction() as tx:
            row = tx.fetchone(
                "SELECT message_thread_id FROM telegram_user_topics WHERE telegram_user_id = ? AND topic_key = ?",
                (telegram_user_id, topic_key),
            )
            return int(row["message_thread_id"]) if row else None

    def _register_widget(
        self, chat_id: int, message_id: int, widget_id: str, owner_user_id: str, entity_id: str, state: Dict[str, Any]
    ) -> None:
        with self.domain.store.transaction() as tx:
            tx.execute(
                """
                INSERT INTO telegram_widget_instances
                (chat_id, message_id, widget_id, owner_user_id, entity_id, state_json, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(chat_id, message_id) DO UPDATE SET
                    widget_id = excluded.widget_id,
                    owner_user_id = excluded.owner_user_id,
                    entity_id = excluded.entity_id,
                    state_json = excluded.state_json,
                    updated_at = excluded.updated_at
                """,
                (chat_id, message_id, widget_id, owner_user_id, entity_id, json.dumps(state), int(time.time())),
            )

    def _dispatch_widget_or_fallback(
        self,
        *,
        chat_id: int,
        chat_type: str,
        user: Dict[str, Any],
        widget_id: str,
        chat_data: Dict[str, Any],
        caption: str,
        markup: Dict[str, Any],
        public_data: Optional[Dict[str, Any]] = None,
        entity_id: str = "",
        topic_key: Optional[str] = None,
    ) -> None:
        thread_id = self._get_topic_thread(chat_id, topic_key) if (chat_type == "private" and topic_key) else None
        use_widget = self.caps.can_send_widget_in_chat(chat_type) and not bool(user.get("classic_mode"))
        if use_widget:
            try:
                msg = self.client.send_widget(
                    chat_id=chat_id,
                    html=WIDGET_TEMPLATES[widget_id],
                    chat_data=chat_data,
                    public_data=public_data,
                    caption=caption,
                    reply_markup=markup,
                    message_thread_id=thread_id,
                )
                self._register_widget(chat_id, int(msg["message_id"]), widget_id, user["id"], entity_id, chat_data)
                return
            except TelegramAPIError as exc:
                logger.warning("sendWidget(%s) fallback triggered: %s", widget_id, exc)
        self.client.send_message(chat_id, caption, reply_markup=markup, message_thread_id=thread_id)

    def handle_update(self, update: Dict[str, Any]) -> None:
        # Automated Stars payment updates (pre_checkout_query / successful_payment) are intentionally NOT processed.
        if "message" in update:
            self._handle_message(update["message"])
        elif "widget_query" in update:
            self._handle_widget_query(update["widget_query"], is_shared=False)
        elif "shared_widget_query" in update:
            self._handle_widget_query(update["shared_widget_query"], is_shared=True)
        elif "callback_query" in update:
            self._handle_callback_query(update["callback_query"])

    def _handle_message(self, msg: Dict[str, Any]) -> None:
        tg_user = msg.get("from")
        chat = msg.get("chat", {})
        if not tg_user or not chat:
            return
        text = (msg.get("text") or "").strip()
        if not text.startswith("/"):
            return

        chat_id = int(chat["id"])
        chat_type = chat.get("type", "private")
        user, _ = self.domain.get_or_create_telegram_user(tg_user)
        parts = text.split(maxsplit=1)
        cmd = parts[0].split("@")[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if cmd == "/start":
            if arg.startswith("prop_"):
                self.send_property_widget(chat_id, chat_type, user)
            elif arg.startswith("event_"):
                self.send_event_widget(chat_id, chat_type, user)
            else:
                self.send_welcome_widget(chat_id, chat_type, user)
        elif cmd == "/dashboard":
            self.send_daily_dashboard_widget(chat_id, chat_type, user)
        elif cmd == "/property":
            self.send_property_widget(chat_id, chat_type, user)
        elif cmd == "/garage":
            self.send_garage_widget(chat_id, chat_type, user)
        elif cmd == "/racing":
            self.send_racing_widget(chat_id, chat_type, user)
        elif cmd == "/battle":
            self.send_district_battle_widget(chat_id, chat_type, user)
        elif cmd == "/event":
            self.send_event_widget(chat_id, chat_type, user)
        elif cmd == "/taxi":
            self.send_taxi_widget(chat_id, chat_type, user)
        elif cmd == "/tx":
            self.send_transaction_widget(chat_id, chat_type, user)
        elif cmd == "/election":
            self.send_election_widget(chat_id, chat_type, user)
        elif cmd == "/topup":
            self.send_manual_topup_notice(chat_id)
        elif cmd == "/classic":
            new_mode = 0 if int(user["classic_mode"]) else 1
            with self.domain.store.transaction() as tx:
                tx.execute("UPDATE profiles SET classic_mode = ? WHERE user_id = ?", (new_mode, user["id"]))
            label = "Classic Fallback Mode" if new_mode else "HTML Widgets Mode"
            self.client.send_message(chat_id, f"Switched to <b>{label}</b>.")
        elif cmd == "/topics" and chat_type == "private":
            self._provision_private_topics(chat_id)
        elif cmd == "/help":
            self.client.send_message(
                chat_id,
                "<b>CityX Commands</b>\n"
                "/start /dashboard /property /garage /racing /battle /event /taxi /tx /election /topup /topics /classic",
            )

    def send_manual_topup_notice(self, chat_id: int) -> None:
        methods = self.domain.list_payment_methods()
        lines = ["<b>CityX Manual Bank Transfer Top-Up (UZS)</b>", "Choose a package inside the Mini App:"]
        for m in methods:
            bank_part = f"{m['bank_name']} — " if m["bank_name"] else ""
            lines.append(f"• {bank_part}{m['network']} • {m['card_masked']} ({m['recipient_name']})")
        lines.append("\nCurrency is credited only after manual administrator verification.")
        self.client.send_message(
            chat_id,
            "\n".join(lines),
            reply_markup={
                "inline_keyboard": [
                    [{"text": "Open Top-Up in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/economy/topup"}}]
                ]
            },
        )

    def send_welcome_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        chat_data = {
            "username": user["username"],
            "coins": int(user["coins"]),
            "dailyReady": user["last_daily_claim"] != self._today_utc5(),
            "district": user["district_id"],
            "miniAppUrl": self.miniapp_link("home"),
        }
        markup = {
            "inline_keyboard": [
                [{"text": "Enter 3D City", "web_app": {"url": f"{self.config.web_base_url}/app"}}],
                [
                    {"text": "Dashboard", "callback_data": self.security.sign_callback("open", "dashboard")},
                    {"text": "Taxi", "callback_data": self.security.sign_callback("open", "taxi")},
                    {"text": "Top Up", "callback_data": self.security.sign_callback("open", "topup")},
                ],
            ]
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_welcome",
            chat_data=chat_data,
            caption=f"<b>CityX</b> — Welcome, @{user['username']} | {int(user['coins']):,} CX",
            markup=markup,
            topic_key="home",
        )

    def send_daily_dashboard_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        fresh = self.domain.get_user_view(user["id"]) or user
        claimable = fresh["last_daily_claim"] != self._today_utc5()
        chat_data = {
            "coins": int(fresh["coins"]),
            "gems": int(fresh["gems"]),
            "level": int(fresh["level"]),
            "questDone": 2,
            "questTotal": 5,
            "streak": int(fresh["streak"]),
            "rank": 1,
            "district": fresh["district_id"],
            "claimable": claimable,
            "msg": "Tap Claim for +150 CX & +2 Gems" if claimable else "Daily reward already claimed today.",
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=fresh,
            widget_id="cityx_daily_dashboard",
            chat_data=chat_data,
            caption=f"<b>Daily Dashboard</b> | {int(fresh['coins']):,} CX | {int(fresh['gems'])} Gems",
            markup={"inline_keyboard": [[{"text": "Claim Daily Reward", "callback_data": self.security.sign_callback("daily", "claim")}]]},
            topic_key="home",
        )

    def send_property_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        with self.domain.store.transaction() as tx:
            home = tx.fetchone("SELECT * FROM homes WHERE user_id = ? LIMIT 1", (user["id"],))
        if not home:
            self.client.send_message(chat_id, "No home found yet.")
            return
        chat_data = {
            "id": home["id"],
            "name": f"Plot {home['plot_code']}",
            "district": home["district_id"],
            "ownerHandle": f"@{user['username']}",
            "level": int(home["floors"]),
            "valueCoins": int(home["floors"]) * 5000,
            "upgradeStatus": "Manage in Mini App",
            "canUpgrade": False,
            "miniAppUrl": self.miniapp_link(f"property_{home['id']}"),
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_property",
            chat_data=chat_data,
            caption=f"<b>Plot {home['plot_code']}</b> ({home['district_id']}) — {home['floors']} floors",
            markup={"inline_keyboard": [[{"text": "Open Home in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/property/{home['id']}"}}]]},
            entity_id=home["id"],
            topic_key="properties",
        )

    def send_garage_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any], idx: int = 0) -> None:
        with self.domain.store.transaction() as tx:
            rows = tx.fetchall("SELECT * FROM vehicles WHERE user_id = ? ORDER BY id", (user["id"],))
        if not rows:
            self.client.send_message(chat_id, "Your garage is empty.")
            return
        v = rows[idx % len(rows)]
        chat_data = {
            "vehId": v["id"],
            "name": v["display_name"],
            "vClass": v["vehicle_class"],
            "rating": int(v["rating"]),
            "upgPct": int(v["upgrade_pct"]),
            "energyPct": int(v["energy_pct"]),
            "idx": idx % len(rows),
            "total": len(rows),
            "miniAppUrl": self.miniapp_link(f"garage_{v['id']}"),
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_garage",
            chat_data=chat_data,
            caption=f"<b>Garage</b> — {v['display_name']} ({v['vehicle_class']})",
            markup={"inline_keyboard": [[{"text": "Open Garage", "web_app": {"url": f"{self.config.web_base_url}/app/garage"}}]]},
            entity_id=v["id"],
            topic_key="garage",
        )

    def send_racing_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any], sel: int = 0) -> None:
        track = RACING_TRACKS[sel % len(RACING_TRACKS)]
        chat_data = {
            "tracks": [t["name"] for t in RACING_TRACKS],
            "selected": sel % len(RACING_TRACKS),
            "record": track["record"],
            "top3": track["top3"],
            "status": f"Track: {track['name']}",
            "miniAppRaceUrl": self.miniapp_link(f"race_{track['name'].lower()}"),
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_racing",
            chat_data=chat_data,
            caption=f"<b>CityX Racing</b> — {track['name']}",
            markup={"inline_keyboard": [[{"text": "Race in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/racing"}}]]},
            topic_key="games",
        )

    def send_district_battle_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        with self.domain.store.transaction() as tx:
            rows = tx.fetchall("SELECT name, total_points FROM districts ORDER BY total_points DESC LIMIT 4")
            part = tx.fetchone("SELECT points FROM district_participants WHERE user_id = ?", (user["id"],))
        public_data = {
            "season": "CityX District Battle",
            "status": "LIVE",
            "districts": [{"name": r["name"], "pts": int(r["total_points"])} for r in rows],
        }
        chat_data = {
            "userDistrict": user["district_id"],
            "userPts": int(part["points"]) if part else 0,
            "joined": bool(part),
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_district_battle",
            chat_data=chat_data,
            public_data=public_data,
            caption=f"<b>District Battle</b> — {user['district_id']}",
            markup={"inline_keyboard": [[{"text": "Open Virtual City", "web_app": {"url": f"{self.config.web_base_url}/app/city"}}]]},
            topic_key="city",
        )

    def send_event_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        with self.domain.store.transaction() as tx:
            ev = tx.fetchone("SELECT * FROM events ORDER BY start_ts DESC LIMIT 1")
            if not ev:
                self.client.send_message(chat_id, "No active events.")
                return
            cnt = tx.fetchone("SELECT COUNT(*) AS c FROM event_rsvps WHERE event_id = ?", (ev["id"],))
            rsvp = tx.fetchone("SELECT 1 FROM event_rsvps WHERE event_id = ? AND user_id = ?", (ev["id"], user["id"]))
        public_data = {
            "eventId": ev["id"],
            "title": ev["title"],
            "location": ev["location"],
            "startTs": int(ev["start_ts"]),
            "attendees": int(cnt["c"]) if cnt else 0,
        }
        chat_data = {"joined": bool(rsvp), "miniAppUrl": self.miniapp_link(f"event_{ev['id']}")}
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_event",
            chat_data=chat_data,
            public_data=public_data,
            caption=f"<b>CityX Event</b> — {ev['title']}",
            markup={"inline_keyboard": [[{"text": "Event Details", "web_app": {"url": f"{self.config.web_base_url}/app/events/{ev['id']}"}}]]},
            entity_id=ev["id"],
            topic_key="events",
        )

    def send_taxi_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        dest = TAXI_WIDGET_DESTINATIONS[1]
        chat_data = {
            "from": user["district_id"],
            "dests": [d["name"] for d in TAXI_WIDGET_DESTINATIONS],
            "selIdx": 1,
            "fareCoins": dest["fare"],
            "etaMin": dest["eta"],
            "booked": False,
            "miniAppRouteUrl": self.miniapp_link("taxi_route"),
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_taxi",
            chat_data=chat_data,
            caption=f"<b>CityX Taxi</b> — Pickup: {user['district_id']}",
            markup={"inline_keyboard": [[{"text": "Open Route in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/city/taxi"}}]]},
            topic_key="city",
        )

    def send_transaction_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        orders = self.domain.list_user_payment_orders(user["id"])
        if not orders:
            self.client.send_message(
                chat_id,
                "No manual payment orders yet. Use /topup to start a manual bank transfer.",
            )
            return
        order = orders[0]
        ts = datetime.datetime.fromtimestamp(int(order["updated_at"]), datetime.timezone.utc).strftime("%H:%M:%S UTC")
        chat_data = {
            "ref": order["order_id"],
            "amount": int(order["expected_amount_uzs"]),
            "currency": "UZS",
            "provider": f"{order['payment_network_snapshot']} ({order['recipient_name_snapshot']})",
            "status": order["status"],
            "confirmed": order["status"] == "approved",
            "receiptUrl": "",
            "updatedAt": ts,
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_transaction",
            chat_data=chat_data,
            caption=f"<b>Order {order['order_id']}</b> — {int(order['expected_amount_uzs']):,} UZS ({order['status'].upper()})",
            markup={"inline_keyboard": [[{"text": "Open Manual Top-Up", "web_app": {"url": f"{self.config.web_base_url}/app/economy/topup"}}]]},
            entity_id=order["order_id"],
            topic_key="economy",
        )

    def send_election_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        with self.domain.store.transaction() as tx:
            elec = tx.fetchone("SELECT * FROM elections WHERE election_id = 'elec_2026_q4'")
            if not elec:
                self.client.send_message(chat_id, "No active election.")
                return
            vote = tx.fetchone(
                "SELECT candidate_id FROM election_votes WHERE election_id = ? AND user_id = ?",
                (elec["election_id"], user["id"]),
            )
        public_data = {
            "electionId": elec["election_id"],
            "title": elec["title"],
            "status": elec["status"],
            "candidates": json.loads(elec["candidates_json"]),
        }
        chat_data = {
            "eligible": int(user["level"]) >= 2,
            "votedId": vote["candidate_id"] if vote else "",
            "reason": "Official vote recorded." if vote else "Select a candidate and confirm.",
        }
        self._dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_election",
            chat_data=chat_data,
            public_data=public_data,
            caption=f"<b>{elec['title']}</b> — Status: {elec['status'].upper()}",
            markup={"inline_keyboard": [[{"text": "Election Info", "web_app": {"url": f"{self.config.web_base_url}/app/events/elections"}}]]},
            entity_id=elec["election_id"],
            topic_key="events",
        )

    def _provision_private_topics(self, chat_id: int) -> None:
        created = 0
        for key, title in PRIVATE_TOPICS:
            if self._get_topic_thread(chat_id, key):
                continue
            try:
                res = self.client.create_forum_topic(chat_id, title)
                with self.domain.store.transaction() as tx:
                    tx.execute(
                        """
                        INSERT INTO telegram_user_topics (telegram_user_id, topic_key, message_thread_id)
                        VALUES (?, ?, ?)
                        ON CONFLICT(telegram_user_id, topic_key) DO UPDATE SET message_thread_id = excluded.message_thread_id
                        """,
                        (chat_id, key, int(res["message_thread_id"])),
                    )
                created += 1
            except TelegramAPIError:
                break
        self.client.send_message(chat_id, f"Provisioned {created} CityX private topics.")

    def _handle_widget_query(self, query: Dict[str, Any], is_shared: bool) -> None:
        query_id = str(query["id"])
        data = str(query.get("data") or "")
        if len(data.encode("utf-8")) > MAX_WIDGET_QUERY_BYTES:
            self.client.answer_widget_query(query_id, "Invalid request size.")
            return
        if not self._acquire_update_idempotency(f"wq:{query_id}", ttl_seconds=120):
            self.client.answer_widget_query(query_id, "Already processed.")
            return

        user, _ = self.domain.get_or_create_telegram_user(query["from"])
        msg = query.get("message") or {}
        chat_id = int(msg.get("chat", {}).get("id", query["from"]["id"]))
        message_id = msg.get("message_id")
        inline_id = query.get("inline_message_id")

        inst = None
        if message_id is not None:
            with self.domain.store.transaction() as tx:
                inst = tx.fetchone(
                    "SELECT * FROM telegram_widget_instances WHERE chat_id = ? AND message_id = ?",
                    (chat_id, int(message_id)),
                )
            if inst and not is_shared and inst["owner_user_id"] != user["id"]:
                self.client.answer_widget_query(query_id, "Access denied: not your widget.")
                return

        state = json.loads(inst["state_json"]) if inst else {}

        try:
            if data in ("w:daily", "d:claim"):
                res = self.domain.claim_daily_reward(user["id"])
                self.client.answer_widget_query(query_id, f"Claimed +{res['coins_awarded']} CX & +{res['gems_awarded']} Gems!")
            elif data == "t:go":
                sel = int(state.get("selIdx", 1)) % len(TAXI_WIDGET_DESTINATIONS)
                dest = TAXI_WIDGET_DESTINATIONS[sel]
                res = self.domain.book_taxi(user["id"], dest["id"], request_id=f"tg_widget_{message_id or query_id}")
                self.client.answer_widget_query(query_id, f"Taxi confirmed to {res['district_name']}!")
            elif data == "tx:check":
                # Strictly read-only: NEVER marks an order approved from a widget tap.
                order_id = inst["entity_id"] if inst else ""
                orders = [o for o in self.domain.list_user_payment_orders(user["id"]) if o["order_id"] == order_id]
                status = orders[0]["status"].upper() if orders else "NOT_FOUND"
                self.client.answer_widget_query(query_id, f"Status: {status}")
            elif data == "el:cast":
                idx = state.get("pendingIdx")
                if idx is None:
                    self.client.answer_widget_query(query_id, "Select a candidate first.")
                    return
                with self.domain.store.transaction() as tx:
                    elec = tx.fetchone("SELECT candidates_json FROM elections WHERE election_id = 'elec_2026_q4'")
                cands = json.loads(elec["candidates_json"]) if elec else []
                cand = cands[int(idx)]
                self.domain.cast_election_vote(user["id"], "elec_2026_q4", cand["id"])
                self.client.answer_widget_query(query_id, f"Official vote recorded for {cand['name']}!")
            elif data.startswith("el:pick:"):
                raw_idx = data.split(":")[-1]
                if not raw_idx.isdigit():
                    self.client.answer_widget_query(query_id, "Invalid candidate index.")
                    return
                state["pendingIdx"] = int(raw_idx)
                if message_id is not None:
                    self._register_widget(chat_id, int(message_id), "cityx_election", user["id"], "elec_2026_q4", state)
                self.client.answer_widget_query(query_id, "Candidate selected. Tap Confirm.")
            else:
                self.client.answer_widget_query(query_id, "Action received.")
        except DomainError as exc:
            self.client.answer_widget_query(query_id, str(exc))

    def _handle_callback_query(self, cb: Dict[str, Any]) -> None:
        cb_id = str(cb["id"])
        if not self._acquire_update_idempotency(f"cb:{cb_id}", ttl_seconds=120):
            self.client.answer_callback_query(cb_id)
            return
        ok, action, entity_id, err = self.security.verify_callback(str(cb.get("data") or ""))
        if not ok:
            self.client.answer_callback_query(cb_id, err, show_alert=True)
            return

        user, _ = self.domain.get_or_create_telegram_user(cb["from"])
        msg = cb.get("message") or {}
        chat_id = int(msg.get("chat", {}).get("id", cb["from"]["id"]))
        chat_type = msg.get("chat", {}).get("type", "private")

        if action == "open":
            self.client.answer_callback_query(cb_id, f"Opening {entity_id}...")
            if entity_id == "dashboard":
                self.send_daily_dashboard_widget(chat_id, chat_type, user)
            elif entity_id == "taxi":
                self.send_taxi_widget(chat_id, chat_type, user)
            elif entity_id == "topup":
                self.send_manual_topup_notice(chat_id)
        elif action == "daily" and entity_id == "claim":
            try:
                res = self.domain.claim_daily_reward(user["id"])
                self.client.answer_callback_query(
                    cb_id, f"Claimed +{res['coins_awarded']} CX & +{res['gems_awarded']} Gems!", show_alert=True
                )
            except DomainError as exc:
                self.client.answer_callback_query(cb_id, str(exc), show_alert=True)
        else:
            self.client.answer_callback_query(cb_id, "Action processed.")
