from __future__ import annotations

import hashlib
import hmac
import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

_CARD_DIGITS_RE = re.compile(r"^\d{16}$")


def mask_card_number(card_number: str) -> str:
    digits = re.sub(r"\D", "", card_number or "")
    if len(digits) < 4:
        return "****"
    return f"****{digits[-4:]}"


def card_fingerprint_hmac(signing_secret: str, card_number: str) -> str:
    """Compute keyed HMAC-SHA256 fingerprint of a 16-digit card number (never stores PAN)."""
    digits = re.sub(r"\D", "", card_number or "")
    return hmac.new(signing_secret.encode("utf-8"), digits.encode("utf-8"), hashlib.sha256).hexdigest()


@dataclass(frozen=True)
class ManualCardConfig:
    code: str                   # "uzum_visa" | "uzcard"
    display_name: str
    network: str                # "Visa" | "Uzcard"
    bank_name: Optional[str]    # "Uzum Bank" for Card 1; None for Card 2 unless explicitly verified
    card_number: str            # Server-side ONLY secret; NEVER exposed in API responses, frontend, or logs
    recipient_name: str         # Exact confirmed recipient per card; never merged
    enabled: bool = True

    @property
    def card_last4(self) -> str:
        digits = re.sub(r"\D", "", self.card_number)
        return digits[-4:] if len(digits) >= 4 else "0000"

    @property
    def card_masked(self) -> str:
        return f"**** **** **** {self.card_last4}"

    def __repr__(self) -> str:
        return (
            f"ManualCardConfig(code={self.code!r}, network={self.network!r}, "
            f"bank_name={self.bank_name!r}, card={mask_card_number(self.card_number)!r}, "
            f"recipient={self.recipient_name!r}, enabled={self.enabled!r})"
        )


@dataclass(frozen=True)
class AppConfig:
    environment: str
    port: int
    host: str
    database_url: str
    sqlite_path: str
    bot_token: str
    bot_username: str
    miniapp_short_name: str
    web_base_url: str
    cors_origins: Tuple[str, ...]
    signing_secret: str
    webhook_url: str
    webhook_secret: str
    admin_telegram_ids: Tuple[str, ...]
    receipt_storage_dir: str
    manual_payment_support_handle: str
    smtp_configured: bool
    manual_cards: Dict[str, ManualCardConfig]
    ton_wallet_enabled: bool = field(default=False)

    @classmethod
    def from_env(cls) -> "AppConfig":
        raw_port = os.getenv("PORT") or os.getenv("HTTP_PORT") or "8080"
        web_url = os.getenv("CITYX_WEB_URL", "https://cityx.uz").rstrip("/")

        extra_origins = [
            o.strip().rstrip("/")
            for o in os.getenv("CITYX_EXTRA_CORS_ORIGINS", "").split(",")
            if o.strip()
        ]
        cors_origins = tuple(dict.fromkeys([web_url, *extra_origins]))

        admin_ids = tuple(
            x.strip()
            for x in os.getenv("CITYX_ADMIN_TELEGRAM_IDS", "").split(",")
            if x.strip()
        )

        # Card 1 — Visa (Uzum Bank, Abdullox Arslonov)
        visa_enabled = os.getenv("CITYX_PAYMENT_VISA_ENABLED", "true").lower() == "true"
        visa_card_raw = re.sub(r"\s+", "", os.getenv("CITYX_PAYMENT_VISA_CARD_NUMBER", ""))
        visa_bank = os.getenv("CITYX_PAYMENT_VISA_BANK_NAME", "Uzum Bank").strip() or None
        visa_recipient = os.getenv("CITYX_PAYMENT_VISA_RECIPIENT", "Abdullox Arslonov").strip()

        # Card 2 — Uzcard (issuing bank unverified -> None unless explicitly provided, Arslonov Abdulloh)
        uzcard_enabled = os.getenv("CITYX_PAYMENT_UZCARD_ENABLED", "true").lower() == "true"
        uzcard_card_raw = re.sub(r"\s+", "", os.getenv("CITYX_PAYMENT_UZCARD_CARD_NUMBER", ""))
        uzcard_bank_raw = os.getenv("CITYX_PAYMENT_UZCARD_BANK_NAME", "").strip()
        uzcard_bank = uzcard_bank_raw if uzcard_bank_raw else None
        uzcard_recipient = os.getenv("CITYX_PAYMENT_UZCARD_RECIPIENT", "Arslonov Abdulloh").strip()

        cards: Dict[str, ManualCardConfig] = {
            "uzum_visa": ManualCardConfig(
                code="uzum_visa",
                display_name="Uzum Bank — Visa",
                network=os.getenv("CITYX_PAYMENT_VISA_NETWORK", "Visa").strip(),
                bank_name=visa_bank,
                card_number=visa_card_raw,
                recipient_name=visa_recipient,
                enabled=visa_enabled,
            ),
            "uzcard": ManualCardConfig(
                code="uzcard",
                display_name="Uzcard",
                network=os.getenv("CITYX_PAYMENT_UZCARD_NETWORK", "Uzcard").strip(),
                bank_name=uzcard_bank,
                card_number=uzcard_card_raw,
                recipient_name=uzcard_recipient,
                enabled=uzcard_enabled,
            ),
        }

        cfg = cls(
            environment=os.getenv("CITYX_ENV", "production").lower(),
            port=int(raw_port),
            host=os.getenv("HTTP_HOST", "0.0.0.0"),
            database_url=os.getenv("DATABASE_URL", "").strip(),
            sqlite_path=os.getenv("CITYX_DB_PATH", "").strip(),
            bot_token=os.getenv("BOT_TOKEN", "").strip(),
            bot_username=os.getenv("BOT_USERNAME", "cityx_bot").strip(),
            miniapp_short_name=os.getenv("MINIAPP_SHORT_NAME", "app").strip(),
            web_base_url=web_url,
            cors_origins=cors_origins,
            signing_secret=os.getenv("CITYX_SIGNING_SECRET", "").strip(),
            webhook_url=os.getenv("WEBHOOK_URL", "").strip().rstrip("/"),
            webhook_secret=os.getenv("WEBHOOK_SECRET", "").strip(),
            admin_telegram_ids=admin_ids,
            receipt_storage_dir=os.getenv("CITYX_RECEIPT_STORAGE_DIR", "").strip(),
            manual_payment_support_handle=os.getenv("CITYX_PAYMENT_SUPPORT_HANDLE", "@cityx_bot").strip(),
            smtp_configured=bool(os.getenv("SMTP_HOST", "").strip()),
            manual_cards=cards,
            ton_wallet_enabled=False,
        )
        cfg.validate_runtime_invariants()
        return cfg

    def validate_runtime_invariants(self) -> None:
        if self.ton_wallet_enabled:
            raise RuntimeError("SECURITY VIOLATION: TON wallet must remain disabled.")
        if self.environment == "production" and not self.database_url:
            raise RuntimeError(
                "DATABASE_URL (PostgreSQL) is required in production; SQLite is not permitted on Render."
            )
        if self.environment == "production" and len(self.signing_secret) < 32:
            raise RuntimeError("CITYX_SIGNING_SECRET must be at least 32 characters in production.")
        for code, card in self.manual_cards.items():
            if card.enabled:
                if not _CARD_DIGITS_RE.match(card.card_number):
                    raise ValueError(
                        f"Enabled manual payment card '{code}' requires a valid 16-digit server-side card number."
                    )
                if not card.recipient_name:
                    raise ValueError(f"Enabled manual payment card '{code}' requires a recipient name.")

    def active_manual_cards(self) -> List[ManualCardConfig]:
        return [c for c in self.manual_cards.values() if c.enabled]
