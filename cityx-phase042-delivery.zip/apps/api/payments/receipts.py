from __future__ import annotations

import hashlib
import os
import re
import uuid
from dataclasses import dataclass
from typing import Optional

MAX_RECEIPT_BYTES = 5 * 1024 * 1024  # 5 MB
_ORDER_ID_RE = re.compile(r"^[A-Za-z0-9_-]{4,64}$")

_MAGIC_SIGNATURES = (
    (b"\x89PNG\r\n\x1a\n", "image/png", "png"),
    (b"\xff\xd8\xff", "image/jpeg", "jpg"),
    (b"%PDF-", "application/pdf", "pdf"),
)


class ReceiptValidationError(ValueError):
    pass


@dataclass(frozen=True)
class ValidatedReceipt:
    object_key: str
    mime_type: str
    extension: str
    sha256: str
    size_bytes: int


def validate_receipt_bytes(raw_bytes: bytes, order_id: str) -> ValidatedReceipt:
    """
    Validate receipt upload strictly by size and magic bytes.
    Rejects arbitrary URLs, SVG/HTML/script payloads, empty files, and >5 MB uploads.
    """
    if not isinstance(raw_bytes, (bytes, bytearray)):
        raise ReceiptValidationError("Receipt payload must be binary bytes.")
    data = bytes(raw_bytes)
    size = len(data)
    if size == 0:
        raise ReceiptValidationError("Receipt file is empty.")
    if size > MAX_RECEIPT_BYTES:
        raise ReceiptValidationError(f"Receipt file exceeds maximum size of {MAX_RECEIPT_BYTES} bytes.")
    if not _ORDER_ID_RE.match(order_id):
        raise ReceiptValidationError("Invalid order_id for receipt storage.")

    mime: Optional[str] = None
    ext: Optional[str] = None
    if size >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        mime, ext = "image/webp", "webp"
    else:
        for sig, m, e in _MAGIC_SIGNATURES:
            if data.startswith(sig):
                mime, ext = m, e
                break

    if not mime or not ext:
        raise ReceiptValidationError(
            "Unsupported receipt file signature. Allowed binary formats: PNG, JPEG, WebP, PDF."
        )

    sha256_hex = hashlib.sha256(data).hexdigest()
    # Opaque server-generated key — never trusts user filename or user-supplied URLs.
    object_key = f"receipts/{order_id}/{uuid.uuid4().hex}.{ext}"
    return ValidatedReceipt(
        object_key=object_key,
        mime_type=mime,
        extension=ext,
        sha256=sha256_hex,
        size_bytes=size,
    )


def save_receipt_privately(storage_dir: str, receipt: ValidatedReceipt, raw_bytes: bytes) -> str:
    """Write validated receipt into private local storage directory with path-prefix guard."""
    base = os.path.abspath(storage_dir)
    dest = os.path.abspath(os.path.join(base, receipt.object_key))
    if not dest.startswith(base + os.sep):
        raise ReceiptValidationError("Invalid receipt storage path.")
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "wb") as f:
        f.write(raw_bytes)
    return dest
