from __future__ import annotations

import datetime
import hashlib
import hmac
import json
import re
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from apps.api.auth.tokens import hash_password_pbkdf2, verify_password_pbkdf2
from apps.api.config import AppConfig, ManualCardConfig, card_fingerprint_hmac
from apps.api.db.store import CityXStore, TransactionCursor, is_unique_violation
from apps.api.payments.receipts import (
    ReceiptValidationError,
    save_receipt_privately,
    validate_receipt_bytes,
)

GENESIS_HASH = "0" * 64
BANNED_WORDS = {"spam", "scam", "hack", "exploit", "abuse"}

TAXI_FARES_BY_DISTRICT: Dict[str, Tuple[int, int]] = {
    "residential": (100, 2),
    "university": (120, 2),
    "business": (150, 3),
    "nature": (140, 3),
    "downtown": (120, 2),
    "entertainment": (160, 3),
    "transport": (130, 3),
    "vip": (220, 4),
}


class DomainError(Exception):
    status_code = 400


class UnauthorizedError(DomainError):
    status_code = 401


class PaymentRequiredError(DomainError):
    status_code = 402


class ForbiddenError(DomainError):
    status_code = 403


class NotFoundError(DomainError):
    status_code = 404


class ConflictError(DomainError):
    status_code = 409


def _compute_chain_hash(prev_hash: str, payload: Dict[str, Any]) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(f"{prev_hash}|{canonical}".encode("utf-8")).hexdigest()


class CityXDomainService:
    """
    Unified, transaction-safe CityX domain service shared across Website,
    Telegram Mini App, Telegram Bot, and Admin Dashboard.
    Preserves legacy 20-table CityXService mechanics while adding Phase 0.3
    hardening, replay-safe idempotency, hash-chained append-only audits, and
    dual-card manual bank transfers.
    """

    def __init__(self, config: AppConfig, store: CityXStore) -> None:
        self.config = config
        self.store = store

    # ------------------------------------------------------------------
    # Hash-Chained Append-Only Audit Helpers
    # ------------------------------------------------------------------
    def _append_payment_audit_in_tx(
        self,
        tx: TransactionCursor,
        *,
        order_id: str,
        actor_user_id: str,
        event_type: str,
        details: Dict[str, Any],
        now: int,
    ) -> None:
        last = tx.fetchone(
            "SELECT entry_hash FROM payment_audit_logs WHERE order_id = ? ORDER BY id DESC LIMIT 1",
            (order_id,),
        )
        prev_hash = last["entry_hash"] if last and last["entry_hash"] else GENESIS_HASH
        details_json = json.dumps(details, sort_keys=True, separators=(",", ":"))
        entry_hash = _compute_chain_hash(
            prev_hash,
            {
                "order_id": order_id,
                "actor_user_id": actor_user_id,
                "event_type": event_type,
                "details_json": details_json,
                "created_at": now,
            },
        )
        tx.execute(
            """
            INSERT INTO payment_audit_logs
            (order_id, actor_user_id, event_type, details_json, prev_hash, entry_hash, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (order_id, actor_user_id, event_type, details_json, prev_hash, entry_hash, now),
        )

    def _append_admin_audit_in_tx(
        self,
        tx: TransactionCursor,
        *,
        admin_user_id: str,
        action: str,
        target_type: str,
        target_entity: str,
        before_state: Dict[str, Any],
        after_state: Dict[str, Any],
        reason: str,
        now: int,
    ) -> str:
        last = tx.fetchone(
            "SELECT entry_hash FROM admin_audit_logs WHERE entry_hash <> '' ORDER BY created_ts DESC, id DESC LIMIT 1"
        )
        prev_hash = last["entry_hash"] if last and last["entry_hash"] else GENESIS_HASH
        audit_id = f"aud_{uuid.uuid4().hex[:12]}"
        before_json = json.dumps(before_state, sort_keys=True, separators=(",", ":"))
        after_json = json.dumps(after_state, sort_keys=True, separators=(",", ":"))
        details_json = json.dumps({"reason": reason, "before": before_state, "after": after_state}, sort_keys=True, separators=(",", ":"))
        entry_hash = _compute_chain_hash(
            prev_hash,
            {
                "id": audit_id,
                "admin_user_id": admin_user_id,
                "action": action,
                "target_type": target_type,
                "target_entity": target_entity,
                "before_json": before_json,
                "after_json": after_json,
                "reason": reason,
                "created_ts": now,
            },
        )
        tx.execute(
            """
            INSERT INTO admin_audit_logs
            (id, admin_user_id, action, target_entity, details_json,
             target_type, before_json, after_json, reason, prev_hash, entry_hash, created_ts)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                audit_id,
                admin_user_id,
                action,
                target_entity,
                details_json,
                target_type,
                before_json,
                after_json,
                reason,
                prev_hash,
                entry_hash,
                now,
            ),
        )
        return audit_id

    def verify_payment_audit_chain(self, order_id: str) -> bool:
        """Verify SHA-256 hash chain integrity for an order's payment audit log."""
        with self.store.transaction() as tx:
            rows = tx.fetchall(
                "SELECT * FROM payment_audit_logs WHERE order_id = ? ORDER BY id ASC",
                (order_id,),
            )
        prev = GENESIS_HASH
        for row in rows:
            if row["prev_hash"] != prev:
                return False
            expected = _compute_chain_hash(
                prev,
                {
                    "order_id": row["order_id"],
                    "actor_user_id": row["actor_user_id"],
                    "event_type": row["event_type"],
                    "details_json": row["details_json"],
                    "created_at": int(row["created_at"]),
                },
            )
            if not hmac.compare_digest(expected, row["entry_hash"]):
                return False
            prev = row["entry_hash"]
        return True

    # ------------------------------------------------------------------
    # Unified Identity (Local Web + Telegram Bot + Mini App) & Sessions
    # ------------------------------------------------------------------
    def _fetch_user_view_in_tx(self, tx: TransactionCursor, user_id: str) -> Optional[Dict[str, Any]]:
        return tx.fetchone(
            """
            SELECT u.id, u.username, u.email, u.auth_provider, u.telegram_id, u.role, u.is_banned,
                   p.display_name, p.instagram_handle, p.avatar_url, p.bio, p.language,
                   p.district_id, p.coins, p.gems,
                   p.reputation_score, p.level, p.streak, p.last_daily_claim, p.classic_mode, p.notify_prefs
            FROM users u
            JOIN profiles p ON p.user_id = u.id
            WHERE u.id = ?
            """,
            (user_id,),
        )

    def get_user_view(self, user_id: str) -> Optional[Dict[str, Any]]:
        with self.store.transaction() as tx:
            return self._fetch_user_view_in_tx(tx, user_id)

    def register_local_user(
        self,
        *,
        username: str,
        password: str,
        instagram_handle: str = "",
        district_id: str = "residential",
        role: str = "user",
        starter_coins: int = 10000,
        starter_gems: int = 25,
    ) -> Dict[str, Any]:
        clean = re.sub(r"[^a-zA-Z0-9._]", "", username).lower()
        if len(clean) < 3 or len(clean) > 24:
            raise DomainError("Username must be 3-24 valid characters")
        if role not in ("user", "moderator", "admin"):
            raise DomainError("Invalid role")

        uid = f"usr_{uuid.uuid4().hex[:12]}"
        home_id = f"hom_{uuid.uuid4().hex[:10]}"
        plot_code = f"P-{uuid.uuid4().hex[:6].upper()}"
        now = int(time.time())
        try:
            with self.store.transaction() as tx:
                dist = tx.fetchone("SELECT id FROM districts WHERE id = ?", (district_id,))
                if not dist:
                    raise DomainError("Invalid canonical district_id")
                tx.execute(
                    "INSERT INTO users (id, username, password_hash, auth_provider, role) VALUES (?, ?, ?, 'local', ?)",
                    (uid, clean, hash_password_pbkdf2(password), role),
                )
                tx.execute(
                    """
                    INSERT INTO profiles (user_id, display_name, instagram_handle, district_id, coins, gems)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (uid, clean, instagram_handle.lstrip("@"), district_id, starter_coins, starter_gems),
                )
                tx.execute(
                    "INSERT INTO user_identities (user_id, provider, external_id, verified_at) VALUES (?, 'local', ?, ?)",
                    (uid, clean, now),
                )
                tx.execute(
                    "INSERT INTO homes (id, user_id, district_id, plot_code, floors) VALUES (?, ?, ?, ?, 2)",
                    (home_id, uid, district_id, plot_code),
                )
                user = self._fetch_user_view_in_tx(tx, uid)
                assert user is not None
                return {"user": user, "home_id": home_id, "plot_code": plot_code}
        except Exception as exc:
            if is_unique_violation(exc):
                raise ConflictError("Username already taken") from exc
            raise

    def authenticate_local_user(self, username: str, password: str) -> Dict[str, Any]:
        clean = re.sub(r"[^a-zA-Z0-9._]", "", username).lower()
        with self.store.transaction() as tx:
            row = tx.fetchone("SELECT id, password_hash, is_banned FROM users WHERE username = ?", (clean,))
            if not row or not verify_password_pbkdf2(password, row["password_hash"] or ""):
                raise UnauthorizedError("Invalid username or password.")
            if int(row["is_banned"]):
                raise ForbiddenError("Account is banned.")
            user = self._fetch_user_view_in_tx(tx, row["id"])
            assert user is not None
            return user

    def get_or_create_telegram_user(self, tg_user: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        tg_id = str(tg_user["id"])
        raw_name = (tg_user.get("username") or tg_user.get("first_name") or f"citizen_{tg_id[-4:]}").strip()
        clean_base = re.sub(r"[^a-zA-Z0-9._]", "", raw_name).lower()[:18] or f"tg_{tg_id[-6:]}"
        is_bootstrap_admin = tg_id in self.config.admin_telegram_ids
        now = int(time.time())

        with self.store.transaction() as tx:
            ident = tx.fetchone(
                "SELECT user_id FROM user_identities WHERE provider = 'telegram' AND external_id = ?",
                (tg_id,),
            )
            if ident:
                user_row = tx.fetchone("SELECT * FROM users WHERE id = ? FOR UPDATE", (ident["user_id"],))
                assert user_row is not None
                new_role = "admin" if is_bootstrap_admin else user_row["role"]
                if user_row["role"] != new_role:
                    tx.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_row["id"]))
                view = self._fetch_user_view_in_tx(tx, user_row["id"])
                assert view is not None
                return view, False

            # Check legacy users.telegram_id before creating a new user
            legacy = tx.fetchone("SELECT * FROM users WHERE telegram_id = ? FOR UPDATE", (tg_id,))
            if legacy:
                tx.execute(
                    "INSERT INTO user_identities (user_id, provider, external_id, verified_at) VALUES (?, 'telegram', ?, ?)",
                    (legacy["id"], tg_id, now),
                )
                view = self._fetch_user_view_in_tx(tx, legacy["id"])
                assert view is not None
                return view, False

            uid = f"cx_{uuid.uuid4().hex[:14]}"
            username = clean_base
            if tx.fetchone("SELECT 1 FROM users WHERE username = ?", (username,)):
                username = f"{clean_base[:14]}_{tg_id[-4:]}"
            role = "admin" if is_bootstrap_admin else "user"
            tx.execute(
                "INSERT INTO users (id, username, auth_provider, telegram_id, role) VALUES (?, ?, 'telegram', ?, ?)",
                (uid, username, tg_id, role),
            )
            tx.execute(
                """
                INSERT INTO profiles (user_id, display_name, district_id, coins, gems, level, streak)
                VALUES (?, ?, 'downtown', 1000, 25, 2, 1)
                """,
                (uid, raw_name[:40],),
            )
            tx.execute(
                "INSERT INTO user_identities (user_id, provider, external_id, verified_at) VALUES (?, 'telegram', ?, ?)",
                (uid, tg_id, now),
            )
            # Provision starter home & vehicles cleanly (NO fake pending payment orders!)
            tx.execute(
                "INSERT INTO homes (id, user_id, district_id, plot_code, floors) VALUES (?, ?, 'downtown', ?, 2)",
                (f"hom_{uid[-8:]}", uid, f"P-{uuid.uuid4().hex[:6].upper()}"),
            )
            tx.execute(
                """
                INSERT INTO vehicles (id, user_id, model_code, display_name, vehicle_class, rating, upgrade_pct, energy_pct)
                VALUES (?, ?, 'cobalt', 'CityX Volt GT', 'S-CLASS', 842, 65, 75)
                """,
                (f"veh_{uid[-6:]}_1", uid),
            )
            tx.execute(
                """
                INSERT INTO vehicles (id, user_id, model_code, display_name, vehicle_class, rating, upgrade_pct, energy_pct)
                VALUES (?, ?, 'malibu_xl', 'Samarkand Drift X', 'A-CLASS', 715, 45, 90)
                """,
                (f"veh_{uid[-6:]}_2", uid),
            )
            view = self._fetch_user_view_in_tx(tx, uid)
            assert view is not None
            return view, True

    def create_session(self, user_id: str, jti: str, expires_at: int) -> str:
        session_id = f"sess_{uuid.uuid4().hex}"
        now = int(time.time())
        with self.store.transaction() as tx:
            tx.execute(
                "INSERT INTO sessions (session_id, user_id, token_jti, expires_at, created_at) VALUES (?, ?, ?, ?, ?)",
                (session_id, user_id, jti, expires_at, now),
            )
        return session_id

    def revoke_session(self, user_id: str, jti: str) -> None:
        now = int(time.time())
        with self.store.transaction() as tx:
            tx.execute(
                "UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND token_jti = ? AND revoked_at IS NULL",
                (now, user_id, jti),
            )

    def get_active_user_for_token(self, user_id: str, jti: str) -> Optional[Dict[str, Any]]:
        now = int(time.time())
        with self.store.transaction() as tx:
            sess = tx.fetchone(
                """
                SELECT session_id FROM sessions
                WHERE user_id = ? AND token_jti = ? AND revoked_at IS NULL AND expires_at > ?
                """,
                (user_id, jti, now),
            )
            if not sess:
                return None
            view = self._fetch_user_view_in_tx(tx, user_id)
            if not view or int(view["is_banned"]):
                return None
            return view

    # ------------------------------------------------------------------
    # Atomic Economy Ledger (Zero f-string SQL, Hash-Chained, Non-Negative)
    # ------------------------------------------------------------------
    def _apply_balance_delta_in_tx(
        self,
        tx: TransactionCursor,
        *,
        user_id: str,
        currency: str,
        delta: int,
        reason: str,
        ref_type: str,
        ref_id: str,
        idempotency_key: str,
    ) -> Dict[str, Any]:
        if currency not in ("coins", "gems"):
            raise DomainError("Unsupported virtual currency.")
        if type(delta) is not int or delta == 0:
            raise DomainError("Balance delta must be a non-zero integer.")

        existing = tx.fetchone("SELECT id FROM economy_ledger WHERE idempotency_key = ?", (idempotency_key,))
        if existing:
            raise ConflictError("Duplicate economy ledger operation blocked.")

        prof = tx.fetchone("SELECT coins, gems FROM profiles WHERE user_id = ? FOR UPDATE", (user_id,))
        if not prof:
            raise NotFoundError("User profile not found.")

        if currency == "coins":
            new_balance = int(prof["coins"]) + delta
            if new_balance < 0:
                raise ConflictError("Insufficient coins balance.")
            tx.execute(
                "UPDATE profiles SET coins = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND coins + ? >= 0",
                (new_balance, user_id, delta),
            )
        else:
            new_balance = int(prof["gems"]) + delta
            if new_balance < 0:
                raise ConflictError("Insufficient gems balance.")
            tx.execute(
                "UPDATE profiles SET gems = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND gems + ? >= 0",
                (new_balance, user_id, delta),
            )

        if tx.rowcount != 1:
            raise ConflictError(f"Atomic {currency} balance update failed.")

        last = tx.fetchone(
            "SELECT entry_hash FROM economy_ledger WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 1",
            (user_id,),
        )
        prev_hash = last["entry_hash"] if last and last["entry_hash"] else GENESIS_HASH
        ledger_id = f"led_{uuid.uuid4().hex[:16]}"
        now = int(time.time())
        entry_hash = _compute_chain_hash(
            prev_hash,
            {
                "id": ledger_id,
                "user_id": user_id,
                "currency": currency,
                "delta": delta,
                "balance_after": new_balance,
                "reason": reason,
                "ref_type": ref_type,
                "ref_id": ref_id,
                "idempotency_key": idempotency_key,
                "created_at": now,
            },
        )
        tx.execute(
            """
            INSERT INTO economy_ledger
            (id, user_id, currency, delta, balance_after, reason, ref_type, ref_id,
             idempotency_key, prev_hash, entry_hash, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (ledger_id, user_id, currency, delta, new_balance, reason, ref_type, ref_id, idempotency_key, prev_hash, entry_hash, now),
        )
        rec = tx.fetchone("SELECT * FROM economy_ledger WHERE id = ?", (ledger_id,))
        assert rec is not None
        return rec

    # ------------------------------------------------------------------
    # Daily Reward (Atomic + Shared Across Bot Widgets, Classic, Web)
    # ------------------------------------------------------------------
    def claim_daily_reward(self, user_id: str) -> Dict[str, Any]:
        tz_uz = datetime.timezone(datetime.timedelta(hours=5))
        today = datetime.datetime.now(tz_uz).strftime("%Y-%m-%d")
        with self.store.transaction() as tx:
            prof = tx.fetchone("SELECT * FROM profiles WHERE user_id = ? FOR UPDATE", (user_id,))
            if not prof:
                raise NotFoundError("Profile not found.")
            if prof["last_daily_claim"] == today:
                raise ConflictError("Daily reward already claimed today.")
            tx.execute(
                "UPDATE profiles SET streak = streak + 1, last_daily_claim = ? WHERE user_id = ? AND last_daily_claim <> ?",
                (today, user_id, today),
            )
            if tx.rowcount != 1:
                raise ConflictError("Daily reward already claimed today.")
            coins_tx = self._apply_balance_delta_in_tx(
                tx,
                user_id=user_id,
                currency="coins",
                delta=150,
                reason="daily_reward",
                ref_type="daily",
                ref_id=today,
                idempotency_key=f"daily:coins:{user_id}:{today}",
            )
            gems_tx = self._apply_balance_delta_in_tx(
                tx,
                user_id=user_id,
                currency="gems",
                delta=2,
                reason="daily_reward",
                ref_type="daily",
                ref_id=today,
                idempotency_key=f"daily:gems:{user_id}:{today}",
            )
            return {
                "date": today,
                "coins_awarded": 150,
                "gems_awarded": 2,
                "coins_balance": int(coins_tx["balance_after"]),
                "gems_balance": int(gems_tx["balance_after"]),
            }

    # ------------------------------------------------------------------
    # Replay-Safe Taxi Booking (Canonical 8 Districts + True Idempotency)
    # ------------------------------------------------------------------
    def book_taxi(self, user_id: str, destination_district_id: str, request_id: str) -> Dict[str, Any]:
        req_id = request_id.strip()
        if len(req_id) < 4 or len(req_id) > 128:
            raise DomainError("request_id must be 4-128 characters.")
        if destination_district_id not in TAXI_FARES_BY_DISTRICT:
            raise DomainError("Invalid canonical district destination.")
        fare, eta_min = TAXI_FARES_BY_DISTRICT[destination_district_id]

        try:
            with self.store.transaction() as tx:
                existing = tx.fetchone(
                    "SELECT * FROM taxi_rides WHERE user_id = ? AND request_id = ?",
                    (user_id, req_id),
                )
                if existing:
                    if existing["destination_district_id"] != destination_district_id:
                        raise ConflictError(
                            "Idempotency key reuse with a different destination_district_id is prohibited."
                        )
                    return {
                        "ride_id": existing["id"],
                        "request_id": existing["request_id"],
                        "district_id": existing["destination_district_id"],
                        "district_name": existing["district_name"],
                        "fare_coins": int(existing["fare_coins"]),
                        "eta_min": int(existing["eta_min"]),
                        "balance_after": int(existing["balance_after"]),
                        "idempotent_replay": True,
                    }

                district = tx.fetchone("SELECT id, name FROM districts WHERE id = ?", (destination_district_id,))
                if not district:
                    raise NotFoundError("District not found.")

                ledger = self._apply_balance_delta_in_tx(
                    tx,
                    user_id=user_id,
                    currency="coins",
                    delta=-fare,
                    reason="taxi_fare",
                    ref_type="district",
                    ref_id=destination_district_id,
                    idempotency_key=f"taxi:{user_id}:{req_id}",
                )
                tx.execute(
                    "UPDATE profiles SET district_id = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
                    (destination_district_id, user_id),
                )
                ride_id = f"tax_{uuid.uuid4().hex[:12]}"
                now = int(time.time())
                tx.execute(
                    """
                    INSERT INTO taxi_rides
                    (id, user_id, request_id, destination_district_id, district_name,
                     fare_coins, eta_min, balance_after, ledger_id, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ride_id,
                        user_id,
                        req_id,
                        destination_district_id,
                        district["name"],
                        fare,
                        eta_min,
                        int(ledger["balance_after"]),
                        ledger["id"],
                        now,
                    ),
                )
                return {
                    "ride_id": ride_id,
                    "request_id": req_id,
                    "district_id": destination_district_id,
                    "district_name": district["name"],
                    "fare_coins": fare,
                    "eta_min": eta_min,
                    "balance_after": int(ledger["balance_after"]),
                    "idempotent_replay": False,
                }
        except Exception as exc:
            if is_unique_violation(exc):
                # Re-read winning concurrent ride cleanly
                with self.store.transaction() as tx:
                    existing = tx.fetchone(
                        "SELECT * FROM taxi_rides WHERE user_id = ? AND request_id = ?",
                        (user_id, req_id),
                    )
                    if existing and existing["destination_district_id"] == destination_district_id:
                        return {
                            "ride_id": existing["id"],
                            "request_id": existing["request_id"],
                            "district_id": existing["destination_district_id"],
                            "district_name": existing["district_name"],
                            "fare_coins": int(existing["fare_coins"]),
                            "eta_min": int(existing["eta_min"]),
                            "balance_after": int(existing["balance_after"]),
                            "idempotent_replay": True,
                        }
                raise ConflictError("Concurrent taxi idempotency conflict.") from exc
            raise

    # ------------------------------------------------------------------
    # Fixed Election Voting (Explicit State Machine + Concurrency Safe)
    # ------------------------------------------------------------------
    def cast_election_vote(self, user_id: str, election_id: str, candidate_id: str) -> Dict[str, Any]:
        now = int(time.time())
        try:
            with self.store.transaction() as tx:
                prof = tx.fetchone("SELECT level FROM profiles WHERE user_id = ?", (user_id,))
                if not prof:
                    raise NotFoundError("Profile not found.")
                if int(prof["level"]) < 2:
                    raise ForbiddenError("Citizen Level 2+ required to vote.")

                elec = tx.fetchone("SELECT * FROM elections WHERE election_id = ? FOR UPDATE", (election_id,))
                if not elec:
                    raise NotFoundError("Election not found.")
                if elec["status"] != "open":
                    raise ConflictError(f"Election is not open for voting (status={elec['status']}).")

                candidates = json.loads(elec["candidates_json"])
                if candidate_id not in {c["id"] for c in candidates}:
                    raise DomainError("Invalid candidate_id.")

                tx.execute(
                    "INSERT INTO election_votes (election_id, user_id, candidate_id, voted_at) VALUES (?, ?, ?, ?)",
                    (election_id, user_id, candidate_id, now),
                )
                return {"election_id": election_id, "candidate_id": candidate_id, "voted_at": now}
        except Exception as exc:
            if is_unique_violation(exc):
                raise ConflictError("User has already voted in this election.") from exc
            raise

    # ------------------------------------------------------------------
    # Dual-Card Manual Bank-Transfer Payments (Snapshot-Safe + Admin-Only)
    # ------------------------------------------------------------------
    def list_payment_methods(self) -> List[Dict[str, Any]]:
        """Expose both confirmed manual cards independently; never merge recipients or guess Uzcard bank."""
        return [
            {
                "code": card.code,
                "display_name": card.display_name,
                "network": card.network,
                "bank_name": card.bank_name,
                "recipient_name": card.recipient_name,
                "card_last4": card.card_last4,
                "card_masked": card.card_masked,
                "enabled": card.enabled,
            }
            for card in self.config.active_manual_cards()
        ]

    def list_payment_packages(self) -> List[Dict[str, Any]]:
        with self.store.transaction() as tx:
            return tx.fetchall(
                "SELECT id, title, reward_currency, reward_amount, price_uzs FROM payment_packages WHERE is_active = TRUE ORDER BY price_uzs ASC"
            )

    def _get_enabled_card(self, method_code: str) -> ManualCardConfig:
        card = self.config.manual_cards.get(method_code)
        if not card or not card.enabled:
            raise DomainError("Selected manual payment method is unavailable.")
        return card

    def _build_snapshot_transfer_instructions(self, order: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build transfer instructions strictly from the order's stored snapshot.
        Full card number is surfaced ONLY when live server env still matches the
        exact stored HMAC fingerprint, recipient, network, and bank name.
        Prevents silent card substitution after config rotation or disable.
        """
        method_code = order["payment_method_code"]
        live_card = self.config.manual_cards.get(method_code)
        live_matches = (
            live_card is not None
            and live_card.enabled
            and live_card.recipient_name == order["recipient_name_snapshot"]
            and live_card.bank_name == order["payment_bank_snapshot"]
            and live_card.network == order["payment_network_snapshot"]
            and hmac.compare_digest(
                card_fingerprint_hmac(self.config.signing_secret, live_card.card_number),
                order["card_fingerprint_hmac"],
            )
        )
        # STRICT SECURITY RULE: NEVER expose full card numbers in API responses, frontend, or logs.
        return {
            "order_id": order["order_id"],
            "payment_method_code": method_code,
            "network": order["payment_network_snapshot"],
            "bank_name": order["payment_bank_snapshot"],
            "recipient_name": order["recipient_name_snapshot"],
            "card_last4": order["card_last4_snapshot"],
            "card_masked": f"**** **** **** {order['card_last4_snapshot']}",
            "card_config_changed": not live_matches,
            "expected_amount_uzs": int(order["expected_amount_uzs"]),
            "reward_currency": order["reward_currency"],
            "reward_amount": int(order["reward_amount"]),
            "transfer_channel_notice": (
                f"Full card numbers are kept strictly server-side. Confirm transfer details via "
                f"{self.config.manual_payment_support_handle} using masked card ending {order['card_last4_snapshot']} "
                f"({order['recipient_name_snapshot']})."
            ),
            "verification_notice": (
                "Transfer the exact UZS amount externally, upload your receipt or submit your transaction reference. "
                "Virtual currency is credited only after manual administrator verification."
            ),
        }

    def create_manual_payment_order(
        self,
        *,
        user_id: str,
        package_id: str,
        payment_method_code: str,
        idempotency_key: str,
    ) -> Dict[str, Any]:
        idem = idempotency_key.strip()
        if len(idem) < 4 or len(idem) > 200:
            raise DomainError("idempotency_key must be 4-200 characters.")
        if payment_method_code not in ("uzum_visa", "uzcard"):
            raise DomainError("payment_method_code must be 'uzum_visa' or 'uzcard'.")

        now = int(time.time())
        try:
            with self.store.transaction() as tx:
                existing = tx.fetchone(
                    "SELECT * FROM payment_orders WHERE user_id = ? AND idempotency_key = ?",
                    (user_id, idem),
                )
                if existing:
                    if (
                        existing["package_id"] != package_id
                        or existing["payment_method_code"] != payment_method_code
                    ):
                        raise ConflictError(
                            "Idempotency key already used with different package_id or payment_method_code."
                        )
                    return {
                        "order": existing,
                        "transfer_instructions": self._build_snapshot_transfer_instructions(existing),
                        "idempotent_replay": True,
                    }

                card = self._get_enabled_card(payment_method_code)
                pkg = tx.fetchone(
                    "SELECT * FROM payment_packages WHERE id = ? AND is_active = TRUE", (package_id,)
                )
                if not pkg:
                    raise NotFoundError("Payment package not found.")

                order_id = f"CX-{uuid.uuid4().hex[:10].upper()}"
                fingerprint = card_fingerprint_hmac(self.config.signing_secret, card.card_number)
                tx.execute(
                    """
                    INSERT INTO payment_orders (
                        order_id, user_id, package_id,
                        payment_method_code, payment_network_snapshot, payment_bank_snapshot,
                        recipient_name_snapshot, card_last4_snapshot, card_fingerprint_hmac,
                        expected_amount_uzs, reward_currency, reward_amount,
                        status, idempotency_key, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
                    """,
                    (
                        order_id,
                        user_id,
                        pkg["id"],
                        card.code,
                        card.network,
                        card.bank_name,
                        card.recipient_name,
                        card.card_last4,
                        fingerprint,
                        int(pkg["price_uzs"]),
                        pkg["reward_currency"],
                        int(pkg["reward_amount"]),
                        idem,
                        now,
                        now,
                    ),
                )
                self._append_payment_audit_in_tx(
                    tx,
                    order_id=order_id,
                    actor_user_id=user_id,
                    event_type="order_created",
                    details={
                        "package_id": pkg["id"],
                        "payment_method_code": card.code,
                        "card_last4": card.card_last4,
                        "recipient_name": card.recipient_name,
                        "expected_amount_uzs": int(pkg["price_uzs"]),
                    },
                    now=now,
                )
                order = tx.fetchone("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,))
                assert order is not None
                return {
                    "order": order,
                    "transfer_instructions": self._build_snapshot_transfer_instructions(order),
                    "idempotent_replay": False,
                }
        except Exception as exc:
            if is_unique_violation(exc):
                with self.store.transaction() as tx:
                    existing = tx.fetchone(
                        "SELECT * FROM payment_orders WHERE user_id = ? AND idempotency_key = ?",
                        (user_id, idem),
                    )
                    if (
                        existing
                        and existing["package_id"] == package_id
                        and existing["payment_method_code"] == payment_method_code
                    ):
                        return {
                            "order": existing,
                            "transfer_instructions": self._build_snapshot_transfer_instructions(existing),
                            "idempotent_replay": True,
                        }
                raise ConflictError("Concurrent payment idempotency conflict.") from exc
            raise

    def upload_manual_payment_receipt(
        self,
        *,
        order_id: str,
        user_id: str,
        raw_bytes: bytes,
    ) -> Dict[str, Any]:
        """Validate binary receipt by magic bytes & size; never credits currency."""
        try:
            validated = validate_receipt_bytes(raw_bytes, order_id)
        except ReceiptValidationError as exc:
            raise DomainError(str(exc)) from exc

        now = int(time.time())
        with self.store.transaction() as tx:
            order = tx.fetchone(
                "SELECT * FROM payment_orders WHERE order_id = ? FOR UPDATE", (order_id,)
            )
            if not order:
                raise NotFoundError("Payment order not found.")
            if order["user_id"] != user_id:
                raise ForbiddenError("Cannot attach a receipt to another user's order.")
            if order["status"] not in ("pending", "pending_review"):
                raise ConflictError(f"Cannot upload receipt for order in status '{order['status']}'.")

            if self.config.receipt_storage_dir:
                save_receipt_privately(self.config.receipt_storage_dir, validated, raw_bytes)

            tx.execute(
                """
                UPDATE payment_orders
                SET receipt_object_key = ?,
                    receipt_mime_type = ?,
                    receipt_sha256 = ?,
                    receipt_size_bytes = ?,
                    updated_at = ?
                WHERE order_id = ?
                """,
                (
                    validated.object_key,
                    validated.mime_type,
                    validated.sha256,
                    validated.size_bytes,
                    now,
                    order_id,
                ),
            )
            self._append_payment_audit_in_tx(
                tx,
                order_id=order_id,
                actor_user_id=user_id,
                event_type="receipt_uploaded",
                details={
                    "object_key": validated.object_key,
                    "mime_type": validated.mime_type,
                    "sha256": validated.sha256,
                    "size_bytes": validated.size_bytes,
                },
                now=now,
            )
            updated = tx.fetchone("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,))
            assert updated is not None
            return updated

    def submit_manual_payment_proof(
        self,
        *,
        order_id: str,
        user_id: str,
        submitted_reference: str,
    ) -> Dict[str, Any]:
        """
        Mark order pending_review after user submits banking reference.
        Rejects arbitrary URL strings; receipts must use upload_manual_payment_receipt().
        NEVER credits currency.
        """
        ref = submitted_reference.strip()
        if len(ref) < 3 or len(ref) > 128:
            raise DomainError("Transaction reference must be between 3 and 128 characters.")
        if re.search(r"(https?://|javascript:|data:|file://)", ref, re.I):
            raise DomainError("Transaction reference must not contain URLs or scripts.")

        now = int(time.time())
        with self.store.transaction() as tx:
            order = tx.fetchone(
                "SELECT * FROM payment_orders WHERE order_id = ? FOR UPDATE", (order_id,)
            )
            if not order:
                raise NotFoundError("Payment order not found.")
            if order["user_id"] != user_id:
                raise ForbiddenError("Cannot submit proof for another user's order.")
            if order["status"] != "pending":
                raise ConflictError(f"Order cannot accept proof from status '{order['status']}'.")

            tx.execute(
                """
                UPDATE payment_orders
                SET status = 'pending_review',
                    submitted_reference = ?,
                    submitted_at = ?,
                    updated_at = ?
                WHERE order_id = ? AND status = 'pending'
                """,
                (ref, now, now, order_id),
            )
            if tx.rowcount != 1:
                raise ConflictError("Order state changed concurrently.")

            self._append_payment_audit_in_tx(
                tx,
                order_id=order_id,
                actor_user_id=user_id,
                event_type="reference_submitted",
                details={"submitted_reference": ref, "has_receipt": bool(order["receipt_object_key"])},
                now=now,
            )
            updated = tx.fetchone("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,))
            assert updated is not None
            return updated

    def cancel_manual_payment_order(self, *, order_id: str, user_id: str) -> Dict[str, Any]:
        now = int(time.time())
        with self.store.transaction() as tx:
            order = tx.fetchone(
                "SELECT * FROM payment_orders WHERE order_id = ? FOR UPDATE", (order_id,)
            )
            if not order:
                raise NotFoundError("Payment order not found.")
            if order["user_id"] != user_id:
                raise ForbiddenError("Cannot cancel another user's order.")
            if order["status"] != "pending":
                raise ConflictError(f"Cannot cancel order in status '{order['status']}'.")

            tx.execute(
                "UPDATE payment_orders SET status = 'cancelled', updated_at = ? WHERE order_id = ? AND status = 'pending'",
                (now, order_id),
            )
            if tx.rowcount != 1:
                raise ConflictError("Order state changed concurrently.")
            self._append_payment_audit_in_tx(
                tx,
                order_id=order_id,
                actor_user_id=user_id,
                event_type="order_cancelled",
                details={},
                now=now,
            )
            updated = tx.fetchone("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,))
            assert updated is not None
            return updated

    def list_user_payment_orders(self, user_id: str) -> List[Dict[str, Any]]:
        with self.store.transaction() as tx:
            return tx.fetchall(
                "SELECT * FROM payment_orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 50",
                (user_id,),
            )

    def _lock_and_verify_admin_in_tx(self, tx: TransactionCursor, actor_user_id: str) -> Dict[str, Any]:
        actor = tx.fetchone("SELECT * FROM users WHERE id = ? FOR UPDATE", (actor_user_id,))
        if not actor or actor["role"] != "admin" or int(actor["is_banned"]):
            raise ForbiddenError("Administrator privileges required.")
        return actor

    def list_admin_payment_orders(
        self,
        *,
        admin_user_id: str,
        status_filter: Optional[str] = None,
        method_filter: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        with self.store.transaction() as tx:
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            clauses: List[str] = []
            params: List[Any] = []
            if status_filter:
                clauses.append("o.status = ?")
                params.append(status_filter)
            if method_filter:
                clauses.append("o.payment_method_code = ?")
                params.append(method_filter)
            where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
            return tx.fetchall(
                f"""
                SELECT o.*, u.username AS user_username
                FROM payment_orders o
                JOIN users u ON u.id = o.user_id
                {where_sql}
                ORDER BY COALESCE(o.submitted_at, o.created_at) DESC
                LIMIT 100
                """,
                params,
            )

    def approve_manual_payment_order(self, *, order_id: str, admin_user_id: str) -> Dict[str, Any]:
        now = int(time.time())
        with self.store.transaction() as tx:
            order = tx.fetchone(
                "SELECT * FROM payment_orders WHERE order_id = ? FOR UPDATE", (order_id,)
            )
            if not order:
                # Verify admin before leaking existence
                self._lock_and_verify_admin_in_tx(tx, admin_user_id)
                raise NotFoundError("Payment order not found.")

            # Deterministic lock ordering across users prevents deadlocks
            for uid in sorted({admin_user_id, order["user_id"]}):
                tx.fetchone("SELECT id FROM users WHERE id = ? FOR UPDATE", (uid,))

            self._lock_and_verify_admin_in_tx(tx, admin_user_id)

            if order["user_id"] == admin_user_id:
                raise ForbiddenError("Administrators cannot approve their own payment orders.")
            if order["status"] != "pending_review" or order["credited_ledger_id"] is not None:
                raise ConflictError(f"Order cannot be approved from status '{order['status']}'.")

            before_snapshot = {
                "status": order["status"],
                "credited_ledger_id": order["credited_ledger_id"],
            }
            ledger = self._apply_balance_delta_in_tx(
                tx,
                user_id=order["user_id"],
                currency=order["reward_currency"],
                delta=int(order["reward_amount"]),
                reason="manual_bank_transfer_approved",
                ref_type="payment_order",
                ref_id=order_id,
                idempotency_key=f"payment_order:{order_id}",
            )
            tx.execute(
                """
                UPDATE payment_orders
                SET status = 'approved',
                    reviewed_by_admin_id = ?,
                    reviewed_at = ?,
                    credited_ledger_id = ?,
                    updated_at = ?
                WHERE order_id = ?
                  AND status = 'pending_review'
                  AND credited_ledger_id IS NULL
                """,
                (admin_user_id, now, ledger["id"], now, order_id),
            )
            if tx.rowcount != 1:
                raise ConflictError("Order was concurrently modified before approval could commit.")

            after_snapshot = {"status": "approved", "credited_ledger_id": ledger["id"]}
            self._append_payment_audit_in_tx(
                tx,
                order_id=order_id,
                actor_user_id=admin_user_id,
                event_type="admin_approved",
                details={
                    "credited_ledger_id": ledger["id"],
                    "currency": order["reward_currency"],
                    "amount": int(order["reward_amount"]),
                    "payment_method_code": order["payment_method_code"],
                    "card_last4": order["card_last4_snapshot"],
                    "recipient_name": order["recipient_name_snapshot"],
                },
                now=now,
            )
            self._append_admin_audit_in_tx(
                tx,
                admin_user_id=admin_user_id,
                action="PAYMENT_APPROVE",
                target_type="payment_order",
                target_entity=order_id,
                before_state=before_snapshot,
                after_state=after_snapshot,
                reason="Manual bank transfer verified by administrator",
                now=now,
            )
            self._create_notification_in_tx(
                tx,
                user_id=order["user_id"],
                title="To‘lov tasdiqlandi",
                body=f"Buyurtma {order_id} tasdiqlandi: +{int(order['reward_amount'])} {order['reward_currency'].upper()} hisobingizga qo‘shildi.",
            )
            updated = tx.fetchone("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,))
            assert updated is not None
            return {"order": updated, "ledger": ledger}

    def reject_manual_payment_order(
        self, *, order_id: str, admin_user_id: str, rejection_reason: str
    ) -> Dict[str, Any]:
        reason = rejection_reason.strip()
        if len(reason) < 3 or len(reason) > 300:
            raise DomainError("Rejection reason must be between 3 and 300 characters.")
        now = int(time.time())

        with self.store.transaction() as tx:
            order = tx.fetchone(
                "SELECT * FROM payment_orders WHERE order_id = ? FOR UPDATE", (order_id,)
            )
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            if not order:
                raise NotFoundError("Payment order not found.")
            if order["status"] != "pending_review":
                raise ConflictError(f"Order cannot be rejected from status '{order['status']}'.")

            before_snapshot = {"status": order["status"]}
            tx.execute(
                """
                UPDATE payment_orders
                SET status = 'rejected',
                    reviewed_by_admin_id = ?,
                    reviewed_at = ?,
                    rejection_reason = ?,
                    updated_at = ?
                WHERE order_id = ? AND status = 'pending_review'
                """,
                (admin_user_id, now, reason, now, order_id),
            )
            if tx.rowcount != 1:
                raise ConflictError("Order was concurrently modified before rejection could commit.")

            after_snapshot = {"status": "rejected", "rejection_reason": reason}
            self._append_payment_audit_in_tx(
                tx,
                order_id=order_id,
                actor_user_id=admin_user_id,
                event_type="admin_rejected",
                details={"rejection_reason": reason},
                now=now,
            )
            self._append_admin_audit_in_tx(
                tx,
                admin_user_id=admin_user_id,
                action="PAYMENT_REJECT",
                target_type="payment_order",
                target_entity=order_id,
                before_state=before_snapshot,
                after_state=after_snapshot,
                reason=reason,
                now=now,
            )
            self._create_notification_in_tx(
                tx,
                user_id=order["user_id"],
                title="To‘lov rad etildi",
                body=f"Buyurtma {order_id} rad etildi. Sabab: {reason}",
            )
            updated = tx.fetchone("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,))
            assert updated is not None
            return updated

    # ------------------------------------------------------------------
    # Preserved Legacy CityXService Gameplay Mechanics (Unified DB)
    # ------------------------------------------------------------------
    def update_home(self, user_id: str, floors: int, has_pool: bool = False, has_helipad: bool = False) -> Dict[str, Any]:
        if not (1 <= floors <= 50):
            raise DomainError("Floors must be between 1 and 50")
        with self.store.transaction() as tx:
            tx.execute(
                "UPDATE homes SET floors = ?, has_pool = ?, has_helipad = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
                (floors, int(has_pool), int(has_helipad), user_id),
            )
            row = tx.fetchone("SELECT * FROM homes WHERE user_id = ?", (user_id,))
            if not row:
                raise NotFoundError("Home not found")
            return row

    def acquire_object(self, user_id: str, object_id: str, expected_version: int) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            obj = tx.fetchone("SELECT * FROM city_objects WHERE id = ? FOR UPDATE", (object_id,))
            if not obj:
                raise NotFoundError("Object not found")
            if int(obj["version"]) != int(expected_version):
                raise ConflictError("Object already acquired or price changed — refresh required")

            existing = tx.fetchone("SELECT * FROM ownerships WHERE object_id = ?", (object_id,))
            if existing and existing["owner_user_id"] == user_id:
                raise ConflictError("You already own this object")

            price = int(obj["current_price_coins"])
            prof = tx.fetchone("SELECT coins FROM profiles WHERE user_id = ? FOR UPDATE", (user_id,))
            if not prof or int(prof["coins"]) < price:
                raise PaymentRequiredError("Insufficient coins")

            self._apply_balance_delta_in_tx(
                tx,
                user_id=user_id,
                currency="coins",
                delta=-price,
                reason="landmark_acquire",
                ref_type="city_object",
                ref_id=object_id,
                idempotency_key=f"acquire:{object_id}:v{expected_version}:{user_id}",
            )
            if existing:
                cashback = int(int(existing["acquired_price_coins"]) * 0.9)
                if cashback > 0:
                    self._apply_balance_delta_in_tx(
                        tx,
                        user_id=existing["owner_user_id"],
                        currency="coins",
                        delta=cashback,
                        reason="landmark_overbid_cashback",
                        ref_type="city_object",
                        ref_id=object_id,
                        idempotency_key=f"cashback:{object_id}:v{expected_version}:{existing['owner_user_id']}",
                    )
                tx.execute("DELETE FROM ownerships WHERE object_id = ?", (object_id,))

            next_price = int(price * 1.2)
            tx.execute(
                "INSERT INTO ownerships (id, object_id, owner_user_id, acquired_price_coins) VALUES (?, ?, ?, ?)",
                (f"own_{uuid.uuid4().hex[:10]}", object_id, user_id, price),
            )
            tx.execute(
                "UPDATE city_objects SET current_price_coins = ?, version = version + 1 WHERE id = ? AND version = ?",
                (next_price, object_id, expected_version),
            )
            if tx.rowcount != 1:
                raise ConflictError("Concurrent ownership version conflict")
            return {
                "object_id": object_id,
                "owner_user_id": user_id,
                "paid_coins": price,
                "next_price_coins": next_price,
                "new_version": expected_version + 1,
            }

    def claim_referral(self, referrer_id: str, referred_id: str, ip_hash: str = "") -> Dict[str, Any]:
        if referrer_id == referred_id:
            raise DomainError("Self-referral is prohibited")
        try:
            with self.store.transaction() as tx:
                tx.execute(
                    "INSERT INTO referrals (id, referrer_user_id, referred_user_id, ip_hash, reward_granted) VALUES (?, ?, ?, ?, 1)",
                    (f"ref_{uuid.uuid4().hex[:10]}", referrer_id, referred_id, ip_hash),
                )
                self._apply_balance_delta_in_tx(
                    tx,
                    user_id=referrer_id,
                    currency="coins",
                    delta=500,
                    reason="referral_bonus",
                    ref_type="referral",
                    ref_id=referred_id,
                    idempotency_key=f"referral:{referred_id}",
                )
                tx.execute(
                    "UPDATE homes SET floors = CASE WHEN floors < 50 THEN floors + 1 ELSE 50 END WHERE user_id = ?",
                    (referrer_id,),
                )
                return {"status": "reward_granted", "bonus_coins": 500, "bonus_floors": 1}
        except Exception as exc:
            if is_unique_violation(exc):
                raise ConflictError("Referral already claimed for this user") from exc
            raise

    def submit_game_score(self, user_id: str, game_code: str, score: int, duration_sec: float) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            game = tx.fetchone("SELECT * FROM games WHERE code = ?", (game_code,))
            if not game:
                raise NotFoundError("Unknown game")
            if score < 0 or duration_sec < 2.0 or (score / duration_sec) > float(game["max_score_per_sec"]):
                raise DomainError("Score rejected by server anti-cheat validation")
            coins = min(500, max(5, score // 2))
            score_id = f"gs_{uuid.uuid4().hex[:10]}"
            tx.execute(
                "INSERT INTO game_scores (id, game_id, user_id, score, duration_sec, coins_awarded) VALUES (?, ?, ?, ?, ?, ?)",
                (score_id, game["id"], user_id, score, duration_sec, coins),
            )
            self._apply_balance_delta_in_tx(
                tx,
                user_id=user_id,
                currency="coins",
                delta=coins,
                reason=f"game_reward:{game_code}",
                ref_type="game_score",
                ref_id=score_id,
                idempotency_key=f"game_score:{score_id}",
            )
            return {"score": score, "coins_awarded": coins}

    def launch_firework(self, user_id: str, message: str) -> Dict[str, Any]:
        clean = message.strip()
        if not clean or len(clean) > 24:
            raise DomainError("Message must be 1-24 characters")
        lower_tokens = set(re.findall(r"[a-zA-Z0-9]+", clean.lower()))
        if lower_tokens & BANNED_WORDS:
            raise DomainError("Message blocked by moderation filter")
        exp = (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=1)).isoformat()
        fw_id = f"fw_{uuid.uuid4().hex[:10]}"
        with self.store.transaction() as tx:
            tx.execute(
                "INSERT INTO fireworks (id, user_id, message, expires_at) VALUES (?, ?, ?, ?)",
                (fw_id, user_id, clean, exp),
            )
        return {"firework_id": fw_id, "message": clean, "expires_at": exp}

    def admin_ban_user(self, admin_user_id: str, target_user_id: str, reason: str) -> Dict[str, Any]:
        now = int(time.time())
        with self.store.transaction() as tx:
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            target = tx.fetchone("SELECT id, is_banned FROM users WHERE id = ? FOR UPDATE", (target_user_id,))
            if not target:
                raise NotFoundError("Target user not found.")
            tx.execute("UPDATE users SET is_banned = 1 WHERE id = ?", (target_user_id,))
            self._append_admin_audit_in_tx(
                tx,
                admin_user_id=admin_user_id,
                action="BAN_USER",
                target_type="user",
                target_entity=target_user_id,
                before_state={"is_banned": int(target["is_banned"])},
                after_state={"is_banned": 1},
                reason=reason,
                now=now,
            )
            return {"status": "banned", "target_user_id": target_user_id}
    # ------------------------------------------------------------------
    # Phase 0.4 Domain Services
    # ------------------------------------------------------------------
    def _create_notification_in_tx(self, tx: TransactionCursor, *, user_id: str, title: str, body: str) -> str:
        nid = f"ntf_{uuid.uuid4().hex[:12]}"
        tx.execute(
            "INSERT INTO notifications (id, user_id, title, body, is_read) VALUES (?, ?, ?, ?, 0)",
            (nid, user_id, title[:120], body[:500]),
        )
        return nid

    def get_public_overview(self) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            d_cnt = tx.fetchone("SELECT COUNT(*) AS c FROM districts")
            u_cnt = tx.fetchone("SELECT COUNT(*) AS c FROM users WHERE is_banned = 0")
            o_cnt = tx.fetchone("SELECT COUNT(*) AS c FROM city_objects")
            p_cnt = tx.fetchone("SELECT COUNT(*) AS c FROM city_places WHERE is_open = TRUE")
            e_cnt = tx.fetchone("SELECT COUNT(*) AS c FROM events WHERE status = 'active'")
        return {
            "platform": "CityX",
            "primary_market": "Uzbekistan",
            "initial_city": "Tashkent",
            "districts_count": int(d_cnt["c"]) if d_cnt else 0,
            "citizens_count": int(u_cnt["c"]) if u_cnt else 0,
            "landmarks_count": int(o_cnt["c"]) if o_cnt else 0,
            "places_count": int(p_cnt["c"]) if p_cnt else 0,
            "active_events_count": int(e_cnt["c"]) if e_cnt else 0,
            "payment_mode": "manual_bank_transfer_only",
            "active_payment_methods": [c.code for c in self.config.active_manual_cards()],
        }

    def request_password_recovery(self, identifier: str) -> Dict[str, Any]:
        ident = identifier.strip().lower()
        if len(ident) < 3 or len(ident) > 128:
            raise DomainError("Provide a valid username or email.")
        now = int(time.time())
        raw_token = f"cxr_{uuid.uuid4().hex}{uuid.uuid4().hex[:16]}"
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        with self.store.transaction() as tx:
            user = tx.fetchone(
                "SELECT id, is_banned FROM users WHERE LOWER(username) = ? OR LOWER(COALESCE(email, '')) = ?",
                (ident, ident),
            )
            if user and not int(user["is_banned"]):
                tx.execute(
                    "INSERT INTO password_reset_tokens (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)",
                    (f"rst_{uuid.uuid4().hex[:12]}", user["id"], token_hash, now + 900, now),
                )
        return {
            "accepted": True,
            "expires_in_seconds": 900,
            "email_delivery_configured": self.config.smtp_configured,
            "delivery_notice": (
                "If an account exists, a recovery token was queued via configured email."
                if self.config.smtp_configured
                else "SMTP email delivery is not configured in this environment. Request a verified recovery token via official support or Telegram verification."
            ),
        }

    def issue_recovery_token_for_admin(self, admin_user_id: str, target_user_id: str) -> Dict[str, Any]:
        now = int(time.time())
        raw_token = f"cxr_{uuid.uuid4().hex}{uuid.uuid4().hex[:16]}"
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        with self.store.transaction() as tx:
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            user = tx.fetchone("SELECT id FROM users WHERE id = ?", (target_user_id,))
            if not user:
                raise NotFoundError("Target user not found.")
            rst_id = f"rst_{uuid.uuid4().hex[:12]}"
            tx.execute(
                "INSERT INTO password_reset_tokens (id, user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?)",
                (rst_id, target_user_id, token_hash, now + 900, now),
            )
            self._append_admin_audit_in_tx(
                tx,
                admin_user_id=admin_user_id,
                action="ISSUE_RECOVERY_TOKEN",
                target_type="user",
                target_entity=target_user_id,
                before_state={},
                after_state={"reset_id": rst_id},
                reason="Admin-verified account recovery token issued",
                now=now,
            )
        return {"recovery_token": raw_token, "expires_in_seconds": 900}

    def confirm_password_recovery(self, raw_token: str, new_password: str) -> Dict[str, Any]:
        tok = raw_token.strip()
        if len(tok) < 16 or len(tok) > 128:
            raise DomainError("Invalid recovery token format.")
        if len(new_password) < 8 or len(new_password) > 128:
            raise DomainError("New password must be 8-128 characters.")
        token_hash = hashlib.sha256(tok.encode("utf-8")).hexdigest()
        now = int(time.time())
        with self.store.transaction() as tx:
            rec = tx.fetchone("SELECT * FROM password_reset_tokens WHERE token_hash = ? FOR UPDATE", (token_hash,))
            if not rec or rec["used_at"] is not None or int(rec["expires_at"]) <= now:
                raise DomainError("Recovery token is invalid, expired, or already used.")
            tx.execute(
                "UPDATE password_reset_tokens SET used_at = ? WHERE id = ? AND used_at IS NULL",
                (now, rec["id"]),
            )
            if tx.rowcount != 1:
                raise ConflictError("Recovery token was already consumed.")
            tx.execute("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password_pbkdf2(new_password), rec["user_id"]))
            tx.execute("UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL", (now, rec["user_id"]))
            self._create_notification_in_tx(
                tx,
                user_id=rec["user_id"],
                title="Parol yangilandi",
                body="Hisob parolingiz tiklandi va barcha eski sessiyalar yopildi.",
            )
        return {"status": "password_updated", "sessions_revoked": True}

    def get_profile_bundle(self, user_id: str) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            user = self._fetch_user_view_in_tx(tx, user_id)
            if not user:
                raise NotFoundError("User not found.")
            home = tx.fetchone("SELECT * FROM homes WHERE user_id = ?", (user_id,))
            vehicles = tx.fetchall("SELECT * FROM vehicles WHERE user_id = ? ORDER BY id ASC", (user_id,))
            owned_landmarks = tx.fetchall(
                """
                SELECT o.object_id, o.acquired_price_coins, o.acquired_at, c.name, c.district_id, c.current_price_coins
                FROM ownerships o
                JOIN city_objects c ON c.id = o.object_id
                WHERE o.owner_user_id = ?
                """,
                (user_id,),
            )
            likes_cnt = (
                tx.fetchone("SELECT COUNT(*) AS c FROM likes WHERE target_home_id = ?", (home["id"],))
                if home
                else {"c": 0}
            )
        return {
            "user": user,
            "home": home,
            "vehicles": vehicles,
            "owned_landmarks": owned_landmarks,
            "home_likes_count": int(likes_cnt["c"]) if likes_cnt else 0,
        }

    def update_profile(
        self,
        user_id: str,
        *,
        display_name: Optional[str] = None,
        bio: Optional[str] = None,
        instagram_handle: Optional[str] = None,
        avatar_url: Optional[str] = None,
        district_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        if avatar_url is not None and avatar_url != "":
            av = avatar_url.strip()
            if not (av.startswith("preset:") or av.startswith("https://")):
                raise DomainError("avatar_url must use a safe 'preset:' identifier or 'https://' URL.")
            if re.search(r"(javascript:|data:|<|>)", av, re.I) or len(av) > 300:
                raise DomainError("Unsafe avatar_url value.")
        with self.store.transaction() as tx:
            prof = tx.fetchone("SELECT * FROM profiles WHERE user_id = ? FOR UPDATE", (user_id,))
            if not prof:
                raise NotFoundError("Profile not found.")
            new_display = prof["display_name"] if display_name is None else display_name.strip()[:48]
            if len(new_display) < 2:
                raise DomainError("display_name must be at least 2 characters.")
            new_bio = prof["bio"] if bio is None else bio.strip()[:240]
            new_ig = prof["instagram_handle"] if instagram_handle is None else re.sub(r"[^a-zA-Z0-9._]", "", instagram_handle.lstrip("@"))[:30]
            new_av = prof["avatar_url"] if avatar_url is None else avatar_url.strip()
            new_dist = prof["district_id"] if district_id is None else district_id.strip()
            if district_id is not None and not tx.fetchone("SELECT id FROM districts WHERE id = ?", (new_dist,)):
                raise DomainError("Invalid canonical district_id.")
            tx.execute(
                """
                UPDATE profiles
                SET display_name = ?, bio = ?, instagram_handle = ?, avatar_url = ?, district_id = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = ?
                """,
                (new_display, new_bio, new_ig, new_av, new_dist, user_id),
            )
            updated = self._fetch_user_view_in_tx(tx, user_id)
            assert updated is not None
            return updated

    def get_dashboard_summary(self, user_id: str) -> Dict[str, Any]:
        tz_uz = datetime.timezone(datetime.timedelta(hours=5))
        today = datetime.datetime.now(tz_uz).strftime("%Y-%m-%d")
        with self.store.transaction() as tx:
            user = self._fetch_user_view_in_tx(tx, user_id)
            if not user:
                raise NotFoundError("User not found.")
            home = tx.fetchone("SELECT * FROM homes WHERE user_id = ?", (user_id,))
            districts = tx.fetchall("SELECT id, name, code, total_points FROM districts ORDER BY total_points DESC, name ASC")
            recent_ledger = tx.fetchall(
                "SELECT id, currency, delta, balance_after, reason, created_at FROM economy_ledger WHERE user_id = ? ORDER BY created_at DESC LIMIT 8",
                (user_id,),
            )
            unread = tx.fetchone("SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0", (user_id,))
            pending_orders = tx.fetchone(
                "SELECT COUNT(*) AS c FROM payment_orders WHERE user_id = ? AND status IN ('pending', 'pending_review')",
                (user_id,),
            )
        rank = next((i + 1 for i, d in enumerate(districts) if d["id"] == user["district_id"]), 1)
        return {
            "user": user,
            "home": home,
            "daily_claim_ready": user["last_daily_claim"] != today,
            "district_rank": rank,
            "districts_leaderboard": districts,
            "recent_ledger": recent_ledger,
            "unread_notifications": int(unread["c"]) if unread else 0,
            "pending_payment_orders": int(pending_orders["c"]) if pending_orders else 0,
        }

    def get_city_map(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            districts = tx.fetchall(
                "SELECT id, name, code, description, total_points, center_x, center_z FROM districts ORDER BY id ASC"
            )
            objects = tx.fetchall(
                """
                SELECT c.*, o.owner_user_id, u.username AS owner_username
                FROM city_objects c
                LEFT JOIN ownerships o ON o.object_id = c.id
                LEFT JOIN users u ON u.id = o.owner_user_id
                ORDER BY c.current_price_coins DESC
                """
            )
            user_home = tx.fetchone("SELECT * FROM homes WHERE user_id = ?", (user_id,)) if user_id else None
        fares = {k: {"fare_coins": v[0], "eta_min": v[1]} for k, v in TAXI_FARES_BY_DISTRICT.items()}
        return {
            "world_size_m": 1200,
            "grid_dimensions": "3x3",
            "districts": districts,
            "landmarks": objects,
            "taxi_fares": fares,
            "user_home": user_home,
        }

    def get_wallet(self, user_id: str, limit: int = 50) -> Dict[str, Any]:
        cap = max(1, min(int(limit), 100))
        with self.store.transaction() as tx:
            prof = tx.fetchone("SELECT coins, gems FROM profiles WHERE user_id = ?", (user_id,))
            if not prof:
                raise NotFoundError("Profile not found.")
            ledger = tx.fetchall(
                """
                SELECT id, currency, delta, balance_after, reason, ref_type, ref_id, created_at
                FROM economy_ledger
                WHERE user_id = ?
                ORDER BY created_at DESC, id DESC
                LIMIT ?
                """,
                (user_id, cap),
            )
        return {"coins": int(prof["coins"]), "gems": int(prof["gems"]), "transactions": ledger}

    def get_settings(self, user_id: str) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            prof = tx.fetchone("SELECT language, classic_mode, notify_prefs FROM profiles WHERE user_id = ?", (user_id,))
            if not prof:
                raise NotFoundError("Profile not found.")
        try:
            prefs = json.loads(prof["notify_prefs"] or "{}")
        except json.JSONDecodeError:
            prefs = {}
        return {"language": prof["language"], "classic_mode": bool(prof["classic_mode"]), "notify_prefs": prefs}

    def update_settings(
        self,
        user_id: str,
        *,
        language: Optional[str] = None,
        classic_mode: Optional[bool] = None,
        notify_prefs: Optional[Dict[str, bool]] = None,
    ) -> Dict[str, Any]:
        if language is not None and language not in ("uz", "ru", "en"):
            raise DomainError("Language must be 'uz', 'ru', or 'en'.")
        with self.store.transaction() as tx:
            prof = tx.fetchone("SELECT language, classic_mode, notify_prefs FROM profiles WHERE user_id = ? FOR UPDATE", (user_id,))
            if not prof:
                raise NotFoundError("Profile not found.")
            new_lang = prof["language"] if language is None else language
            new_classic = int(prof["classic_mode"]) if classic_mode is None else (1 if classic_mode else 0)
            new_prefs_str = (
                prof["notify_prefs"]
                if notify_prefs is None
                else json.dumps({str(k)[:32]: bool(v) for k, v in notify_prefs.items()}, sort_keys=True, separators=(",", ":"))
            )
            tx.execute(
                "UPDATE profiles SET language = ?, classic_mode = ?, notify_prefs = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
                (new_lang, new_classic, new_prefs_str, user_id),
            )
        return self.get_settings(user_id)

    def list_notifications(self, user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        cap = max(1, min(int(limit), 100))
        with self.store.transaction() as tx:
            return tx.fetchall(
                "SELECT id, title, body, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT ?",
                (user_id, cap),
            )

    def mark_notification_read(self, user_id: str, notification_id: str) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            tx.execute("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", (notification_id, user_id))
            row = tx.fetchone(
                "SELECT id, title, body, is_read, created_at FROM notifications WHERE id = ? AND user_id = ?",
                (notification_id, user_id),
            )
            if not row:
                raise NotFoundError("Notification not found.")
            return row

    def discover_profiles(self, query: str = "", district_id: Optional[str] = None, limit: int = 30) -> List[Dict[str, Any]]:
        cap = max(1, min(int(limit), 50))
        q = query.strip().lower()
        clauses = ["u.is_banned = 0"]
        params: List[Any] = []
        if q:
            clauses.append("(LOWER(u.username) LIKE ? OR LOWER(p.display_name) LIKE ?)")
            like_q = f"%{q}%"
            params.extend([like_q, like_q])
        if district_id:
            clauses.append("p.district_id = ?")
            params.append(district_id.strip())
        params.append(cap)
        where_sql = " AND ".join(clauses)
        with self.store.transaction() as tx:
            return tx.fetchall(
                f"""
                SELECT u.id, u.username, p.display_name, p.bio, p.avatar_url,
                       p.instagram_handle, p.district_id, p.level, p.reputation_score,
                       h.id AS home_id, h.plot_code, h.floors
                FROM users u
                JOIN profiles p ON p.user_id = u.id
                LEFT JOIN homes h ON h.user_id = u.id
                WHERE {where_sql}
                ORDER BY p.level DESC, p.reputation_score DESC, u.username ASC
                LIMIT ?
                """,
                params,
            )

    def get_public_profile(self, username: str) -> Dict[str, Any]:
        clean = username.strip().lower()
        with self.store.transaction() as tx:
            row = tx.fetchone(
                """
                SELECT u.id, u.username, p.display_name, p.bio, p.avatar_url,
                       p.instagram_handle, p.district_id, p.level, p.reputation_score
                FROM users u
                JOIN profiles p ON p.user_id = u.id
                WHERE LOWER(u.username) = ? AND u.is_banned = 0
                """,
                (clean,),
            )
            if not row:
                raise NotFoundError("Citizen profile not found.")
            home = tx.fetchone(
                "SELECT id, district_id, plot_code, floors, architecture_style, has_pool, has_helipad FROM homes WHERE user_id = ?",
                (row["id"],),
            )
            likes_cnt = tx.fetchone("SELECT COUNT(*) AS c FROM likes WHERE target_home_id = ?", (home["id"],)) if home else {"c": 0}
            landmarks = tx.fetchall(
                "SELECT c.id, c.name, c.district_id FROM ownerships o JOIN city_objects c ON c.id = o.object_id WHERE o.owner_user_id = ?",
                (row["id"],),
            )
        return {
            "profile": row,
            "home": home,
            "home_likes_count": int(likes_cnt["c"]) if likes_cnt else 0,
            "owned_landmarks": landmarks,
        }

    def request_friendship(self, from_user_id: str, target_username: str) -> Dict[str, Any]:
        clean = target_username.strip().lower()
        with self.store.transaction() as tx:
            target = tx.fetchone("SELECT id, username FROM users WHERE LOWER(username) = ? AND is_banned = 0", (clean,))
            if not target:
                raise NotFoundError("Target citizen not found.")
            if target["id"] == from_user_id:
                raise DomainError("Cannot send a friend request to yourself.")
            existing = tx.fetchone(
                "SELECT * FROM friendships WHERE (user_a = ? AND user_b = ?) OR (user_a = ? AND user_b = ?)",
                (from_user_id, target["id"], target["id"], from_user_id),
            )
            if existing:
                raise ConflictError(f"Friendship already exists (status={existing['status']}).")
            fid = f"frd_{uuid.uuid4().hex[:12]}"
            tx.execute("INSERT INTO friendships (id, user_a, user_b, status) VALUES (?, ?, ?, 'pending')", (fid, from_user_id, target["id"]))
            sender = tx.fetchone("SELECT username FROM users WHERE id = ?", (from_user_id,))
            self._create_notification_in_tx(
                tx,
                user_id=target["id"],
                title="Yangi do‘stlik so‘rovi",
                body=f"@{sender['username'] if sender else 'citizen'} sizga do‘stlik so‘rovi yubordi.",
            )
            return {"id": fid, "status": "pending", "target_username": target["username"]}

    def accept_friendship(self, user_id: str, friendship_id: str) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            row = tx.fetchone("SELECT * FROM friendships WHERE id = ? FOR UPDATE", (friendship_id,))
            if not row:
                raise NotFoundError("Friend request not found.")
            if row["user_b"] != user_id:
                raise ForbiddenError("Only the recipient can accept a friend request.")
            if row["status"] != "pending":
                raise ConflictError(f"Cannot accept request in status '{row['status']}'.")
            tx.execute("UPDATE friendships SET status = 'accepted' WHERE id = ?", (friendship_id,))
            return {"id": friendship_id, "status": "accepted"}

    def list_friends(self, user_id: str) -> List[Dict[str, Any]]:
        with self.store.transaction() as tx:
            return tx.fetchall(
                """
                SELECT f.id, f.status, f.created_at,
                       CASE WHEN f.user_a = ? THEN 'outgoing' ELSE 'incoming' END AS direction,
                       u.id AS peer_id, u.username AS peer_username, p.display_name AS peer_display_name,
                       p.district_id AS peer_district_id, p.level AS peer_level
                FROM friendships f
                JOIN users u ON u.id = CASE WHEN f.user_a = ? THEN f.user_b ELSE f.user_a END
                JOIN profiles p ON p.user_id = u.id
                WHERE f.user_a = ? OR f.user_b = ?
                ORDER BY f.created_at DESC
                """,
                (user_id, user_id, user_id, user_id),
            )

    def like_home(self, user_id: str, home_id: str) -> Dict[str, Any]:
        try:
            with self.store.transaction() as tx:
                home = tx.fetchone("SELECT id, user_id FROM homes WHERE id = ?", (home_id,))
                if not home:
                    raise NotFoundError("Home not found.")
                tx.execute("INSERT INTO likes (id, from_user_id, target_home_id) VALUES (?, ?, ?)", (f"lik_{uuid.uuid4().hex[:12]}", user_id, home_id))
                tx.execute("UPDATE profiles SET reputation_score = reputation_score + 1 WHERE user_id = ?", (home["user_id"],))
                cnt = tx.fetchone("SELECT COUNT(*) AS c FROM likes WHERE target_home_id = ?", (home_id,))
                return {"home_id": home_id, "likes_count": int(cnt["c"]) if cnt else 1}
        except Exception as exc:
            if is_unique_violation(exc):
                raise ConflictError("You have already liked this home.") from exc
            raise

    def list_places(self, district_id: Optional[str] = None, category: Optional[str] = None) -> List[Dict[str, Any]]:
        clauses = ["is_open = TRUE"]
        params: List[Any] = []
        if district_id:
            clauses.append("district_id = ?")
            params.append(district_id.strip())
        if category:
            clauses.append("category = ?")
            params.append(category.strip())
        with self.store.transaction() as tx:
            return tx.fetchall(f"SELECT * FROM city_places WHERE {' AND '.join(clauses)} ORDER BY district_id ASC, name ASC", params)

    def list_events(self, user_id: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.store.transaction() as tx:
            events = tx.fetchall("SELECT * FROM events ORDER BY start_ts ASC")
            out: List[Dict[str, Any]] = []
            for ev in events:
                cnt = tx.fetchone("SELECT COUNT(*) AS c FROM event_rsvps WHERE event_id = ?", (ev["id"],))
                joined = bool(tx.fetchone("SELECT 1 FROM event_rsvps WHERE event_id = ? AND user_id = ?", (ev["id"], user_id))) if user_id else False
                out.append({**ev, "attendees_count": int(cnt["c"]) if cnt else 0, "joined": joined})
            return out

    def toggle_event_rsvp(self, user_id: str, event_id: str, join: bool = True) -> Dict[str, Any]:
        now = int(time.time())
        with self.store.transaction() as tx:
            if not tx.fetchone("SELECT id FROM events WHERE id = ?", (event_id,)):
                raise NotFoundError("Event not found.")
            if join:
                if not tx.fetchone("SELECT 1 FROM event_rsvps WHERE event_id = ? AND user_id = ?", (event_id, user_id)):
                    tx.execute("INSERT INTO event_rsvps (event_id, user_id, joined_at) VALUES (?, ?, ?)", (event_id, user_id, now))
            else:
                tx.execute("DELETE FROM event_rsvps WHERE event_id = ? AND user_id = ?", (event_id, user_id))
            cnt = tx.fetchone("SELECT COUNT(*) AS c FROM event_rsvps WHERE event_id = ?", (event_id,))
            return {"event_id": event_id, "joined": join, "attendees_count": int(cnt["c"]) if cnt else 0}

    def list_elections(self, user_id: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.store.transaction() as tx:
            rows = tx.fetchall("SELECT * FROM elections ORDER BY election_id DESC")
            out: List[Dict[str, Any]] = []
            for e in rows:
                vote = tx.fetchone("SELECT candidate_id FROM election_votes WHERE election_id = ? AND user_id = ?", (e["election_id"], user_id)) if user_id else None
                total = tx.fetchone("SELECT COUNT(*) AS c FROM election_votes WHERE election_id = ?", (e["election_id"],))
                out.append({
                    "election_id": e["election_id"],
                    "title": e["title"],
                    "status": e["status"],
                    "candidates": json.loads(e["candidates_json"]),
                    "total_votes": int(total["c"]) if total else 0,
                    "user_voted_candidate_id": vote["candidate_id"] if vote else None,
                })
            return out

    def get_admin_overview(self, admin_user_id: str) -> Dict[str, Any]:
        with self.store.transaction() as tx:
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            u_tot = tx.fetchone("SELECT COUNT(*) AS c FROM users")
            u_ban = tx.fetchone("SELECT COUNT(*) AS c FROM users WHERE is_banned = 1")
            p_rev = tx.fetchone("SELECT COUNT(*) AS c FROM payment_orders WHERE status = 'pending_review'")
            p_app = tx.fetchone("SELECT COUNT(*) AS c FROM payment_orders WHERE status = 'approved'")
            p_rej = tx.fetchone("SELECT COUNT(*) AS c FROM payment_orders WHERE status = 'rejected'")
            led = tx.fetchone("SELECT COUNT(*) AS c FROM economy_ledger")
        return {
            "users_total": int(u_tot["c"]) if u_tot else 0,
            "banned_users": int(u_ban["c"]) if u_ban else 0,
            "pending_review_payments": int(p_rev["c"]) if p_rev else 0,
            "approved_payments": int(p_app["c"]) if p_app else 0,
            "rejected_payments": int(p_rej["c"]) if p_rej else 0,
            "ledger_entries": int(led["c"]) if led else 0,
        }

    def list_admin_users(self, admin_user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        cap = max(1, min(int(limit), 100))
        with self.store.transaction() as tx:
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            return tx.fetchall(
                """
                SELECT u.id, u.username, u.role, u.is_banned, u.auth_provider, u.created_at,
                       p.district_id, p.coins, p.gems, p.level
                FROM users u
                JOIN profiles p ON p.user_id = u.id
                ORDER BY u.created_at DESC
                LIMIT ?
                """,
                (cap,),
            )

    def list_admin_audit_logs(self, admin_user_id: str, limit: int = 50) -> Dict[str, Any]:
        cap = max(1, min(int(limit), 100))
        with self.store.transaction() as tx:
            self._lock_and_verify_admin_in_tx(tx, admin_user_id)
            admin_logs = tx.fetchall("SELECT * FROM admin_audit_logs ORDER BY created_ts DESC, id DESC LIMIT ?", (cap,))
            payment_logs = tx.fetchall("SELECT * FROM payment_audit_logs ORDER BY id DESC LIMIT ?", (cap,))
        return {"admin_audit_logs": admin_logs, "payment_audit_logs": payment_logs}
