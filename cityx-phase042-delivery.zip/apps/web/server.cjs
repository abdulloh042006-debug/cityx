const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { URL } = require("node:url");

const port = Number(process.env.PORT || 3000);
const root = path.resolve(__dirname, "dist");
const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".woff2": "font/woff2",
};

const securityHeaders = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
  "Content-Security-Policy":
    "default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https: http://localhost:*; frame-ancestors 'self' https://web.telegram.org https://*.telegram.org;",
};

function send(res, status, body, type = "text/plain; charset=utf-8") {
  res.writeHead(status, { ...securityHeaders, "Content-Type": type, "Cache-Control": "no-store" });
  res.end(body);
}

function safePath(requestPath) {
  const decoded = decodeURIComponent(requestPath);
  const relative = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
  const candidate = path.resolve(root, relative);
  return candidate.startsWith(`${root}${path.sep}`) ? candidate : null;
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url || "/", "http://cityx.local");
  if (url.pathname === "/__health") {
    send(res, 200, "ok\n");
    return;
  }
  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "method not allowed\n");
    return;
  }

  let filePath;
  try {
    filePath = safePath(url.pathname);
  } catch {
    send(res, 400, "bad request\n");
    return;
  }
  if (!filePath) {
    send(res, 400, "bad request\n");
    return;
  }

  const fallback = path.join(root, "index.html");
  const candidate = fs.existsSync(filePath) && fs.statSync(filePath).isFile() ? filePath : fallback;
  fs.readFile(candidate, (error, data) => {
    if (error) {
      send(res, 500, "server error\n");
      return;
    }
    const type = contentTypes[path.extname(candidate)] || "application/octet-stream";
    res.writeHead(200, {
      ...securityHeaders,
      "Content-Type": type,
      "Cache-Control": candidate === fallback ? "no-cache" : "public, max-age=31536000, immutable",
    });
    if (req.method !== "HEAD") res.end(data);
    else res.end();
  });
});

server.listen(port, "0.0.0.0", () => {
  console.log(`CityX frontend server listening on ${port}`);
});
