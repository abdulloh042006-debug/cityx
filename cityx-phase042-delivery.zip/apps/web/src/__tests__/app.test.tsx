import { describe, it, expect, vi, beforeEach } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { I18nProvider } from "../i18n/I18nContext";
import { AuthProvider } from "../auth/AuthContext";
import { AppRoutes } from "../App";

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function renderAt(path: string) {
  return render(
    <I18nProvider>
      <AuthProvider>
        <MemoryRouter initialEntries={[path]}>
          <AppRoutes />
        </MemoryRouter>
      </AuthProvider>
    </I18nProvider>
  );
}

const SAMPLE_USER = {
  id: "usr_1",
  username: "aziz_uz",
  display_name: "Aziz",
  role: "user",
  district_id: "downtown",
  coins: 1000,
  gems: 25,
  level: 2,
  streak: 1,
  reputation_score: 10,
  bio: "",
  language: "uz",
  avatar_url: "preset:cyan-architect",
  instagram_handle: "",
  is_banned: 0,
};

describe("CityX Phase 0.4.2 Frontend Forms, Routes & Security Integration", () => {
  beforeEach(() => {
    window.localStorage.clear();
    vi.restoreAllMocks();
  });

  it("renders Uzbek Latin landing page and calls /api/city/overview", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValueOnce(
      jsonResponse({
        ok: true,
        overview: { districts_count: 8, landmarks_count: 6, places_count: 15, citizens_count: 42 },
      })
    );

    renderAt("/");
    expect(screen.getByText(/CityX — Toshkentdan boshlanadigan/i)).toBeInTheDocument();
    await waitFor(() =>
      expect(fetchMock).toHaveBeenCalledWith(expect.stringContaining("/api/city/overview"), expect.anything())
    );
  });

  it("validates login, registration and password recovery forms without fake success", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch");
    renderAt("/auth");

    // Login validation blocks short username before hitting API
    fireEvent.change(screen.getByLabelText(/Foydalanuvchi nomi/i), { target: { value: "ab" } });
    fireEvent.click(screen.getByRole("button", { name: /Hisobga kirish/i }));
    expect(await screen.findByRole("alert")).toHaveTextContent(/kamida 3 belgi/i);
    expect(fetchMock).not.toHaveBeenCalled();

    // Switch to Password Recovery tab and verify honest delivery notice from backend
    fireEvent.click(screen.getByRole("button", { name: /Parolni tiklash/i }));
    fetchMock.mockResolvedValueOnce(
      jsonResponse({
        ok: true,
        accepted: true,
        email_delivery_configured: false,
        delivery_notice: "SMTP email delivery is not configured in this environment.",
      })
    );
    fireEvent.change(screen.getByPlaceholderText(/Foydalanuvchi nomi yoki email/i), { target: { value: "aziz_uz" } });
    fireEvent.click(screen.getByRole("button", { name: /Tiklash so‘rovi yuborish/i }));
    expect(await screen.findByRole("status")).toHaveTextContent(/SMTP email delivery is not configured/i);
  });

  it("displays separate Visa & Uzcard manual payment cards with masked numbers only", async () => {
    window.localStorage.setItem("cityx_access_token", "test-jwt");
    vi.spyOn(globalThis, "fetch").mockImplementation(async (input) => {
      const url = String(input);
      if (url.endsWith("/api/profile/me")) {
        return jsonResponse({ ok: true, user: SAMPLE_USER, home: null, vehicles: [], owned_landmarks: [], home_likes_count: 0 });
      }
      if (url.endsWith("/api/payments/methods")) {
        return jsonResponse({
          ok: true,
          methods: [
            {
              code: "uzum_visa",
              display_name: "Uzum Bank — Visa",
              network: "Visa",
              bank_name: "Uzum Bank",
              recipient_name: "Abdullox Arslonov",
              card_last4: "8421",
              card_masked: "**** **** **** 8421",
              enabled: true,
            },
            {
              code: "uzcard",
              display_name: "Uzcard",
              network: "Uzcard",
              bank_name: null,
              recipient_name: "Arslonov Abdulloh",
              card_last4: "8244",
              card_masked: "**** **** **** 8244",
              enabled: true,
            },
          ],
        });
      }
      if (url.endsWith("/api/payments/packages")) {
        return jsonResponse({
          ok: true,
          packages: [{ id: "gems_100", title: "100 CityX Gems", reward_currency: "gems", reward_amount: 100, price_uzs: 25000 }],
        });
      }
      if (url.endsWith("/api/payments/orders")) {
        return jsonResponse({ ok: true, orders: [] });
      }
      return jsonResponse({ ok: true });
    });

    renderAt("/payments");
    expect(await screen.findByText(/Abdullox Arslonov/i)).toBeInTheDocument();
    expect(screen.getByText(/Arslonov Abdulloh/i)).toBeInTheDocument();
    expect(screen.getByText(/\*\*\*\* \*\*\*\* \*\*\*\* 8421/)).toBeInTheDocument();
    expect(screen.getByText(/\*\*\*\* \*\*\*\* \*\*\*\* 8244/)).toBeInTheDocument();
    expect(screen.getByText(/Bank nomi tasdiqlanmagan/i)).toBeInTheDocument();
  });

  it("gates unauthenticated access to /app/economy/topup and /app/property/:id deep links", async () => {
    renderAt("/app/property/hom_123");
    expect(await screen.findByText(/hisobingizga kiring/i)).toBeInTheDocument();
  });

  it("enforces admin role gate on /admin for regular users", async () => {
    window.localStorage.setItem("cityx_access_token", "test-jwt");
    vi.spyOn(globalThis, "fetch").mockResolvedValueOnce(
      jsonResponse({ ok: true, user: SAMPLE_USER, home: null, vehicles: [], owned_landmarks: [], home_likes_count: 0 })
    );
    renderAt("/admin");
    expect(await screen.findByText(/403 Forbidden/i)).toBeInTheDocument();
  });
});
