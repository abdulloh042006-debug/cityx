import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, CityXUser, configureApiAuth } from "../api/client";

const TOKEN_KEY = "cityx_access_token";

interface AuthContextValue {
  token: string | null;
  user: CityXUser | null;
  loading: boolean;
  setSession: (token: string, user: CityXUser) => void;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() =>
    typeof window !== "undefined" ? window.localStorage.getItem(TOKEN_KEY) : null
  );
  const [user, setUser] = useState<CityXUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const clearSession = useCallback(() => {
    setToken(null);
    setUser(null);
    window.localStorage.removeItem(TOKEN_KEY);
  }, []);

  useEffect(() => {
    configureApiAuth(() => token, clearSession);
  }, [token, clearSession]);

  const setSession = useCallback((nextToken: string, nextUser: CityXUser) => {
    window.localStorage.setItem(TOKEN_KEY, nextToken);
    setToken(nextToken);
    setUser(nextUser);
  }, []);

  const refreshUser = useCallback(async () => {
    if (!token) {
      setUser(null);
      return;
    }
    try {
      const res = await api.getProfileMe();
      setUser(res.user);
    } catch {
      clearSession();
    }
  }, [token, clearSession]);

  useEffect(() => {
    let active = true;
    async function bootstrap() {
      if (token) {
        try {
          const res = await api.getProfileMe();
          if (active) setUser(res.user);
        } catch {
          if (active) clearSession();
        } finally {
          if (active) setLoading(false);
        }
        return;
      }

      const tg = (window as unknown as { Telegram?: { WebApp?: { initData?: string; ready?: () => void } } }).Telegram?.WebApp;
      if (tg?.initData) {
        tg.ready?.();
        try {
          const res = await api.miniAppAuth(tg.initData);
          if (active) setSession(res.accessToken, res.user);
        } catch {
          // Remain guest if initData verification fails
        }
      }
      if (active) setLoading(false);
    }
    bootstrap();
    return () => {
      active = false;
    };
  }, [token, clearSession, setSession]);

  const logout = useCallback(async () => {
    try {
      if (token) await api.logout();
    } catch {
      // Clear client session even if server unreachable
    } finally {
      clearSession();
    }
  }, [token, clearSession]);

  return (
    <AuthContext.Provider value={{ token, user, loading, setSession, refreshUser, logout, isAdmin: user?.role === "admin" }}>
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
