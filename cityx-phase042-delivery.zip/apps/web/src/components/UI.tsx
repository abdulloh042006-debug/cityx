import React from "react";
import { Link } from "react-router-dom";
import { useI18n } from "../i18n/I18nContext";

export const PageHeader: React.FC<{ title: string; subtitle?: string; right?: React.ReactNode }> = ({
  title,
  subtitle,
  right,
}) => (
  <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
    <div>
      <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-slate-400">{subtitle}</p>}
    </div>
    {right}
  </div>
);

export const LoadingBox: React.FC<{ label?: string }> = ({ label }) => {
  const { t } = useI18n();
  return (
    <div className="rounded-2xl border border-slate-800 bg-[#071326]/70 p-8 text-center text-sm text-slate-300">
      {label || t.common.loading}
    </div>
  );
};

export const ErrorBox: React.FC<{ message: string; onRetry?: () => void }> = ({ message, onRetry }) => {
  const { t } = useI18n();
  return (
    <div className="rounded-2xl border border-rose-500/40 bg-rose-950/30 p-4 text-sm text-rose-200">
      <p>{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 rounded-lg bg-rose-500/20 px-3 py-1.5 text-xs font-semibold text-rose-100 hover:bg-rose-500/30"
        >
          {t.common.retry}
        </button>
      )}
    </div>
  );
};

export const AuthGate: React.FC = () => {
  const { t } = useI18n();
  return (
    <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-8 text-center">
      <p className="text-sm text-slate-300">{t.common.authRequired}</p>
      <Link
        to="/auth"
        className="mt-4 inline-block rounded-xl bg-cyan-400 px-5 py-2.5 text-sm font-semibold text-slate-950 hover:bg-cyan-300"
      >
        {t.nav.login}
      </Link>
    </div>
  );
};

export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const map: Record<string, string> = {
    pending: "border-slate-600 bg-slate-800 text-slate-200",
    pending_review: "border-amber-400/50 bg-amber-500/15 text-amber-200",
    approved: "border-emerald-400/50 bg-emerald-500/15 text-emerald-200",
    rejected: "border-rose-400/50 bg-rose-500/15 text-rose-200",
    cancelled: "border-slate-700 bg-slate-900 text-slate-400",
  };
  return (
    <span className={`inline-flex rounded-full border px-2.5 py-0.5 text-xs font-semibold uppercase ${map[status] || map.pending}`}>
      {status}
    </span>
  );
};
