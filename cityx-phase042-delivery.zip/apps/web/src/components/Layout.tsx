import React, { useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { Menu, Shield, X } from "lucide-react";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { Lang } from "../i18n/translations";

export const Layout: React.FC = () => {
  const { user, isAdmin, logout } = useAuth();
  const { lang, setLang, t } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { to: "/", label: t.nav.home },
    { to: "/dashboard", label: t.nav.dashboard },
    { to: "/map", label: t.nav.map },
    { to: "/city-3d", label: t.nav.city3d },
    { to: "/wallet", label: t.nav.wallet },
    { to: "/payments", label: t.nav.payments },
    { to: "/social", label: t.nav.social },
    { to: "/places", label: t.nav.places },
    { to: "/profile", label: t.nav.profile },
    { to: "/settings", label: t.nav.settings },
  ];

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-lg px-2.5 py-1.5 text-xs font-medium transition ${
      isActive ? "bg-cyan-400/20 text-cyan-300" : "text-slate-300 hover:bg-slate-800/70 hover:text-white"
    }`;

  return (
    <div className="flex min-h-screen flex-col bg-[#03040A] text-slate-100">
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#071326]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 font-display text-sm font-bold text-slate-950">
              CX
            </span>
            <span className="font-display text-lg font-bold tracking-tight text-white">CityX</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden flex-wrap items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <NavLink key={item.to} to={item.to} end={item.to === "/"} className={linkClass}>
                {item.label}
              </NavLink>
            ))}
            {isAdmin && (
              <NavLink to="/admin" className={linkClass}>
                <span className="inline-flex items-center gap-1">
                  <Shield className="h-3.5 w-3.5 text-amber-400" />
                  {t.nav.admin}
                </span>
              </NavLink>
            )}
          </nav>

          {/* Right Controls: Language Switcher + Auth + Mobile Drawer Toggle */}
          <div className="flex items-center gap-2">
            <div className="flex rounded-lg border border-slate-700 bg-slate-900/80 p-0.5 text-[11px]">
              {(["uz", "ru", "en"] as Lang[]).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => setLang(code)}
                  className={`rounded-md px-2 py-0.5 font-semibold uppercase ${
                    lang === code ? "bg-cyan-400 text-slate-950" : "text-slate-400 hover:text-white"
                  }`}
                >
                  {code}
                </button>
              ))}
            </div>

            {user ? (
              <div className="hidden items-center gap-2 sm:flex">
                <span className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-cyan-300">
                  @{user.username} • {user.coins.toLocaleString()} CX
                </span>
                <button
                  type="button"
                  onClick={() => void logout()}
                  className="rounded-lg border border-slate-700 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-800"
                >
                  {t.nav.logout}
                </button>
              </div>
            ) : (
              <Link
                to="/auth"
                className="hidden rounded-lg bg-cyan-400 px-3 py-1.5 text-xs font-semibold text-slate-950 hover:bg-cyan-300 sm:inline-block"
              >
                {t.nav.login}
              </Link>
            )}

            <button
              type="button"
              aria-label="Toggle menu"
              onClick={() => setMenuOpen((o) => !o)}
              className="rounded-lg border border-slate-700 p-1.5 text-slate-200 lg:hidden"
            >
              {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {menuOpen && (
          <div className="border-t border-slate-800 bg-[#071326] px-4 py-3 lg:hidden">
            <div className="grid grid-cols-2 gap-1.5">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === "/"}
                  onClick={() => setMenuOpen(false)}
                  className={linkClass}
                >
                  {item.label}
                </NavLink>
              ))}
              {isAdmin && (
                <NavLink to="/admin" onClick={() => setMenuOpen(false)} className={linkClass}>
                  {t.nav.admin}
                </NavLink>
              )}
            </div>
            <div className="mt-3 border-t border-slate-800 pt-3">
              {user ? (
                <div className="flex items-center justify-between text-xs">
                  <span className="text-cyan-300">
                    @{user.username} ({user.coins.toLocaleString()} CX / {user.gems} G)
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      void logout();
                    }}
                    className="rounded-lg border border-slate-700 px-3 py-1 text-slate-200"
                  >
                    {t.nav.logout}
                  </button>
                </div>
              ) : (
                <Link
                  to="/auth"
                  onClick={() => setMenuOpen(false)}
                  className="block w-full rounded-xl bg-cyan-400 py-2 text-center text-xs font-semibold text-slate-950"
                >
                  {t.nav.login}
                </Link>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6">
        <Outlet />
      </main>

      <footer className="border-t border-slate-800/80 bg-[#071326]/50 px-4 py-4 text-center text-xs text-slate-500">
        CityX (cityx.uz • @cityx_bot) — {t.brandTagline}
      </footer>
    </div>
  );
};
