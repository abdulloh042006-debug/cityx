import React, { useEffect, useRef, useState } from "react";
import { DistrictItem, LandmarkItem } from "../api/client";
import { CitySceneEngine, LightingMode, QualityMode } from "../three/CitySceneEngine";

interface Props {
  districts: DistrictItem[];
  landmarks: LandmarkItem[];
  focusCoords?: { x: number; z: number } | null;
  onSelectLandmark?: (id: string) => void;
}

function detectWebGLSupport(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return !!(window.WebGLRenderingContext && (canvas.getContext("webgl2") || canvas.getContext("webgl")));
  } catch {
    return false;
  }
}

export const City3DViewport: React.FC<Props> = ({ districts, landmarks, focusCoords, onSelectLandmark }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<CitySceneEngine | null>(null);
  const onSelectLandmarkRef = useRef(onSelectLandmark);
  const [quality, setQuality] = useState<QualityMode>("hd");
  const [lighting, setLighting] = useState<LightingMode>("night");
  const [fallback2D, setFallback2D] = useState<boolean>(() => !detectWebGLSupport());
  const [fps, setFps] = useState<number | null>(null);
  const [webglError, setWebglError] = useState<string | null>(null);
  const [contextLost, setContextLost] = useState<boolean>(false);

  // Keep latest callback in ref so unstable parent callbacks never recreate the WebGL renderer
  useEffect(() => {
    onSelectLandmarkRef.current = onSelectLandmark;
  }, [onSelectLandmark]);

  useEffect(() => {
    if (fallback2D || !containerRef.current) return;
    try {
      const engine = new CitySceneEngine(containerRef.current, districts, landmarks, quality, lighting, {
        onSelectLandmark: (id) => onSelectLandmarkRef.current?.(id),
        onFpsUpdate: setFps,
        onContextLost: () => {
          setContextLost(true);
          setWebglError("WebGL konteksti vaqtincha uzildi. Tiklanishi kutilmoqda yoki 2D rejimga o‘ting.");
        },
        onContextRestored: () => {
          setContextLost(false);
          setWebglError(null);
        },
      });
      engineRef.current = engine;
      setWebglError(null);
      setContextLost(false);
      return () => {
        engine.dispose();
        engineRef.current = null;
      };
    } catch (err) {
      setWebglError(err instanceof Error ? err.message : "WebGL ishga tushmadi");
      setFallback2D(true);
    }
  }, [districts, landmarks, quality, fallback2D]);

  useEffect(() => {
    engineRef.current?.setLighting(lighting);
  }, [lighting]);

  useEffect(() => {
    if (focusCoords) engineRef.current?.focusCoordinates(focusCoords.x, focusCoords.z);
  }, [focusCoords]);

  if (fallback2D) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-[#071326] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-sm font-semibold text-cyan-300">2D Shahar Sxemasi (Mobil / Yengil Rejim)</p>
            {webglError && <p className="text-xs text-amber-300">{webglError}</p>}
          </div>
          <button
            type="button"
            onClick={() => setFallback2D(false)}
            className="rounded-lg bg-cyan-500/20 px-3 py-1.5 text-xs font-medium text-cyan-200 hover:bg-cyan-500/30"
          >
            3D WebGL rejimiga qaytish
          </button>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {districts.map((d) => (
            <div key={d.id} className="rounded-xl border border-slate-700/70 bg-slate-900/70 p-3 text-center">
              <div className="text-xs font-bold text-cyan-300">{d.code}</div>
              <div className="mt-1 text-xs text-slate-200">{d.name}</div>
              <div className="mt-1 text-[11px] text-slate-400">
                X:{d.center_x} / Z:{d.center_z}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-[#03040A]">
      <div ref={containerRef} className="h-[420px] w-full sm:h-[520px]" />

      {/* Top HUD */}
      <div className="pointer-events-none absolute left-3 top-3 flex flex-wrap items-center gap-2">
        <span className="rounded-full border border-cyan-400/30 bg-[#071326]/85 px-3 py-1 text-xs font-semibold text-cyan-300">
          3D Foundation Scene {fps !== null ? `• ${fps} FPS` : ""}
        </span>
        <span className="rounded-full border border-amber-400/30 bg-[#071326]/85 px-3 py-1 text-[11px] text-amber-200">
          1200×1200m bazaviy sahna (2 barmoq: zoom + pan)
        </span>
      </div>

      {/* WebGL Context Lost Overlay */}
      {contextLost && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#03040A]/85 p-4 text-center">
          <p className="text-sm font-semibold text-amber-300">{webglError}</p>
          <button
            type="button"
            onClick={() => setFallback2D(true)}
            className="mt-3 rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950"
          >
            2D Rejimga o‘tish
          </button>
        </div>
      )}

      {/* Controls */}
      <div className="absolute bottom-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          {(["day", "sunset", "night"] as LightingMode[]).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setLighting(mode)}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium ${
                lighting === mode ? "bg-cyan-400 text-slate-950" : "bg-[#071326]/90 text-slate-200 border border-slate-700"
              }`}
            >
              {mode === "day" ? "Kunduz" : mode === "sunset" ? "Quyosh botishi" : "Tun"}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setQuality((q) => (q === "hd" ? "lite" : "hd"))}
            className="rounded-lg border border-slate-700 bg-[#071326]/90 px-2.5 py-1 text-xs text-slate-200"
          >
            Sifat: {quality.toUpperCase()}
          </button>
          <button
            type="button"
            onClick={() => setFallback2D(true)}
            className="rounded-lg border border-slate-700 bg-[#071326]/90 px-2.5 py-1 text-xs text-slate-200"
          >
            2D Rejim
          </button>
        </div>
        <div className="flex gap-1.5">
          <button
            type="button"
            onClick={() => engineRef.current?.zoom(-10)}
            className="rounded-lg border border-slate-700 bg-[#071326]/90 px-2.5 py-1 text-xs font-bold text-slate-100"
          >
            +
          </button>
          <button
            type="button"
            onClick={() => engineRef.current?.zoom(10)}
            className="rounded-lg border border-slate-700 bg-[#071326]/90 px-2.5 py-1 text-xs font-bold text-slate-100"
          >
            −
          </button>
          <button
            type="button"
            onClick={() => engineRef.current?.rotate(0.4)}
            className="rounded-lg border border-slate-700 bg-[#071326]/90 px-2.5 py-1 text-xs text-slate-100"
          >
            360°
          </button>
          <button
            type="button"
            onClick={() => engineRef.current?.resetCamera()}
            className="rounded-lg border border-slate-700 bg-[#071326]/90 px-2.5 py-1 text-xs text-slate-100"
          >
            Reset
          </button>
        </div>
      </div>
    </div>
  );
};
