import React from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import { I18nProvider } from "./i18n/I18nContext";
import { Layout } from "./components/Layout";
import { LandingPage } from "./pages/LandingPage";
import { AuthPage } from "./pages/AuthPage";
import { ProfilePage } from "./pages/ProfilePage";
import { DashboardPage } from "./pages/DashboardPage";
import { CityMapPage } from "./pages/CityMapPage";
import { City3DPage } from "./pages/City3DPage";
import { WalletPage } from "./pages/WalletPage";
import { PaymentsPage } from "./pages/PaymentsPage";
import { SettingsPage } from "./pages/SettingsPage";
import { SocialPage } from "./pages/SocialPage";
import { PlacesPage } from "./pages/PlacesPage";
import { AdminPage } from "./pages/AdminPage";

export const AppRoutes: React.FC = () => (
  <Routes>
    <Route element={<Layout />}>
      <Route path="/" element={<LandingPage />} />
      <Route path="/auth" element={<AuthPage />} />
      <Route path="/dashboard" element={<DashboardPage />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/map" element={<CityMapPage />} />
      <Route path="/city-3d" element={<City3DPage />} />
      <Route path="/wallet" element={<WalletPage />} />
      <Route path="/payments" element={<PaymentsPage />} />
      <Route path="/settings" element={<SettingsPage />} />
      <Route path="/social" element={<SocialPage />} />
      <Route path="/places" element={<PlacesPage />} />
      <Route path="/admin" element={<AdminPage />} />
      {/* Telegram Mini App deep-link routes */}
      <Route path="/app" element={<Navigate to="/city-3d" replace />} />
      <Route path="/app/city" element={<Navigate to="/map" replace />} />
      <Route path="/app/city/taxi" element={<Navigate to="/map" replace />} />
      <Route path="/app/property" element={<Navigate to="/profile" replace />} />
      <Route path="/app/property/:propertyId" element={<Navigate to="/profile" replace />} />
      <Route path="/app/garage" element={<Navigate to="/profile" replace />} />
      <Route path="/app/racing" element={<Navigate to="/city-3d" replace />} />
      <Route path="/app/events" element={<Navigate to="/places" replace />} />
      <Route path="/app/events/elections" element={<Navigate to="/places" replace />} />
      <Route path="/app/events/:eventId" element={<Navigate to="/places" replace />} />
      <Route path="/app/economy/topup" element={<Navigate to="/payments" replace />} />
      <Route path="/app/economy/transactions" element={<Navigate to="/wallet" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Route>
  </Routes>
);

export const App: React.FC = () => (
  <I18nProvider>
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  </I18nProvider>
);

export default App;
