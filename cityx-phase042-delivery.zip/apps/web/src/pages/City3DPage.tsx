import React, { useCallback, useEffect, useState } from "react";
import { api, DistrictItem, LandmarkItem } from "../api/client";
import { City3DViewport } from "../components/City3DViewport";
import { ErrorBox, LoadingBox, PageHeader } from "../components/UI";

export const City3DPage: React.FC = () => {
  const [districts, setDistricts] = useState<DistrictItem[]>([]);
  const [landmarks, setLandmarks] = useState<LandmarkItem[]>([]);
  const [focus, setFocus] = useState<{ x: number; z: number } | null>(null);
  const [selectedLandmarkId, setSelectedLandmarkId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getCityMap();
      setDistricts(res.districts);
      setLandmarks(res.landmarks);
    } catch (err) {
      setError(err instanceof Error ? err.message : "3D shahar ma’lumotlari yuklanmadi");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const selectedLm = landmarks.find((l) => l.id === selectedLandmarkId) || null;

  return (
    <div className="space-y-4">
      <PageHeader
        title="3D Shahar Tadqiqoti (Three.js Foundation)"
        subtitle="Real Three.js WebGL bazaviy muhiti, HD/Lite sifat va mobil 2D zaxira rejimi. Yuqori detallikdagi GLB modellar Phase 1–2 da yuklanadi."
      />
      {error && <ErrorBox message={error} onRetry={() => void load()} />}
      {loading ? (
        <LoadingBox />
      ) : (
        <>
          <div className="flex flex-wrap gap-2">
            {districts.map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => setFocus({ x: d.center_x, z: d.center_z })}
                className="rounded-lg border border-slate-700 bg-[#071326] px-3 py-1.5 text-xs text-slate-200 hover:border-cyan-400"
              >
                {d.code}: {d.name}
              </button>
            ))}
          </div>

          <City3DViewport
            districts={districts}
            landmarks={landmarks}
            focusCoords={focus}
            onSelectLandmark={setSelectedLandmarkId}
          />

          {selectedLm && (
            <div className="rounded-2xl border border-cyan-400/40 bg-[#071326] p-4 text-xs">
              <div className="font-bold text-cyan-300">{selectedLm.name}</div>
              <div className="mt-1 text-slate-300">
                Tuman: {selectedLm.district_id} • Narx: {selectedLm.current_price_coins.toLocaleString()} CX • Ega:{" "}
                {selectedLm.owner_username ? `@${selectedLm.owner_username}` : "Bo‘sh"}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
