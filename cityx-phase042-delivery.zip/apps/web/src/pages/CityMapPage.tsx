import React, { useCallback, useEffect, useState } from "react";
import { api, DistrictItem, LandmarkItem } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { ErrorBox, LoadingBox, PageHeader } from "../components/UI";

export const CityMapPage: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [districts, setDistricts] = useState<DistrictItem[]>([]);
  const [landmarks, setLandmarks] = useState<LandmarkItem[]>([]);
  const [fares, setFares] = useState<Record<string, { fare_coins: number; eta_min: number }>>({});
  const [selectedDistrict, setSelectedDistrict] = useState<string>("downtown");
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getCityMap();
      setDistricts(res.districts);
      setLandmarks(res.landmarks);
      setFares(res.taxi_fares);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Xarita ma’lumotlari yuklanmadi");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function takeTaxi(districtId: string) {
    if (!user) {
      setError("Taksi buyurtma qilish uchun hisobingizga kiring.");
      return;
    }
    setNotice(null);
    setError(null);
    try {
      const reqId = `web_taxi_${Date.now()}_${districtId}`;
      const res = await api.bookTaxi(districtId, reqId);
      setNotice(`${res.district_name} tumaniga yetib keldingiz! (-${res.fare_coins} CX, qoldiq: ${res.balance_after} CX)`);
      await refreshUser();
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Taksi xatosi");
    }
  }

  async function buyLandmark(lm: LandmarkItem) {
    if (!user) {
      setError("Obida sotib olish uchun hisobingizga kiring.");
      return;
    }
    setNotice(null);
    setError(null);
    try {
      const res = await api.acquireLandmark(lm.id, lm.version);
      setNotice(`${lm.name} sizning mulkingizga o‘tdi! Yangi narx: ${res.next_price_coins.toLocaleString()} CX`);
      await refreshUser();
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sotib olish amalga oshmadi");
    }
  }

  if (loading) return <LoadingBox />;

  return (
    <div className="space-y-6">
      <PageHeader title="Interaktiv Shahar Xaritasi (1200×1200m)" subtitle="8 ta kanonik Toshkent tumani, taksi qatnovi va atomik obida egaligi" />
      {error && <ErrorBox message={error} onRetry={() => void load()} />}
      {notice && <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{notice}</div>}

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {districts.map((d) => {
          const fare = fares[d.id];
          const isActive = selectedDistrict === d.id;
          return (
            <div
              key={d.id}
              onClick={() => setSelectedDistrict(d.id)}
              className={`cursor-pointer rounded-2xl border p-4 transition ${
                isActive ? "border-cyan-400 bg-cyan-950/30" : "border-slate-800 bg-[#071326]/70 hover:border-slate-600"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-300">{d.code}</span>
                <span className="text-[11px] text-slate-400">X:{d.center_x} Z:{d.center_z}</span>
              </div>
              <h2 className="mt-1 text-sm font-bold text-white">{d.name}</h2>
              <p className="mt-1 text-xs text-slate-400">{d.description}</p>
              {fare && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    void takeTaxi(d.id);
                  }}
                  className="mt-3 w-full rounded-lg bg-cyan-400/15 py-1.5 text-xs font-semibold text-cyan-200 hover:bg-cyan-400/25"
                >
                  Taksi ({fare.fare_coins} CX • {fare.eta_min} daq)
                </button>
              )}
            </div>
          );
        })}
      </div>

      <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
        <h2 className="mb-3 text-base font-bold text-white">Noyob obidalar (Atomik +20% overbid)</h2>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {landmarks.map((lm) => (
            <div key={lm.id} className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 text-xs">
              <div className="font-bold text-white">{lm.name}</div>
              <div className="mt-1 text-slate-400">
                Tuman: {lm.district_id} • Ega: {lm.owner_username ? `@${lm.owner_username}` : "Bo‘sh"}
              </div>
              <div className="mt-2 flex items-center justify-between">
                <span className="font-semibold text-amber-300">{lm.current_price_coins.toLocaleString()} CX</span>
                <button
                  type="button"
                  onClick={() => void buyLandmark(lm)}
                  className="rounded-lg bg-amber-400/20 px-3 py-1 font-semibold text-amber-200 hover:bg-amber-400/30"
                >
                  Sotib olish (v{lm.version})
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
