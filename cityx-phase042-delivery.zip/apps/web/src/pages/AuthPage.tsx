import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { ErrorBox, PageHeader } from "../components/UI";

type Tab = "login" | "register" | "recovery";

const DISTRICTS = [
  "residential",
  "downtown",
  "business",
  "university",
  "entertainment",
  "nature",
  "transport",
  "vip",
];

const USERNAME_RE = /^[a-zA-Z0-9._]{3,24}$/;

export const AuthPage: React.FC = () => {
  const { setSession } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();

  const [tab, setTab] = useState<Tab>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [instagram, setInstagram] = useState("");
  const [districtId, setDistrictId] = useState("residential");

  const [recoveryId, setRecoveryId] = useState("");
  const [recoveryToken, setRecoveryToken] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);

  const busy = busyAction !== null;

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    const cleanUser = username.trim();
    if (cleanUser.length < 3) {
      setError("Foydalanuvchi nomi kamida 3 belgidan iborat bo‘lishi kerak.");
      return;
    }
    if (!password) {
      setError("Parolni kiriting.");
      return;
    }
    setBusyAction("login");
    setError(null);
    setNotice(null);
    try {
      const res = await api.login({ username: cleanUser, password });
      setSession(res.accessToken, res.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Kirishda xatolik");
    } finally {
      setBusyAction(null);
    }
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    const cleanUser = username.trim();
    if (!USERNAME_RE.test(cleanUser)) {
      setError("Foydalanuvchi nomi 3–24 belgi (lotin harf, raqam, . yoki _) bo‘lishi kerak.");
      return;
    }
    if (password.length < 8) {
      setError("Parol kamida 8 belgidan iborat bo‘lishi kerak.");
      return;
    }
    setBusyAction("register");
    setError(null);
    setNotice(null);
    try {
      const res = await api.register({
        username: cleanUser,
        password,
        instagram_handle: instagram.trim(),
        district_id: districtId,
      });
      setSession(res.accessToken, res.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ro‘yxatdan o‘tishda xatolik");
    } finally {
      setBusyAction(null);
    }
  }

  async function handleTelegramAuth() {
    const tg = (window as unknown as { Telegram?: { WebApp?: { initData?: string } } }).Telegram?.WebApp;
    if (!tg?.initData) {
      setError("Telegram Mini App muhiti aniqlanmadi. @cityx_bot orqali oching.");
      return;
    }
    setBusyAction("telegram");
    setError(null);
    setNotice(null);
    try {
      const res = await api.miniAppAuth(tg.initData);
      setSession(res.accessToken, res.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Telegram autentifikatsiyasi rad etildi");
    } finally {
      setBusyAction(null);
    }
  }

  async function handleRecoveryRequest(e: React.FormEvent) {
    e.preventDefault();
    const ident = recoveryId.trim();
    if (ident.length < 3) {
      setError("Foydalanuvchi nomi yoki email kamida 3 belgi bo‘lishi kerak.");
      return;
    }
    setBusyAction("recovery-request");
    setError(null);
    setNotice(null);
    try {
      const res = await api.requestRecovery(ident);
      setNotice(res.delivery_notice);
    } catch (err) {
      setError(err instanceof Error ? err.message : "So‘rov yuborilmadi");
    } finally {
      setBusyAction(null);
    }
  }

  async function handleRecoveryConfirm(e: React.FormEvent) {
    e.preventDefault();
    const tok = recoveryToken.trim();
    if (tok.length < 16) {
      setError("Tasdiqlangan tiklash tokeni kamida 16 belgidan iborat bo‘lishi kerak.");
      return;
    }
    if (newPassword.length < 8) {
      setError("Yangi parol kamida 8 belgidan iborat bo‘lishi kerak.");
      return;
    }
    setBusyAction("recovery-confirm");
    setError(null);
    setNotice(null);
    try {
      await api.confirmRecovery(tok, newPassword);
      setRecoveryToken("");
      setNewPassword("");
      setNotice("Parol muvaffaqiyatli yangilandi. Endi yangi parol bilan kiring.");
      setTab("login");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Token tasdiqlanmadi");
    } finally {
      setBusyAction(null);
    }
  }

  return (
    <div className="mx-auto max-w-lg">
      <PageHeader title="CityX Hisob" subtitle="Web, Telegram Mini App va @cityx_bot uchun yagona hisob" />

      <div className="mb-4 grid grid-cols-3 gap-2 rounded-2xl border border-slate-800 bg-[#071326] p-1.5">
        {(["login", "register", "recovery"] as Tab[]).map((key) => (
          <button
            key={key}
            type="button"
            disabled={busy}
            onClick={() => {
              setTab(key);
              setError(null);
              setNotice(null);
              setPassword("");
              setNewPassword("");
            }}
            className={`rounded-xl py-2 text-xs font-semibold ${
              tab === key ? "bg-cyan-400 text-slate-950" : "text-slate-300 hover:text-white"
            }`}
          >
            {key === "login" ? t.auth.loginTab : key === "register" ? t.auth.registerTab : t.auth.recoveryTab}
          </button>
        ))}
      </div>

      {error && (
        <div role="alert" className="mb-4">
          <ErrorBox message={error} />
        </div>
      )}
      {notice && (
        <div role="status" className="mb-4 rounded-2xl border border-cyan-400/40 bg-cyan-950/30 p-4 text-xs text-cyan-200">
          {notice}
        </div>
      )}

      {tab === "login" && (
        <form onSubmit={handleLogin} noValidate className="space-y-4 rounded-2xl border border-slate-800 bg-[#071326]/80 p-6">
          <div>
            <label htmlFor="login-username" className="block text-xs text-slate-300">{t.auth.username}</label>
            <input
              id="login-username"
              required
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="login-password" className="block text-xs text-slate-300">{t.auth.password}</label>
            <input
              id="login-password"
              required
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
            />
          </div>
          <button
            disabled={busy}
            type="submit"
            className="w-full rounded-xl bg-cyan-400 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
          >
            {busyAction === "login" ? t.common.loading : t.auth.loginBtn}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => void handleTelegramAuth()}
            className="w-full rounded-xl border border-cyan-400/40 bg-cyan-500/10 py-2.5 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/20 disabled:opacity-50"
          >
            {busyAction === "telegram" ? t.common.loading : t.auth.tgLoginBtn}
          </button>
        </form>
      )}

      {tab === "register" && (
        <form onSubmit={handleRegister} noValidate className="space-y-4 rounded-2xl border border-slate-800 bg-[#071326]/80 p-6">
          <div>
            <label htmlFor="reg-username" className="block text-xs text-slate-300">{t.auth.username}</label>
            <input
              id="reg-username"
              required
              minLength={3}
              maxLength={24}
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="reg-password" className="block text-xs text-slate-300">{t.auth.password} (min 8)</label>
            <input
              id="reg-password"
              required
              minLength={8}
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="reg-instagram" className="block text-xs text-slate-300">{t.auth.instagram}</label>
            <input
              id="reg-instagram"
              maxLength={64}
              value={instagram}
              onChange={(e) => setInstagram(e.target.value)}
              placeholder="@cityx.uz"
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="reg-district" className="block text-xs text-slate-300">{t.common.district}</label>
            <select
              id="reg-district"
              value={districtId}
              onChange={(e) => setDistrictId(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
            >
              {DISTRICTS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>
          <button
            disabled={busy}
            type="submit"
            className="w-full rounded-xl bg-cyan-400 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
          >
            {busyAction === "register" ? t.common.loading : t.auth.registerBtn}
          </button>
        </form>
      )}

      {tab === "recovery" && (
        <div className="space-y-4">
          <form onSubmit={handleRecoveryRequest} noValidate className="space-y-3 rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
            <h2 className="text-sm font-semibold text-white">1. {t.auth.recoveryRequestBtn}</h2>
            <input
              required
              minLength={3}
              maxLength={128}
              value={recoveryId}
              onChange={(e) => setRecoveryId(e.target.value)}
              placeholder={t.auth.recoveryIdentifier}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
            <button
              disabled={busy}
              type="submit"
              className="rounded-xl bg-cyan-400/20 px-4 py-2 text-xs font-semibold text-cyan-200 hover:bg-cyan-400/30 disabled:opacity-50"
            >
              {busyAction === "recovery-request" ? t.common.loading : t.auth.recoveryRequestBtn}
            </button>
          </form>

          <form onSubmit={handleRecoveryConfirm} noValidate className="space-y-3 rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
            <h2 className="text-sm font-semibold text-white">2. {t.auth.recoveryConfirmBtn}</h2>
            <input
              required
              minLength={16}
              maxLength={128}
              value={recoveryToken}
              onChange={(e) => setRecoveryToken(e.target.value)}
              placeholder={t.auth.recoveryToken}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
            <input
              required
              minLength={8}
              maxLength={128}
              type="password"
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder={t.auth.newPassword}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
            <button
              disabled={busy}
              type="submit"
              className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
            >
              {busyAction === "recovery-confirm" ? t.common.loading : t.auth.recoveryConfirmBtn}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
