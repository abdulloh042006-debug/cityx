import React, { useCallback, useEffect, useState } from "react";
import { api, PaymentOrder } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { AuthGate, ErrorBox, LoadingBox, PageHeader, StatusBadge } from "../components/UI";

export const AdminPage: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const { t } = useI18n();

  const [overview, setOverview] = useState<Record<string, number> | null>(null);
  const [orders, setOrders] = useState<PaymentOrder[]>([]);
  const [users, setUsers] = useState<Array<Record<string, unknown>>>([]);
  const [audit, setAudit] = useState<{ admin_audit_logs: Array<Record<string, unknown>>; payment_audit_logs: Array<Record<string, unknown>> } | null>(null);
  const [rejectReasons, setRejectReasons] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (showSpinner = true) => {
    if (showSpinner) setLoading(true);
    setError(null);
    try {
      const [ov, pay, us, au] = await Promise.all([
        api.adminOverview(),
        api.adminPayments(),
        api.adminUsers(),
        api.adminAuditLogs(),
      ]);
      setOverview(ov.overview);
      setOrders(pay.orders);
      setUsers(us.users);
      setAudit({ admin_audit_logs: au.admin_audit_logs, payment_audit_logs: au.payment_audit_logs });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Admin ma’lumotlari yuklanmadi");
    } finally {
      if (showSpinner) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user && isAdmin) void load(true);
  }, [user, isAdmin, load]);

  if (!user) return <AuthGate />;
  if (!isAdmin) return <ErrorBox message={t.admin.forbidden} />;
  if (loading && !overview) return <LoadingBox />;

  async function approve(orderId: string) {
    setBusyAction(`approve:${orderId}`);
    setMsg(null);
    setError(null);
    try {
      await api.adminApprovePayment(orderId);
      setMsg(`Buyurtma ${orderId} tasdiqlandi va paket bir marta qo‘shildi.`);
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Tasdiqlash xatosi");
    } finally {
      setBusyAction(null);
    }
  }

  async function reject(e: React.FormEvent, orderId: string) {
    e.preventDefault();
    const reason = (rejectReasons[orderId] || "").trim();
    if (reason.length < 3 || reason.length > 300) {
      setError("Rad etish sababi 3–300 belgidan iborat bo‘lishi kerak.");
      return;
    }
    setBusyAction(`reject:${orderId}`);
    setMsg(null);
    setError(null);
    try {
      await api.adminRejectPayment(orderId, reason);
      setRejectReasons((prev) => {
        const next = { ...prev };
        delete next[orderId];
        return next;
      });
      setMsg(`Buyurtma ${orderId} rad etildi (0 valyuta qo‘shildi).`);
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Rad etish xatosi");
    } finally {
      setBusyAction(null);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title={t.admin.title} subtitle="Serverda tasdiqlangan RBAC boshqaruvi, qo‘lda to‘lov tekshiruvi va append-only audit jurnali" />
      {error && <div role="alert"><ErrorBox message={error} onRetry={() => void load(false)} /></div>}
      {msg && <div role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{msg}</div>}

      {overview && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {Object.entries(overview).map(([k, v]) => (
            <div key={k} className="rounded-xl border border-slate-800 bg-[#071326]/80 p-3">
              <div className="text-[11px] text-slate-400">{k}</div>
              <div className="mt-1 font-display text-xl font-bold text-cyan-300">{v}</div>
            </div>
          ))}
        </div>
      )}

      <section className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
        <h2 className="mb-3 text-base font-bold text-white">Qo‘lda bank o‘tkazmalari navbati</h2>
        {orders.length === 0 ? (
          <p className="text-xs text-slate-400">Buyurtmalar yo‘q.</p>
        ) : (
          <div className="space-y-3 text-xs">
            {orders.map((o) => {
              const approving = busyAction === `approve:${o.order_id}`;
              const rejecting = busyAction === `reject:${o.order_id}`;
              const rowBusy = busyAction !== null;
              return (
                <div key={o.order_id} className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-bold text-white">
                      {o.order_id} • @{o.user_username || o.user_id} • {o.payment_network_snapshot} (****{o.card_last4_snapshot})
                    </div>
                    <StatusBadge status={o.status} />
                  </div>
                  <div className="text-slate-300">
                    Qabul qiluvchi: <strong>{o.recipient_name_snapshot}</strong> • Bank: {o.payment_bank_snapshot || "Tasdiqlanmagan"} •{" "}
                    Summa: <strong className="text-amber-300">{o.expected_amount_uzs.toLocaleString()} UZS</strong> → {o.reward_amount} {o.reward_currency.toUpperCase()}
                  </div>
                  <div className="text-slate-400">
                    Ref: {o.submitted_reference || "—"} • Chek: {o.receipt_object_key ? `Yuklangan (${o.receipt_mime_type})` : "Yo‘q"}
                  </div>
                  {o.status === "pending_review" && (
                    <form onSubmit={(e) => void reject(e, o.order_id)} noValidate className="flex flex-wrap items-center gap-2 pt-2">
                      <button
                        type="button"
                        disabled={rowBusy}
                        onClick={() => void approve(o.order_id)}
                        className="rounded-lg bg-emerald-400 px-3 py-1.5 font-bold text-slate-950 hover:bg-emerald-300 disabled:opacity-50"
                      >
                        {approving ? t.common.loading : t.admin.approve}
                      </button>
                      <input
                        aria-label={`Rad etish sababi ${o.order_id}`}
                        minLength={3}
                        maxLength={300}
                        disabled={rowBusy}
                        value={rejectReasons[o.order_id] || ""}
                        onChange={(e) => setRejectReasons((prev) => ({ ...prev, [o.order_id]: e.target.value }))}
                        placeholder={t.admin.rejectReasonPlaceholder}
                        className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white"
                      />
                      <button
                        type="submit"
                        disabled={rowBusy}
                        className="rounded-lg bg-rose-500/20 px-3 py-1.5 font-semibold text-rose-200 hover:bg-rose-500/30 disabled:opacity-50"
                      >
                        {rejecting ? t.common.loading : t.admin.reject}
                      </button>
                    </form>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <h2 className="mb-3 text-base font-bold text-white">Fuqarolar ({users.length})</h2>
          <div className="space-y-2 text-xs">
            {users.map((u) => (
              <div key={String(u.id)} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2">
                <span>@{String(u.username)} ({String(u.role)}) • {String(u.coins)} CX / {String(u.gems)} G</span>
                <span className={Number(u.is_banned) ? "text-rose-400" : "text-emerald-400"}>
                  {Number(u.is_banned) ? "BANNED" : "ACTIVE"}
                </span>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <h2 className="mb-3 text-base font-bold text-white">Append-Only Admin Audit Jurnali</h2>
          <div className="space-y-2 text-xs">
            {(audit?.admin_audit_logs || []).slice(0, 12).map((a) => (
              <div key={String(a.id)} className="rounded-xl border border-slate-800 bg-slate-950/60 p-2.5">
                <div className="font-semibold text-cyan-300">{String(a.action)} → {String(a.target_entity)}</div>
                <div className="text-slate-400">{String(a.reason || a.details_json || "")}</div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
