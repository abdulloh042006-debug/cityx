import React, { useCallback, useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { AuthGate, ErrorBox, LoadingBox, PageHeader } from "../components/UI";

const AVATAR_PRESETS = [
  { id: "preset:cyan-architect", label: "Me’mor", bg: "from-cyan-400 to-blue-600" },
  { id: "preset:gold-vip", label: "VIP", bg: "from-amber-300 to-yellow-600" },
  { id: "preset:emerald-mahalla", label: "Mahalla", bg: "from-emerald-400 to-teal-600" },
  { id: "preset:neon-racer", label: "Poygachi", bg: "from-fuchsia-400 to-indigo-600" },
];

export const ProfilePage: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const { t } = useI18n();
  const [bundle, setBundle] = useState<Awaited<ReturnType<typeof api.getProfileMe>> | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [instagram, setInstagram] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("preset:cyan-architect");
  const [floors, setFloors] = useState(2);
  const [hasPool, setHasPool] = useState(false);
  const [hasHelipad, setHasHelipad] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingHome, setSavingHome] = useState(false);

  const load = useCallback(async (showSpinner = true) => {
    if (showSpinner) setLoading(true);
    setLoadError(null);
    try {
      const res = await api.getProfileMe();
      setBundle(res);
      setDisplayName(res.user.display_name || res.user.username);
      setBio(res.user.bio || "");
      setInstagram(res.user.instagram_handle || "");
      setAvatarUrl(res.user.avatar_url || "preset:cyan-architect");
      if (res.home) {
        setFloors(Number(res.home.floors || 2));
        setHasPool(Boolean(res.home.has_pool));
        setHasHelipad(Boolean(res.home.has_helipad));
      }
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : "Profil yuklanmadi");
    } finally {
      if (showSpinner) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) void load(true);
  }, [user, load]);

  if (!user) return <AuthGate />;
  if (loading && !bundle) return <LoadingBox />;
  if (loadError && !bundle) return <ErrorBox message={loadError} onRetry={() => void load(true)} />;

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    const cleanName = displayName.trim();
    if (cleanName.length < 2 || cleanName.length > 48) {
      setFormError("Ko‘rinadigan ism 2–48 belgidan iborat bo‘lishi kerak.");
      return;
    }
    if (bio.trim().length > 240) {
      setFormError("Bio 240 belgidan oshmasligi kerak.");
      return;
    }
    setSavingProfile(true);
    setMsg(null);
    setFormError(null);
    try {
      await api.updateProfile({
        display_name: cleanName,
        bio: bio.trim(),
        instagram_handle: instagram.trim(),
        avatar_url: avatarUrl,
      });
      await refreshUser();
      await load(false);
      setMsg("Profil va avatar saqlandi.");
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Saqlashda xatolik");
    } finally {
      setSavingProfile(false);
    }
  }

  async function saveHome(e: React.FormEvent) {
    e.preventDefault();
    if (floors < 1 || floors > 50) {
      setFormError("Qavatlar soni 1 dan 50 gacha bo‘lishi kerak.");
      return;
    }
    setSavingHome(true);
    setMsg(null);
    setFormError(null);
    try {
      await api.updateHome({ floors, has_pool: hasPool, has_helipad: hasHelipad });
      await load(false);
      setMsg("Uy parametrlari (1–50 qavat) bazaga saqlandi.");
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Uy saqlanmadi");
    } finally {
      setSavingHome(false);
    }
  }

  const presetObj = AVATAR_PRESETS.find((p) => p.id === avatarUrl) || AVATAR_PRESETS[0];

  return (
    <div className="space-y-6">
      <PageHeader title={`Profil — @${user.username}`} subtitle={`Daraja ${user.level} • Tuman: ${user.district_id} • Obro‘: ${user.reputation_score}`} />
      {formError && <div role="alert"><ErrorBox message={formError} /></div>}
      {msg && <div role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{msg}</div>}

      <div className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={saveProfile} noValidate className="space-y-4 rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <div className="flex items-center gap-4">
            <div className={`flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${presetObj.bg} font-display text-xl font-bold text-slate-950`}>
              {(displayName.trim() || user.username).slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="font-semibold text-white">{displayName || user.username}</div>
              <div className="text-xs text-slate-400">Uy layklari: {bundle?.home_likes_count ?? 0}</div>
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-300">Avatar uslubi</label>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {AVATAR_PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  disabled={savingProfile}
                  onClick={() => setAvatarUrl(p.id)}
                  className={`rounded-xl border px-2 py-2 text-xs font-medium ${
                    avatarUrl === p.id ? "border-cyan-400 bg-cyan-400/15 text-cyan-200" : "border-slate-700 text-slate-300"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="prof-display-name" className="block text-xs text-slate-300">Ko‘rinadigan ism</label>
            <input
              id="prof-display-name"
              required
              minLength={2}
              maxLength={48}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="prof-bio" className="block text-xs text-slate-300">Bio ({bio.length}/240)</label>
            <textarea
              id="prof-bio"
              rows={2}
              maxLength={240}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="prof-instagram" className="block text-xs text-slate-300">Instagram (ochiq profil nomi)</label>
            <input
              id="prof-instagram"
              maxLength={32}
              value={instagram}
              onChange={(e) => setInstagram(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
          </div>
          <button
            type="submit"
            disabled={savingProfile}
            className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
          >
            {savingProfile ? t.common.loading : "Profilni saqlash"}
          </button>
        </form>

        <div className="space-y-4">
          <form onSubmit={saveHome} noValidate className="space-y-4 rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
            <h2 className="text-base font-bold text-white">
              Mening uyim ({String(bundle?.home?.plot_code || "Uchastka")})
            </h2>
            <div>
              <label htmlFor="home-floors" className="block text-xs text-slate-300">Qavatlar soni (1–50): {floors}</label>
              <input
                id="home-floors"
                type="range"
                min={1}
                max={50}
                value={floors}
                onChange={(e) => setFloors(Number(e.target.value))}
                className="mt-2 w-full accent-cyan-400"
              />
            </div>
            <div className="flex flex-wrap gap-4 text-xs text-slate-300">
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={hasPool} onChange={(e) => setHasPool(e.target.checked)} /> Basseyn
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={hasHelipad} onChange={(e) => setHasHelipad(e.target.checked)} /> Vertolyot maydonchasi
              </label>
            </div>
            <button
              type="submit"
              disabled={savingHome}
              className="rounded-xl bg-cyan-400/20 px-4 py-2 text-xs font-semibold text-cyan-200 hover:bg-cyan-400/30 disabled:opacity-50"
            >
              {savingHome ? t.common.loading : "Uyni yangilash"}
            </button>
          </form>

          <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
            <h2 className="text-base font-bold text-white">Garaj va noyob obidalar</h2>
            <p className="mt-1 text-xs text-slate-400">
              Avtomobillar: {bundle?.vehicles.length ?? 0} ta • Noyob obidalar: {bundle?.owned_landmarks.length ?? 0} ta
            </p>
            <div className="mt-3 space-y-2 text-xs">
              {bundle?.vehicles.map((v) => (
                <div key={String(v.id)} className="flex justify-between rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2">
                  <span>{String(v.display_name || v.model_code)}</span>
                  <span className="text-cyan-300">{String(v.vehicle_class || "STANDARD")} • {String(v.rating || 500)} PR</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
