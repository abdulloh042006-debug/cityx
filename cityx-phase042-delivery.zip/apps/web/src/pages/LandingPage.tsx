import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Building2, Compass, ShieldCheck, Wallet } from "lucide-react";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { ErrorBox } from "../components/UI";

export const LandingPage: React.FC = () => {
  const { user } = useAuth();
  const { t } = useI18n();
  const [overview, setOverview] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getOverview()
      .then((res) => setOverview(res.overview))
      .catch((err) => setError(err instanceof Error ? err.message : "API ulanmadi"));
  }, []);

  const stats = [
    { label: t.landing.statsDistricts, value: overview ? String(overview.districts_count ?? "8") : "—" },
    { label: t.landing.statsLandmarks, value: overview ? String(overview.landmarks_count ?? "6") : "—" },
    { label: t.landing.statsPlaces, value: overview ? String(overview.places_count ?? "15") : "—" },
    { label: t.landing.statsCitizens, value: overview ? String(overview.citizens_count ?? "0") : "—" },
  ];

  return (
    <div className="space-y-8">
      <section className="rounded-3xl border border-cyan-400/20 bg-gradient-to-br from-[#071326] via-[#091b36] to-[#03040A] p-6 sm:p-10">
        <span className="inline-flex items-center rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-xs font-semibold text-cyan-300">
          cityx.uz • @cityx_bot • Phase 0.4
        </span>
        <h1 className="mt-4 max-w-3xl text-3xl font-bold leading-tight text-white sm:text-5xl">
          {t.landing.heroTitle}
        </h1>
        <p className="mt-4 max-w-2xl text-sm text-slate-300 sm:text-base">{t.landing.heroDesc}</p>

        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            to="/city-3d"
            className="rounded-xl bg-cyan-400 px-5 py-3 text-sm font-bold text-slate-950 hover:bg-cyan-300"
          >
            {t.landing.enterCity}
          </Link>
          {user ? (
            <Link
              to="/dashboard"
              className="rounded-xl border border-slate-700 bg-slate-900/80 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800"
            >
              {t.landing.openDashboard}
            </Link>
          ) : (
            <Link
              to="/auth"
              className="rounded-xl border border-slate-700 bg-slate-900/80 px-5 py-3 text-sm font-semibold text-white hover:bg-slate-800"
            >
              {t.landing.getStarted}
            </Link>
          )}
        </div>
      </section>

      {error && <ErrorBox message={`Backend API holati: ${error}`} />}

      <section className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-slate-800 bg-[#071326]/70 p-4">
            <div className="text-xs text-slate-400">{s.label}</div>
            <div className="mt-1 font-display text-2xl font-bold text-cyan-300">{s.value}</div>
          </div>
        ))}
      </section>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { icon: Compass, title: "8 ta rasmiy tuman", desc: "1200×1200m deterministik 3×3 Toshkent xaritasi va taksi qatnovi.", to: "/map" },
          { icon: Building2, title: "1–50 qavatli uylar", desc: "Shaxsiy uchastka, bino qavatlari va noyob obidalarga egalik.", to: "/profile" },
          { icon: Wallet, title: "Qo‘lda bank o‘tkazmasi", desc: "Faqat ikki alohida karta (Visa va Uzcard) va admin tasdig‘i.", to: "/payments" },
          { icon: ShieldCheck, title: "Yagona server xavfsizligi", desc: "PostgreSQL tranzaksiyalari, RBAC va append-only audit jurnali.", to: "/social" },
        ].map((card) => (
          <Link
            key={card.title}
            to={card.to}
            className="rounded-2xl border border-slate-800 bg-[#071326]/60 p-5 transition hover:border-cyan-400/40"
          >
            <card.icon className="h-6 w-6 text-cyan-300" />
            <h2 className="mt-3 text-base font-bold text-white">{card.title}</h2>
            <p className="mt-1 text-xs text-slate-400">{card.desc}</p>
          </Link>
        ))}
      </section>
    </div>
  );
};
