import React, { useCallback, useEffect, useRef, useState } from "react";
import { api, PaymentMethod, PaymentOrder, PaymentPackage, TransferInstructions } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { AuthGate, ErrorBox, LoadingBox, PageHeader, StatusBadge } from "../components/UI";

const MAX_RECEIPT_BYTES = 5 * 1024 * 1024;
const ALLOWED_RECEIPT_MIMES = new Set(["image/png", "image/jpeg", "image/webp", "application/pdf"]);
const UNSAFE_REF_RE = /(https?:\/\/|javascript:|data:|file:\/\/)/i;

function makeAttemptKey(userId: string, method: string, pkg: string): string {
  const rand = typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID().slice(0, 12)
    : `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  return `web_order_${userId}_${method}_${pkg}_${rand}`;
}

export const PaymentsPage: React.FC = () => {
  const { user } = useAuth();
  const { t } = useI18n();

  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [packages, setPackages] = useState<PaymentPackage[]>([]);
  const [orders, setOrders] = useState<PaymentOrder[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<"uzum_visa" | "uzcard">("uzum_visa");
  const [selectedPkg, setSelectedPkg] = useState<string>("gems_100");
  const [activeOrder, setActiveOrder] = useState<PaymentOrder | null>(null);
  const [instructions, setInstructions] = useState<TransferInstructions | null>(null);
  const [txRef, setTxRef] = useState("");
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const pendingIdemKeyRef = useRef<string | null>(null);
  const busy = busyAction !== null;

  const load = useCallback(async (showSpinner = true) => {
    if (showSpinner) setLoading(true);
    setError(null);
    try {
      const [mRes, pRes, oRes] = await Promise.all([
        api.getPaymentMethods(),
        api.getPaymentPackages(),
        api.listMyOrders(),
      ]);
      setMethods(mRes.methods);
      setPackages(pRes.packages);
      setOrders(oRes.orders);
      if (pRes.packages.length > 0) setSelectedPkg((prev) => prev || pRes.packages[0].id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "To‘lov ma’lumotlari yuklanmadi");
    } finally {
      if (showSpinner) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) void load(true);
  }, [user, load]);

  // Reset attempt idempotency key whenever selection changes
  useEffect(() => {
    pendingIdemKeyRef.current = null;
  }, [selectedMethod, selectedPkg]);

  if (!user) return <AuthGate />;
  if (loading && methods.length === 0 && orders.length === 0) return <LoadingBox />;

  async function handleCreateOrder() {
    if (!selectedPkg || !selectedMethod) {
      setError("To‘lov usuli va paketni tanlang.");
      return;
    }
    setBusyAction("create");
    setError(null);
    setNotice(null);
    try {
      if (!pendingIdemKeyRef.current) {
        pendingIdemKeyRef.current = makeAttemptKey(user!.id, selectedMethod, selectedPkg);
      }
      const res = await api.createPaymentOrder({
        package_id: selectedPkg,
        payment_method_code: selectedMethod,
        idempotency_key: pendingIdemKeyRef.current,
      });
      pendingIdemKeyRef.current = null;
      setActiveOrder(res.order);
      setInstructions(res.transfer_instructions);
      setNotice(`Buyurtma ${res.order.order_id} yaratildi. O‘tkazmani amalga oshiring va chek / raqam yuboring.`);
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Buyurtma yaratilmadi");
    } finally {
      setBusyAction(null);
    }
  }

  function handleSelectReceiptFile(file: File | null) {
    setError(null);
    if (!file) {
      setReceiptFile(null);
      return;
    }
    if (file.size === 0 || file.size > MAX_RECEIPT_BYTES) {
      setError("Chek fayli 1 baytdan 5 MB gacha bo‘lishi kerak.");
      setReceiptFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    if (file.type && !ALLOWED_RECEIPT_MIMES.has(file.type)) {
      setError("Faqat PNG, JPEG, WebP yoki PDF formatidagi cheklar qabul qilinadi.");
      setReceiptFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    setReceiptFile(file);
  }

  async function handleUploadReceipt(orderId: string) {
    if (!receiptFile) {
      setError("Avval chek faylini tanlang.");
      return;
    }
    setBusyAction("receipt");
    setError(null);
    setNotice(null);
    try {
      const res = await api.uploadReceipt(orderId, receiptFile);
      setActiveOrder(res.order);
      setReceiptFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      setNotice("Chek xavfsiz tekshiruvdan o‘tdi va saqlandi. Endi o‘tkazma raqamini yuboring.");
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Chek yuklanmadi");
    } finally {
      setBusyAction(null);
    }
  }

  async function handleSubmitProof(e: React.FormEvent, orderId: string) {
    e.preventDefault();
    const ref = txRef.trim();
    if (ref.length < 3 || ref.length > 128) {
      setError("O‘tkazma raqami 3–128 belgidan iborat bo‘lishi kerak.");
      return;
    }
    if (UNSAFE_REF_RE.test(ref)) {
      setError("O‘tkazma raqami ichida havola (URL) yoki skript bo‘lmasligi kerak.");
      return;
    }
    setBusyAction("submit");
    setError(null);
    setNotice(null);
    try {
      const res = await api.submitPaymentProof(orderId, ref);
      setActiveOrder(res.order);
      setTxRef("");
      setNotice("Buyurtma administrator tekshiruviga yuborildi (pending_review). Tasdiqlanmaguncha mablag‘ qo‘shilmaydi.");
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Yuborishda xatolik");
    } finally {
      setBusyAction(null);
    }
  }

  async function handleCancel(orderId: string) {
    setBusyAction("cancel");
    setError(null);
    setNotice(null);
    try {
      await api.cancelPaymentOrder(orderId);
      setActiveOrder(null);
      setInstructions(null);
      setNotice(`Buyurtma ${orderId} bekor qilindi.`);
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Bekor qilinmadi");
    } finally {
      setBusyAction(null);
    }
  }

  function resumePendingOrder(order: PaymentOrder) {
    setActiveOrder(order);
    setInstructions({
      order_id: order.order_id,
      payment_method_code: order.payment_method_code,
      network: order.payment_network_snapshot,
      bank_name: order.payment_bank_snapshot,
      recipient_name: order.recipient_name_snapshot,
      card_last4: order.card_last4_snapshot,
      card_masked: `**** **** **** ${order.card_last4_snapshot}`,
      card_config_changed: false,
      expected_amount_uzs: order.expected_amount_uzs,
      reward_currency: order.reward_currency,
      reward_amount: order.reward_amount,
      transfer_channel_notice: t.payments.cardServerSideNote,
      verification_notice: t.payments.subtitle,
    });
    setError(null);
    setNotice(`Buyurtma ${order.order_id} tanlandi. Chek va o‘tkazma raqamini yuborishingiz mumkin.`);
  }

  return (
    <div className="space-y-6">
      <PageHeader title={t.payments.title} subtitle={t.payments.subtitle} />
      {error && <div role="alert"><ErrorBox message={error} onRetry={() => void load(false)} /></div>}
      {notice && <div role="status" className="rounded-xl border border-cyan-400/40 bg-cyan-950/30 p-3 text-xs text-cyan-200">{notice}</div>}

      {/* Separate Visa and Uzcard Options */}
      <section className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5 space-y-4">
        <h2 className="text-sm font-bold text-white">{t.payments.chooseMethod}</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {methods.map((m) => (
            <button
              key={m.code}
              type="button"
              disabled={busy}
              aria-pressed={selectedMethod === m.code}
              onClick={() => setSelectedMethod(m.code)}
              className={`rounded-2xl border p-4 text-left transition ${
                selectedMethod === m.code
                  ? "border-cyan-400 bg-cyan-950/30"
                  : "border-slate-700 bg-slate-950/60 hover:border-slate-500"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-display text-sm font-bold text-white">{m.network}</span>
                <span className="rounded-full bg-slate-800 px-2.5 py-0.5 text-[11px] text-cyan-300">{m.card_masked}</span>
              </div>
              <div className="mt-2 text-xs text-slate-300">
                Qabul qiluvchi: <strong className="text-white">{m.recipient_name}</strong>
              </div>
              <div className="mt-1 text-[11px] text-slate-400">
                Bank: {m.bank_name ? m.bank_name : t.payments.bankUnverified}
              </div>
            </button>
          ))}
        </div>

        <h2 className="pt-2 text-sm font-bold text-white">{t.payments.choosePackage}</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          {packages.map((p) => (
            <button
              key={p.id}
              type="button"
              disabled={busy}
              aria-pressed={selectedPkg === p.id}
              onClick={() => setSelectedPkg(p.id)}
              className={`rounded-xl border p-3 text-left ${
                selectedPkg === p.id ? "border-amber-400 bg-amber-950/20" : "border-slate-700 bg-slate-950/60"
              }`}
            >
              <div className="text-sm font-bold text-white">{p.title}</div>
              <div className="mt-1 text-xs text-amber-300">{p.price_uzs.toLocaleString()} UZS</div>
            </button>
          ))}
        </div>

        <p className="text-[11px] text-slate-400">{t.payments.cardServerSideNote}</p>

        <button
          disabled={busy || methods.length === 0 || packages.length === 0}
          type="button"
          onClick={() => void handleCreateOrder()}
          className="rounded-xl bg-cyan-400 px-5 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
        >
          {busyAction === "create" ? t.common.loading : t.payments.createOrder}
        </button>
      </section>

      {/* Active Order Transfer Instructions + Receipt & Proof Submission */}
      {activeOrder && instructions && activeOrder.status === "pending" && (
        <section className="space-y-4 rounded-2xl border border-amber-400/40 bg-[#071326] p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-base font-bold text-white">Buyurtma: {activeOrder.order_id}</h2>
            <StatusBadge status={activeOrder.status} />
          </div>

          <div className="grid gap-2 rounded-xl border border-slate-800 bg-slate-950/70 p-4 text-xs sm:grid-cols-2">
            <div>Tarmoq: <strong className="text-white">{instructions.network}</strong></div>
            <div>Bank: <strong className="text-white">{instructions.bank_name || t.payments.bankUnverified}</strong></div>
            <div>Qabul qiluvchi: <strong className="text-white">{instructions.recipient_name}</strong></div>
            <div>Karta (yashirilgan): <strong className="text-cyan-300">{instructions.card_masked}</strong></div>
            <div>Aniq summa: <strong className="text-amber-300">{instructions.expected_amount_uzs.toLocaleString()} UZS</strong></div>
            <div>Paket: <strong className="text-white">{instructions.reward_amount} {instructions.reward_currency.toUpperCase()}</strong></div>
          </div>
          <p className="text-xs text-slate-300">{instructions.transfer_channel_notice}</p>
          <p className="text-xs text-amber-200">{instructions.verification_notice}</p>

          <div className="space-y-2 rounded-xl border border-slate-800 bg-slate-950/60 p-4">
            <label htmlFor="receipt-file-input" className="block text-xs font-semibold text-slate-200">{t.payments.uploadReceipt}</label>
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={fileInputRef}
                id="receipt-file-input"
                type="file"
                disabled={busy}
                accept="image/png,image/jpeg,image/webp,application/pdf"
                onChange={(e) => handleSelectReceiptFile(e.target.files?.[0] || null)}
                className="text-xs text-slate-300"
              />
              <button
                type="button"
                disabled={busy || !receiptFile}
                onClick={() => void handleUploadReceipt(activeOrder.order_id)}
                className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-cyan-200 hover:bg-slate-700 disabled:opacity-40"
              >
                {busyAction === "receipt" ? t.common.loading : "Chekni yuklash"}
              </button>
            </div>
            {activeOrder.receipt_object_key && (
              <p className="text-[11px] text-emerald-300">Chek biriktirilgan ({activeOrder.receipt_mime_type}).</p>
            )}
          </div>

          <form onSubmit={(e) => void handleSubmitProof(e, activeOrder.order_id)} noValidate className="space-y-3">
            <label htmlFor="tx-ref-input" className="block text-xs text-slate-300">{t.payments.txRefLabel}</label>
            <input
              id="tx-ref-input"
              required
              minLength={3}
              maxLength={128}
              value={txRef}
              onChange={(e) => setTxRef(e.target.value)}
              placeholder="Masalan: UZUM-20261126-4455"
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            />
            <div className="flex gap-2">
              <button
                disabled={busy}
                type="submit"
                className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
              >
                {busyAction === "submit" ? t.common.loading : t.payments.submitProof}
              </button>
              <button
                disabled={busy}
                type="button"
                onClick={() => void handleCancel(activeOrder.order_id)}
                className="rounded-xl border border-slate-700 px-4 py-2 text-xs text-slate-300 disabled:opacity-50"
              >
                {busyAction === "cancel" ? t.common.loading : t.common.cancel}
              </button>
            </div>
          </form>
        </section>
      )}

      {/* Orders History & Status */}
      <section className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
        <h2 className="mb-3 text-base font-bold text-white">{t.payments.ordersHistory}</h2>
        {orders.length === 0 ? (
          <p className="text-xs text-slate-400">{t.common.noData}</p>
        ) : (
          <div className="space-y-2.5 text-xs">
            {orders.map((o) => (
              <div key={o.order_id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                <div>
                  <div className="font-semibold text-white">
                    {o.order_id} • {o.payment_network_snapshot} (****{o.card_last4_snapshot}) — {o.recipient_name_snapshot}
                  </div>
                  <div className="text-slate-400">
                    {o.expected_amount_uzs.toLocaleString()} UZS → {o.reward_amount} {o.reward_currency.toUpperCase()}
                    {o.submitted_reference ? ` • Ref: ${o.submitted_reference}` : ""}
                  </div>
                  {o.rejection_reason && <div className="mt-1 text-rose-300">Rad etish sababi: {o.rejection_reason}</div>}
                </div>
                <div className="flex items-center gap-2">
                  {o.status === "pending" && activeOrder?.order_id !== o.order_id && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => resumePendingOrder(o)}
                      className="rounded-lg bg-amber-400/20 px-2.5 py-1 text-[11px] font-semibold text-amber-200 hover:bg-amber-400/30"
                    >
                      Davom ettirish
                    </button>
                  )}
                  <StatusBadge status={o.status} />
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
