import React, { useCallback, useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { ErrorBox, LoadingBox, PageHeader } from "../components/UI";

export const SocialPage: React.FC = () => {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [profiles, setProfiles] = useState<Array<Record<string, unknown>>>([]);
  const [friends, setFriends] = useState<Array<Record<string, unknown>>>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const pRes = await api.discoverProfiles(query);
      setProfiles(pRes.profiles);
      if (user) {
        const fRes = await api.getFriends();
        setFriends(fRes.friends);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Hamjamiyat yuklanmadi");
    } finally {
      setLoading(false);
    }
  }, [query, user]);

  useEffect(() => {
    void load();
  }, [load]);

  async function addFriend(username: string) {
    setMsg(null);
    setError(null);
    try {
      await api.requestFriend(username);
      setMsg(`@${username} ga do‘stlik so‘rovi yuborildi.`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "So‘rov yuborilmadi");
    }
  }

  async function likeHome(homeId: string) {
    setMsg(null);
    setError(null);
    try {
      const res = await api.likeHome(homeId);
      setMsg(`Uyga layk bosildi (jami: ${res.likes_count}).`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Layk bosilmadi");
    }
  }

  async function acceptFriend(id: string) {
    await api.acceptFriend(id);
    await load();
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Ijtimoiy Profillar va Fuqarolar" subtitle="CityX fuqarolarini qidiring, do‘stlashing va uylarga baho bering" />
      {error && <ErrorBox message={error} onRetry={() => void load()} />}
      {msg && <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{msg}</div>}

      <div className="flex gap-2">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Foydalanuvchi nomi bo‘yicha qidirish..."
          className="flex-1 rounded-xl border border-slate-700 bg-[#071326] px-3 py-2 text-sm text-white"
        />
        <button type="button" onClick={() => void load()} className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950">
          Qidirish
        </button>
      </div>

      {loading ? (
        <LoadingBox />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {profiles.map((p) => (
            <div key={String(p.id)} className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-4 text-xs">
              <div className="flex items-center justify-between">
                <strong className="text-sm text-white">{String(p.display_name || p.username)}</strong>
                <span className="text-cyan-300">LVL {String(p.level)}</span>
              </div>
              <div className="text-slate-400">@{String(p.username)} • {String(p.district_id)}</div>
              {Boolean(p.bio) && <p className="mt-2 text-slate-300">{String(p.bio)}</p>}
              <div className="mt-3 flex flex-wrap gap-2">
                {user && user.username !== String(p.username) && (
                  <button
                    type="button"
                    onClick={() => void addFriend(String(p.username))}
                    className="rounded-lg bg-cyan-400/20 px-3 py-1 font-semibold text-cyan-200"
                  >
                    Do‘st qo‘shish
                  </button>
                )}
                {user && Boolean(p.home_id) && (
                  <button
                    type="button"
                    onClick={() => void likeHome(String(p.home_id))}
                    className="rounded-lg border border-slate-700 px-3 py-1 text-slate-200"
                  >
                    Uyga layk ({String(p.floors || 2)} qavat)
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {user && friends.length > 0 && (
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <h2 className="mb-3 text-base font-bold text-white">Do‘stlar va so‘rovlar</h2>
          <div className="space-y-2 text-xs">
            {friends.map((f) => (
              <div key={String(f.id)} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                <span>@{String(f.peer_username)} ({String(f.status)})</span>
                {f.status === "pending" && f.direction === "incoming" && (
                  <button type="button" onClick={() => void acceptFriend(String(f.id))} className="rounded-lg bg-emerald-500/20 px-3 py-1 font-semibold text-emerald-200">
                    Qabul qilish
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
