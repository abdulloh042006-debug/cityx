import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { AuthGate, ErrorBox, LoadingBox, PageHeader } from "../components/UI";

export const DashboardPage: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [data, setData] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [claimMsg, setClaimMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api.getDashboard());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Dashboard yuklanmadi");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) void load();
  }, [user, load]);

  if (!user) return <AuthGate />;
  if (loading) return <LoadingBox />;
  if (error) return <ErrorBox message={error} onRetry={() => void load()} />;

  const dailyReady = Boolean(data?.daily_claim_ready);
  const leaderboard = (data?.districts_leaderboard as Array<Record<string, unknown>>) || [];
  const ledger = (data?.recent_ledger as Array<Record<string, unknown>>) || [];

  async function handleClaimDaily() {
    setClaimMsg(null);
    setError(null);
    try {
      const res = await api.claimDaily();
      setClaimMsg(`+${res.coins_awarded} CX va +${res.gems_awarded} Olmos hisobingizga qo‘shildi!`);
      await refreshUser();
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Kunlik mukofot olinmadi");
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="CityX Boshqaruv Paneli"
        subtitle={`Xush kelibsiz, @${user.username} • Tuman reytingi: #${String(data?.district_rank ?? 1)}`}
        right={
          <button
            type="button"
            disabled={!dailyReady}
            onClick={() => void handleClaimDaily()}
            className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300 disabled:opacity-40"
          >
            {dailyReady ? "Kunlik mukofotni olish (+150 CX)" : "Bugun olingan"}
          </button>
        }
      />

      {claimMsg && <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{claimMsg}</div>}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-4">
          <div className="text-xs text-slate-400">Tangalar</div>
          <div className="mt-1 font-display text-2xl font-bold text-cyan-300">{user.coins.toLocaleString()} CX</div>
        </div>
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-4">
          <div className="text-xs text-slate-400">Olmoslar</div>
          <div className="mt-1 font-display text-2xl font-bold text-amber-300">{user.gems.toLocaleString()} G</div>
        </div>
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-4">
          <div className="text-xs text-slate-400">Kutilayotgan to‘lovlar</div>
          <div className="mt-1 font-display text-2xl font-bold text-white">{String(data?.pending_payment_orders ?? 0)}</div>
        </div>
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-4">
          <div className="text-xs text-slate-400">O‘qilmagan xabarlar</div>
          <div className="mt-1 font-display text-2xl font-bold text-white">{String(data?.unread_notifications ?? 0)}</div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Tumanlar reytingi</h2>
            <Link to="/map" className="text-xs text-cyan-300 hover:underline">Xaritani ochish</Link>
          </div>
          <div className="space-y-2 text-xs">
            {leaderboard.map((d, i) => (
              <div key={String(d.id)} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2">
                <span>#{i + 1} {String(d.name)}</span>
                <span className="font-semibold text-cyan-300">{Number(d.total_points || 0).toLocaleString()} ball</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-bold text-white">So‘nggi tranzaksiyalar</h2>
            <Link to="/wallet" className="text-xs text-cyan-300 hover:underline">Barchasi</Link>
          </div>
          {ledger.length === 0 ? (
            <p className="text-xs text-slate-400">Hali iqtisodiy operatsiyalar yo‘q.</p>
          ) : (
            <div className="space-y-2 text-xs">
              {ledger.map((row) => (
                <div key={String(row.id)} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2">
                  <span>{String(row.reason)}</span>
                  <span className={Number(row.delta) >= 0 ? "text-emerald-300 font-semibold" : "text-rose-300 font-semibold"}>
                    {Number(row.delta) >= 0 ? "+" : ""}{String(row.delta)} {String(row.currency).toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
