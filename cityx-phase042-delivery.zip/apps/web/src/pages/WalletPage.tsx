import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { AuthGate, ErrorBox, LoadingBox, PageHeader } from "../components/UI";

export const WalletPage: React.FC = () => {
  const { user } = useAuth();
  const [wallet, setWallet] = useState<{ coins: number; gems: number; transactions: Array<Record<string, unknown>> } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setWallet(await api.getWallet());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Hamyon yuklanmadi");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) void load();
  }, [user, load]);

  if (!user) return <AuthGate />;
  if (loading) return <LoadingBox />;
  if (error) return <ErrorBox message={error} onRetry={() => void load()} />;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Hamyon va Tranzaksiyalar Tarixi"
        subtitle="Barcha balans o‘zgarishlari serverda append-only economy_ledger jadvalida qayd etiladi"
        right={
          <Link to="/payments" className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-cyan-300">
            Qo‘lda o‘tkazma bilan to‘ldirish
          </Link>
        }
      />

      <div className="grid grid-cols-2 gap-4">
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <div className="text-xs text-slate-400">Tangalar (CX)</div>
          <div className="mt-1 font-display text-3xl font-bold text-cyan-300">{wallet?.coins.toLocaleString()}</div>
        </div>
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <div className="text-xs text-slate-400">Olmoslar (Gems)</div>
          <div className="mt-1 font-display text-3xl font-bold text-amber-300">{wallet?.gems.toLocaleString()}</div>
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-[#071326]/80">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-slate-800 text-slate-400">
            <tr>
              <th className="px-4 py-3">Sabab</th>
              <th className="px-4 py-3">Valyuta</th>
              <th className="px-4 py-3">O‘zgarish</th>
              <th className="px-4 py-3">Qoldiq</th>
              <th className="px-4 py-3">Vaqt</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/70">
            {wallet?.transactions.length ? (
              wallet.transactions.map((tx) => (
                <tr key={String(tx.id)}>
                  <td className="px-4 py-3 text-slate-200">{String(tx.reason)}</td>
                  <td className="px-4 py-3 uppercase text-slate-400">{String(tx.currency)}</td>
                  <td className={`px-4 py-3 font-semibold ${Number(tx.delta) >= 0 ? "text-emerald-300" : "text-rose-300"}`}>
                    {Number(tx.delta) >= 0 ? "+" : ""}{String(tx.delta)}
                  </td>
                  <td className="px-4 py-3 text-white">{Number(tx.balance_after).toLocaleString()}</td>
                  <td className="px-4 py-3 text-slate-400">
                    {new Date(Number(tx.created_at) * 1000).toLocaleString()}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-slate-400">
                  Hozircha tranzaksiyalar mavjud emas.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
