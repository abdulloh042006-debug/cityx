import React, { useCallback, useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { Lang } from "../i18n/translations";
import { AuthGate, ErrorBox, LoadingBox, PageHeader } from "../components/UI";

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();
  const { setLang } = useI18n();
  const [language, setLanguage] = useState<Lang>("uz");
  const [classicMode, setClassicMode] = useState(false);
  const [prefs, setPrefs] = useState<Record<string, boolean>>({});
  const [notifications, setNotifications] = useState<Array<Record<string, unknown>>>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [sRes, nRes] = await Promise.all([api.getSettings(), api.getNotifications()]);
      setLanguage(sRes.settings.language);
      setClassicMode(sRes.settings.classic_mode);
      setPrefs(sRes.settings.notify_prefs || {});
      setNotifications(nRes.notifications);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sozlamalar yuklanmadi");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) void load();
  }, [user, load]);

  if (!user) return <AuthGate />;
  if (loading) return <LoadingBox />;
  if (error) return <ErrorBox message={error} onRetry={() => void load()} />;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    try {
      await api.updateSettings({ language, classic_mode: classicMode, notify_prefs: prefs });
      setLang(language);
      setMsg("Sozlamalar serverga saqlandi.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Saqlanmadi");
    }
  }

  async function markRead(id: string) {
    await api.markNotificationRead(id);
    await load();
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Sozlamalar va Bildirishnomalar" subtitle="Til (O‘zbekcha / Ruscha / Inglizcha), Telegram bot rejimi va xabarlar" />
      {msg && <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{msg}</div>}

      <div className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={save} className="space-y-4 rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <div>
            <label className="block text-xs text-slate-300">Interfeys tili</label>
            <select value={language} onChange={(e) => setLanguage(e.target.value as Lang)} className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white">
              <option value="uz">O‘zbek (Lotin)</option>
              <option value="ru">Русский</option>
              <option value="en">English</option>
            </select>
          </div>
          <label className="flex items-center gap-2 text-xs text-slate-300">
            <input type="checkbox" checked={classicMode} onChange={(e) => setClassicMode(e.target.checked)} />
            Telegram botda klassik tugmalar rejimini yoqish (HTML widgetsiz)
          </label>
          <div className="space-y-2 border-t border-slate-800 pt-3">
            <div className="text-xs font-semibold text-white">Bildirishnoma toifalari</div>
            {["properties", "quests", "social", "events", "garage", "district"].map((k) => (
              <label key={k} className="flex items-center gap-2 text-xs text-slate-300">
                <input
                  type="checkbox"
                  checked={prefs[k] ?? true}
                  onChange={(e) => setPrefs((prev) => ({ ...prev, [k]: e.target.checked }))}
                />
                {k}
              </label>
            ))}
          </div>
          <button type="submit" className="rounded-xl bg-cyan-400 px-4 py-2 text-xs font-bold text-slate-950">
            Saqlash
          </button>
        </form>

        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <h2 className="mb-3 text-base font-bold text-white">Bildirishnomalar</h2>
          {notifications.length === 0 ? (
            <p className="text-xs text-slate-400">Hozircha bildirishnomalar yo‘q.</p>
          ) : (
            <div className="space-y-2 text-xs">
              {notifications.map((n) => (
                <div key={String(n.id)} className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                  <div className="flex items-center justify-between">
                    <strong className="text-white">{String(n.title)}</strong>
                    {!Number(n.is_read) && (
                      <button type="button" onClick={() => void markRead(String(n.id))} className="text-cyan-300 hover:underline">
                        O‘qildi
                      </button>
                    )}
                  </div>
                  <p className="mt-1 text-slate-400">{String(n.body)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
