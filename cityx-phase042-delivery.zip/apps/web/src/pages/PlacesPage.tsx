import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, PlaceItem } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useI18n } from "../i18n/I18nContext";
import { ErrorBox, LoadingBox, PageHeader } from "../components/UI";

const CATEGORIES = ["", "landmark", "business", "education", "service", "entertainment", "nature", "transport"];

export const PlacesPage: React.FC = () => {
  const { user } = useAuth();
  const { t } = useI18n();
  const [category, setCategory] = useState("");
  const [places, setPlaces] = useState<PlaceItem[]>([]);
  const [events, setEvents] = useState<Array<Record<string, unknown>>>([]);
  const [elections, setElections] = useState<Array<Record<string, unknown>>>([]);
  const [loading, setLoading] = useState(true);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (showSpinner = true) => {
    if (showSpinner) setLoading(true);
    setError(null);
    try {
      const [pRes, evRes, elRes] = await Promise.all([
        api.getPlaces(undefined, category || undefined),
        api.getEvents(),
        api.getElections(),
      ]);
      setPlaces(pRes.places);
      setEvents(evRes.events);
      setElections(elRes.elections);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Maskanlar yuklanmadi");
    } finally {
      if (showSpinner) setLoading(false);
    }
  }, [category]);

  useEffect(() => {
    void load(true);
  }, [load]);

  async function toggleRsvp(eventId: string, join: boolean) {
    setBusyKey(`rsvp:${eventId}`);
    setMsg(null);
    setError(null);
    try {
      await api.rsvpEvent(eventId, join);
      setMsg(join ? "Tadbirga yozildingiz!" : "Tadbirdan chiqdingiz.");
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "RSVP xatosi");
    } finally {
      setBusyKey(null);
    }
  }

  async function vote(electionId: string, candidateId: string) {
    setBusyKey(`vote:${electionId}:${candidateId}`);
    setMsg(null);
    setError(null);
    try {
      await api.castVote(electionId, candidateId);
      setMsg("Rasmiy ovozingiz qayd etildi!");
      await load(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ovoz berilmadi");
    } finally {
      setBusyKey(null);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Maskanlar, Bizneslar va Shahar Xizmatlari" subtitle="Toshkentning barcha 8 tumanidagi bizneslar, ta’lim muassasalari, tadbirlar va saylovlar" />
      {error && <div role="alert"><ErrorBox message={error} onRetry={() => void load(false)} /></div>}
      {msg && <div role="status" className="rounded-xl border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">{msg}</div>}

      <div className="flex flex-wrap gap-1.5">
        {CATEGORIES.map((c) => (
          <button
            key={c || "all"}
            type="button"
            onClick={() => setCategory(c)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
              category === c ? "bg-cyan-400 text-slate-950" : "border border-slate-700 bg-[#071326] text-slate-300"
            }`}
          >
            {c || "Barchasi"}
          </button>
        ))}
      </div>

      {loading && places.length === 0 ? (
        <LoadingBox />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {places.map((pl) => (
            <div key={pl.id} className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-4 text-xs">
              <div className="flex items-center justify-between">
                <span className="rounded-full bg-cyan-500/15 px-2 py-0.5 text-[10px] uppercase text-cyan-300">{pl.category}</span>
                <span className="text-slate-400">{pl.district_id}</span>
              </div>
              <h2 className="mt-2 text-sm font-bold text-white">{pl.name}</h2>
              <p className="mt-1 text-slate-400">{pl.description}</p>
              <div className="mt-2 text-[11px] text-slate-500">{pl.address_label}</div>
            </div>
          ))}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5 space-y-2.5">
          <h2 className="text-base font-bold text-white">Shahar tadbirlari</h2>
          {events.length === 0 ? (
            <p className="text-xs text-slate-400">{t.common.noData}</p>
          ) : (
            events.map((ev) => {
              const evId = String(ev.id);
              const isBusy = busyKey === `rsvp:${evId}`;
              return (
                <div key={evId} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-xs">
                  <div>
                    <div className="font-bold text-white">{String(ev.title)}</div>
                    <div className="text-slate-400">{String(ev.location)} • {String(ev.attendees_count)} ishtirokchi</div>
                  </div>
                  {user ? (
                    <button
                      type="button"
                      disabled={busyKey !== null}
                      onClick={() => void toggleRsvp(evId, !Boolean(ev.joined))}
                      className="rounded-lg bg-cyan-400/20 px-3 py-1 font-semibold text-cyan-200 hover:bg-cyan-400/30 disabled:opacity-50"
                    >
                      {isBusy ? t.common.loading : ev.joined ? "Chiqish" : "Qatnashish"}
                    </button>
                  ) : (
                    <Link to="/auth" className="text-[11px] text-cyan-300 hover:underline">
                      Qatnashish uchun kiring
                    </Link>
                  )}
                </div>
              );
            })
          )}
        </div>

        <div className="rounded-2xl border border-slate-800 bg-[#071326]/80 p-5">
          <h2 className="mb-3 text-base font-bold text-white">CityX Saylovlari (1 fuqaro = 1 ovoz)</h2>
          {elections.map((el) => {
            const cands = (el.candidates as Array<{ id: string; name: string; platform: string }>) || [];
            const elId = String(el.election_id);
            return (
              <div key={elId} className="space-y-2 text-xs">
                <div className="font-bold text-white">{String(el.title)} ({String(el.status)})</div>
                {cands.map((c) => {
                  const isBusy = busyKey === `vote:${elId}:${c.id}`;
                  return (
                    <div key={c.id} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                      <div>
                        <div className="font-semibold text-white">{c.name}</div>
                        <div className="text-slate-400">{c.platform}</div>
                      </div>
                      {user && el.status === "open" && !el.user_voted_candidate_id && (
                        <button
                          type="button"
                          disabled={busyKey !== null}
                          onClick={() => void vote(elId, c.id)}
                          className="rounded-lg bg-amber-400/20 px-3 py-1 font-semibold text-amber-200 hover:bg-amber-400/30 disabled:opacity-50"
                        >
                          {isBusy ? t.common.loading : "Ovoz berish"}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
