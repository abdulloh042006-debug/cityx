import React, { createContext, useContext, useEffect, useState } from "react";
import { Lang, TRANSLATIONS, TranslationTree } from "./translations";

interface I18nContextValue {
  lang: Lang;
  setLang: (next: Lang) => void;
  t: TranslationTree;
}

const STORAGE_KEY = "cityx_lang";
const I18nContext = createContext<I18nContextValue | null>(null);

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
    return saved === "ru" || saved === "en" || saved === "uz" ? saved : "uz";
  });

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, lang);
    document.documentElement.lang = lang;
  }, [lang]);

  return (
    <I18nContext.Provider value={{ lang, setLang: setLangState, t: TRANSLATIONS[lang] }}>
      {children}
    </I18nContext.Provider>
  );
};

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used inside I18nProvider");
  return ctx;
}
