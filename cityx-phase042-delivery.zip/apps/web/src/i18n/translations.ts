export type Lang = "uz" | "ru" | "en";

export interface TranslationTree {
  brandTagline: string;
  nav: {
    home: string;
    dashboard: string;
    map: string;
    city3d: string;
    wallet: string;
    payments: string;
    social: string;
    places: string;
    profile: string;
    settings: string;
    admin: string;
    login: string;
    logout: string;
  };
  common: {
    loading: string;
    retry: string;
    save: string;
    saved: string;
    cancel: string;
    submit: string;
    coins: string;
    gems: string;
    district: string;
    level: string;
    status: string;
    noData: string;
    authRequired: string;
  };
  landing: {
    heroTitle: string;
    heroDesc: string;
    enterCity: string;
    openDashboard: string;
    getStarted: string;
    statsDistricts: string;
    statsLandmarks: string;
    statsPlaces: string;
    statsCitizens: string;
  };
  auth: {
    loginTab: string;
    registerTab: string;
    recoveryTab: string;
    username: string;
    password: string;
    instagram: string;
    loginBtn: string;
    registerBtn: string;
    tgLoginBtn: string;
    recoveryIdentifier: string;
    recoveryRequestBtn: string;
    recoveryToken: string;
    newPassword: string;
    recoveryConfirmBtn: string;
  };
  payments: {
    title: string;
    subtitle: string;
    chooseMethod: string;
    choosePackage: string;
    createOrder: string;
    uploadReceipt: string;
    txRefLabel: string;
    submitProof: string;
    bankUnverified: string;
    cardServerSideNote: string;
    ordersHistory: string;
  };
  admin: {
    title: string;
    forbidden: string;
    approve: string;
    reject: string;
    rejectReasonPlaceholder: string;
  };
}

export const TRANSLATIONS: Record<Lang, TranslationTree> = {
  uz: {
    brandTagline: "O‘zbekistonning 3D ijtimoiy virtual shahri",
    nav: {
      home: "Bosh sahifa",
      dashboard: "Boshqaruv",
      map: "Xarita",
      city3d: "3D Shahar",
      wallet: "Hamyon",
      payments: "To‘lovlar",
      social: "Hamjamiyat",
      places: "Maskanlar",
      profile: "Profil",
      settings: "Sozlamalar",
      admin: "Admin",
      login: "Kirish",
      logout: "Chiqish",
    },
    common: {
      loading: "Yuklanmoqda...",
      retry: "Qayta urinish",
      save: "Saqlash",
      saved: "Saqlandi",
      cancel: "Bekor qilish",
      submit: "Yuborish",
      coins: "Tangalar",
      gems: "Olmoslar",
      district: "Tuman",
      level: "Daraja",
      status: "Holat",
      noData: "Hozircha ma’lumot yo‘q",
      authRequired: "Davom etish uchun hisobingizga kiring.",
    },
    landing: {
      heroTitle: "CityX — Toshkentdan boshlanadigan tirik 3D virtual ekotizim",
      heroDesc:
        "8 ta tuman, 1–50 qavatli shaxsiy uylar, tarixiy me’moriy obidalar, Telegram Mini App va yagona server iqtisodiyoti.",
      enterCity: "3D Shaharga kirish",
      openDashboard: "Shaxsiy kabinet",
      getStarted: "Ro‘yxatdan o‘tish",
      statsDistricts: "Tumanlar",
      statsLandmarks: "Noyob obidalar",
      statsPlaces: "Shahar maskanlari",
      statsCitizens: "Fuqarolar",
    },
    auth: {
      loginTab: "Kirish",
      registerTab: "Ro‘yxatdan o‘tish",
      recoveryTab: "Parolni tiklash",
      username: "Foydalanuvchi nomi",
      password: "Parol",
      instagram: "Instagram (@sizning_nomingiz — ixtiyoriy)",
      loginBtn: "Hisobga kirish",
      registerBtn: "Hisob yaratish",
      tgLoginBtn: "Telegram Mini App orqali kirish",
      recoveryIdentifier: "Foydalanuvchi nomi yoki email",
      recoveryRequestBtn: "Tiklash so‘rovi yuborish",
      recoveryToken: "Tasdiqlangan tiklash kodi (token)",
      newPassword: "Yangi parol (kamida 8 belgi)",
      recoveryConfirmBtn: "Parolni yangilash",
    },
    payments: {
      title: "Qo‘lda bank o‘tkazmasi orqali to‘ldirish",
      subtitle:
        "Faqat ikki alohida qo‘lda bank kartasiga o‘tkazma qo‘llab-quvvatlanadi. Mablag‘ faqat administrator qo‘lda tasdiqlaganidan so‘ng qo‘shiladi.",
      chooseMethod: "1. To‘lov usulini tanlang (alohida kartalar)",
      choosePackage: "2. Paketni tanlang (UZS)",
      createOrder: "Buyurtma yaratish",
      uploadReceipt: "Chek faylini yuklash (PNG, JPEG, WebP, PDF, max 5 MB)",
      txRefLabel: "Bank o‘tkazma raqami / izohi",
      submitProof: "Tekshiruvga yuborish",
      bankUnverified: "Bank nomi tasdiqlanmagan",
      cardServerSideNote:
        "Xavfsizlik qoidasi: to‘liq karta raqami API javobi va frontend kodida saqlanmaydi. O‘tkazma rekvizitlarini rasmiy qo‘llab-quvvatlash kanali orqali tasdiqlang.",
      ordersHistory: "Mening to‘lov buyurtmalarim",
    },
    admin: {
      title: "CityX Administrator Boshqaruvi",
      forbidden: "Bu bo‘limga faqat administratorlar kira oladi (403 Forbidden).",
      approve: "Tasdiqlash (1 marta qo‘shiladi)",
      reject: "Rad etish",
      rejectReasonPlaceholder: "Rad etish sababini kiriting (kamida 3 belgi)",
    },
  },
  ru: {
    brandTagline: "3D социальный виртуальный город Узбекистана",
    nav: {
      home: "Главная",
      dashboard: "Панель",
      map: "Карта",
      city3d: "3D Город",
      wallet: "Кошелёк",
      payments: "Оплаты",
      social: "Сообщество",
      places: "Места",
      profile: "Профиль",
      settings: "Настройки",
      admin: "Админ",
      login: "Войти",
      logout: "Выйти",
    },
    common: {
      loading: "Загрузка...",
      retry: "Повторить",
      save: "Сохранить",
      saved: "Сохранено",
      cancel: "Отмена",
      submit: "Отправить",
      coins: "Монеты",
      gems: "Кристаллы",
      district: "Район",
      level: "Уровень",
      status: "Статус",
      noData: "Данных пока нет",
      authRequired: "Войдите в аккаунт, чтобы продолжить.",
    },
    landing: {
      heroTitle: "CityX — живая 3D виртуальная экосистема Узбекистана",
      heroDesc:
        "8 районов, личные дома 1–50 этажей, знаковые объекты, Telegram Mini App и единая серверная экономика.",
      enterCity: "Войти в 3D Город",
      openDashboard: "Личный кабинет",
      getStarted: "Регистрация",
      statsDistricts: "Районов",
      statsLandmarks: "Объектов",
      statsPlaces: "Локаций",
      statsCitizens: "Жителей",
    },
    auth: {
      loginTab: "Вход",
      registerTab: "Регистрация",
      recoveryTab: "Восстановление",
      username: "Имя пользователя",
      password: "Пароль",
      instagram: "Instagram (необязательно)",
      loginBtn: "Войти",
      registerBtn: "Создать аккаунт",
      tgLoginBtn: "Войти через Telegram Mini App",
      recoveryIdentifier: "Имя пользователя или email",
      recoveryRequestBtn: "Запросить восстановление",
      recoveryToken: "Подтверждённый токен восстановления",
      newPassword: "Новый пароль (минимум 8 символов)",
      recoveryConfirmBtn: "Обновить пароль",
    },
    payments: {
      title: "Пополнение ручным банковским переводом",
      subtitle:
        "Поддерживаются только два отдельных метода перевода на карту. Валюта начисляется строго после ручной проверки администратором.",
      chooseMethod: "1. Выберите способ оплаты (раздельные карты)",
      choosePackage: "2. Выберите пакет (UZS)",
      createOrder: "Создать заказ",
      uploadReceipt: "Загрузить чек (PNG, JPEG, WebP, PDF, до 5 МБ)",
      txRefLabel: "Номер / референс банковского перевода",
      submitProof: "Отправить на проверку",
      bankUnverified: "Банк не подтверждён",
      cardServerSideNote:
        "Правило безопасности: полные номера карт хранятся только на сервере и никогда не передаются в API или браузер.",
      ordersHistory: "История моих заказов",
    },
    admin: {
      title: "Панель администратора CityX",
      forbidden: "Доступ разрешён только администраторам (403 Forbidden).",
      approve: "Одобрить (однократное начисление)",
      reject: "Отклонить",
      rejectReasonPlaceholder: "Укажите причину отклонения (минимум 3 символа)",
    },
  },
  en: {
    brandTagline: "Uzbekistan's 3D Social Virtual City",
    nav: {
      home: "Home",
      dashboard: "Dashboard",
      map: "City Map",
      city3d: "3D City",
      wallet: "Wallet",
      payments: "Payments",
      social: "Social",
      places: "Places",
      profile: "Profile",
      settings: "Settings",
      admin: "Admin",
      login: "Sign In",
      logout: "Sign Out",
    },
    common: {
      loading: "Loading...",
      retry: "Retry",
      save: "Save",
      saved: "Saved",
      cancel: "Cancel",
      submit: "Submit",
      coins: "Coins",
      gems: "Gems",
      district: "District",
      level: "Level",
      status: "Status",
      noData: "No data yet",
      authRequired: "Sign in to access this section.",
    },
    landing: {
      heroTitle: "CityX — Living 3D Social Ecosystem Starting in Tashkent",
      heroDesc:
        "8 canonical districts, 1–50 floor homes, iconic architecture, Telegram Mini App integration, and one server-authoritative economy.",
      enterCity: "Enter 3D City",
      openDashboard: "Open Dashboard",
      getStarted: "Create Account",
      statsDistricts: "Districts",
      statsLandmarks: "Landmarks",
      statsPlaces: "City Places",
      statsCitizens: "Citizens",
    },
    auth: {
      loginTab: "Sign In",
      registerTab: "Register",
      recoveryTab: "Recovery",
      username: "Username",
      password: "Password",
      instagram: "Instagram handle (optional)",
      loginBtn: "Sign In",
      registerBtn: "Create Account",
      tgLoginBtn: "Sign In with Telegram Mini App",
      recoveryIdentifier: "Username or email",
      recoveryRequestBtn: "Request Recovery",
      recoveryToken: "Verified recovery token",
      newPassword: "New password (min 8 chars)",
      recoveryConfirmBtn: "Confirm Password Reset",
    },
    payments: {
      title: "Manual Bank-Transfer Top-Up",
      subtitle:
        "Only two separate manual card-transfer methods are supported. Virtual currency is credited strictly after manual administrator approval.",
      chooseMethod: "1. Choose Payment Method (Separate Cards)",
      choosePackage: "2. Choose Package (UZS)",
      createOrder: "Create Payment Order",
      uploadReceipt: "Upload Receipt (PNG, JPEG, WebP, PDF, max 5 MB)",
      txRefLabel: "Bank Transfer Reference",
      submitProof: "Submit for Admin Review",
      bankUnverified: "Issuing bank unverified",
      cardServerSideNote:
        "Security policy: full card numbers remain server-side only and are never returned in API responses or frontend code.",
      ordersHistory: "My Payment Orders",
    },
    admin: {
      title: "CityX Admin Dashboard",
      forbidden: "Administrator privileges required (403 Forbidden).",
      approve: "Approve (Single Credit)",
      reject: "Reject",
      rejectReasonPlaceholder: "Enter rejection reason (min 3 characters)",
    },
  },
};
