import * as THREE from "three";
import { DistrictItem, LandmarkItem } from "../api/client";

export type QualityMode = "hd" | "lite";
export type LightingMode = "day" | "sunset" | "night";

/**
 * Extension hook interfaces for future avatars, user-built 1-50 floor buildings,
 * GLB/GLTF lazy asset loaders, and WebSocket multiplayer entity synchronization.
 */
export interface WorldEntityDescriptor {
  id: string;
  kind: "avatar" | "building" | "landmark" | "vehicle";
  position: [number, number, number];
  rotationY?: number;
  label?: string;
}

export interface MultiplayerEntityAdapter {
  syncEntities(entities: WorldEntityDescriptor[]): void;
  dispose(): void;
}

export interface CitySceneCallbacks {
  onSelectLandmark?: (landmarkId: string) => void;
  onFpsUpdate?: (fps: number) => void;
  onContextLost?: () => void;
  onContextRestored?: () => void;
}

const MATERIAL_TEXTURE_KEYS = [
  "map",
  "normalMap",
  "roughnessMap",
  "metalnessMap",
  "emissiveMap",
  "aoMap",
  "alphaMap",
  "bumpMap",
  "displacementMap",
  "envMap",
  "lightMap",
  "specularMap",
] as const;

function disposeMaterialAndTextures(material: THREE.Material): void {
  const matRecord = material as unknown as Record<string, unknown>;
  for (const key of MATERIAL_TEXTURE_KEYS) {
    const tex = matRecord[key];
    if (tex && typeof (tex as THREE.Texture).dispose === "function") {
      (tex as THREE.Texture).dispose();
    }
  }
  material.dispose();
}

function disposeObject3D(root: THREE.Object3D): void {
  const disposedGeometries = new Set<THREE.BufferGeometry>();
  const disposedMaterials = new Set<THREE.Material>();

  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry && !disposedGeometries.has(mesh.geometry)) {
      mesh.geometry.dispose();
      disposedGeometries.add(mesh.geometry);
    }
    if (mesh.material) {
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const m of mats) {
        if (!disposedMaterials.has(m)) {
          disposeMaterialAndTextures(m);
          disposedMaterials.add(m);
        }
      }
    }
  });
}

/**
 * CityX Phase 0.4.1 Three.js Foundation Engine.
 * Provides a responsive WebGL foundation (1200x1200m coordinate scale mapped to 1:10 viewport units),
 * PBR lighting presets, procedural architectural landmark anchors, mouse + two-finger touch pinch-zoom & pan,
 * WebGL context loss/restoration handling, quality modes (HD/Lite), and complete GPU resource disposal.
 *
 * NOTE: This is a foundational 3D city scene prepared for Phase 1-2 high-detail GLB assets,
 * NOT a complete finished metaverse world.
 */
export class CitySceneEngine implements MultiplayerEntityAdapter {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private landmarkMeshes: Map<string, THREE.Object3D> = new Map();
  private dynamicEntities: Map<string, THREE.Object3D> = new Map();
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private callbacks: CitySceneCallbacks;

  private target = new THREE.Vector3(0, 0, 0);
  private spherical = { radius: 85, theta: Math.PI / 4, phi: Math.PI / 3.2 };
  private isDragging = false;
  private isPanningMouse = false;
  private prevPointer = { x: 0, y: 0 };

  // Two-finger touch gesture state (pinch zoom + ground-plane pan)
  private activeTouches: Map<number, { x: number; y: number }> = new Map();
  private prevPinchDistance: number | null = null;
  private prevTouchMidpoint: { x: number; y: number } | null = null;

  private rafId = 0;
  private resizeObserver: ResizeObserver | null = null;
  private disposed = false;
  private contextLost = false;
  private frameCount = 0;
  private lastFpsSample = performance.now();

  constructor(
    container: HTMLElement,
    districts: DistrictItem[],
    landmarks: LandmarkItem[],
    quality: QualityMode = "hd",
    lighting: LightingMode = "night",
    callbacks: CitySceneCallbacks = {}
  ) {
    this.container = container;
    this.callbacks = callbacks;

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x050b18, 0.0042);

    const w = Math.max(container.clientWidth, 320);
    const h = Math.max(container.clientHeight, 320);
    this.camera = new THREE.PerspectiveCamera(50, w / h, 0.5, 600);

    this.renderer = new THREE.WebGLRenderer({
      antialias: quality === "hd",
      powerPreference: quality === "hd" ? "high-performance" : "low-power",
    });
    this.renderer.setSize(w, h);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, quality === "hd" ? 2 : 1));
    this.renderer.shadowMap.enabled = quality === "hd";
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.domElement.style.touchAction = "none";
    container.appendChild(this.renderer.domElement);

    this.hemiLight = new THREE.HemisphereLight(0x88ccff, 0x0b1220, 0.75);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff4d6, 1.4);
    this.sunLight.position.set(60, 95, 45);
    if (quality === "hd") {
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(1024, 1024);
    }
    this.scene.add(this.sunLight);

    this.buildBaseCityEnvironment(districts, landmarks);
    this.setLighting(lighting);
    this.updateCameraPosition();
    this.bindEvents();
    this.animate();
  }

  private buildBaseCityEnvironment(districts: DistrictItem[], landmarks: LandmarkItem[]): void {
    const groundGeo = new THREE.PlaneGeometry(140, 140);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x0b1426, roughness: 0.92, metalness: 0.08 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    const roadMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85, metalness: 0.1 });
    for (const offset of [-20, 20]) {
      const roadX = new THREE.Mesh(new THREE.BoxGeometry(126, 0.12, 4), roadMat);
      roadX.position.set(0, 0.06, offset);
      this.scene.add(roadX);

      const roadZ = new THREE.Mesh(new THREE.BoxGeometry(4, 0.12, 126), roadMat);
      roadZ.position.set(offset, 0.06, 0);
      this.scene.add(roadZ);
    }

    const districtColors: Record<string, number> = {
      residential: 0x10b981,
      university: 0x38bdf8,
      business: 0xf59e0b,
      nature: 0x22c55e,
      downtown: 0x00e5ff,
      entertainment: 0xe879f9,
      transport: 0x94a3b8,
      vip: 0xfacc15,
    };

    for (const d of districts) {
      const sx = d.center_x / 10;
      const sz = d.center_z / 10;
      const accent = districtColors[d.id] ?? 0x38bdf8;
      const pad = new THREE.Mesh(
        new THREE.BoxGeometry(34, 0.2, 34),
        new THREE.MeshStandardMaterial({ color: 0x0f1c33, roughness: 0.85, metalness: 0.15 })
      );
      pad.position.set(sx, 0.1, sz);
      pad.receiveShadow = true;
      this.scene.add(pad);

      const ring = new THREE.Mesh(
        new THREE.RingGeometry(15.2, 15.8, 4),
        new THREE.MeshBasicMaterial({ color: accent, side: THREE.DoubleSide, transparent: true, opacity: 0.35 })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.rotation.z = Math.PI / 4;
      ring.position.set(sx, 0.25, sz);
      this.scene.add(ring);
    }

    for (const lm of landmarks) {
      const group = this.createLandmarkGroup(lm);
      group.position.set(lm.pos_x / 10, 0.2, lm.pos_z / 10);
      group.userData = { landmarkId: lm.id };
      this.scene.add(group);
      this.landmarkMeshes.set(lm.id, group);
    }
  }

  private createLandmarkGroup(lm: LandmarkItem): THREE.Group {
    const group = new THREE.Group();
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.18,
      metalness: 0.8,
      emissive: 0x062840,
    });
    const marbleMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.35, metalness: 0.1 });
    const domeMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      roughness: 0.28,
      metalness: 0.45,
      emissive: 0x043340,
    });

    if (lm.id.includes("tvtower")) {
      const base = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 2.8, 7, 6), marbleMat);
      base.position.y = 3.5;
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.85, 18, 12), marbleMat);
      shaft.position.y = 14;
      const deck = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 1.6, 2.2, 16), glassMat);
      deck.position.y = 15.5;
      const spire = new THREE.Mesh(new THREE.ConeGeometry(0.28, 7, 8), glassMat);
      spire.position.y = 26.5;
      group.add(base, shaft, deck, spire);
    } else if (lm.id.includes("minor") || lm.id.includes("chorsu") || lm.id.includes("cic")) {
      const hall = new THREE.Mesh(new THREE.BoxGeometry(6.5, 3.8, 6.5), marbleMat);
      hall.position.y = 1.9;
      const dome = new THREE.Mesh(new THREE.SphereGeometry(2.6, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2), domeMat);
      dome.position.y = 3.8;
      group.add(hall, dome);
    } else {
      const podium = new THREE.Mesh(new THREE.BoxGeometry(5.6, 2.4, 5.6), marbleMat);
      podium.position.y = 1.2;
      const tower = new THREE.Mesh(new THREE.BoxGeometry(3.8, 14, 3.8), glassMat);
      tower.position.y = 9.4;
      group.add(podium, tower);
    }
    return group;
  }

  public focusCoordinates(worldX: number, worldZ: number): void {
    this.target.set(
      Math.max(-65, Math.min(65, worldX / 10)),
      0,
      Math.max(-65, Math.min(65, worldZ / 10))
    );
    this.spherical.radius = Math.min(this.spherical.radius, 52);
    this.updateCameraPosition();
  }

  public resetCamera(): void {
    this.target.set(0, 0, 0);
    this.spherical = { radius: 85, theta: Math.PI / 4, phi: Math.PI / 3.2 };
    this.updateCameraPosition();
  }

  public zoom(delta: number): void {
    this.spherical.radius = Math.max(18, Math.min(140, this.spherical.radius + delta));
    this.updateCameraPosition();
  }

  public panByScreenDelta(dx: number, dy: number): void {
    const panScale = this.spherical.radius * 0.0022;
    const forward = new THREE.Vector3(
      -Math.cos(this.spherical.theta),
      0,
      -Math.sin(this.spherical.theta)
    ).normalize();
    const right = new THREE.Vector3(-forward.z, 0, forward.x).normalize();

    this.target.addScaledVector(right, -dx * panScale);
    this.target.addScaledVector(forward, dy * panScale);
    this.target.x = Math.max(-65, Math.min(65, this.target.x));
    this.target.z = Math.max(-65, Math.min(65, this.target.z));
    this.updateCameraPosition();
  }

  public rotate(deltaTheta: number): void {
    this.spherical.theta += deltaTheta;
    this.updateCameraPosition();
  }

  public setLighting(mode: LightingMode): void {
    if (mode === "day") {
      this.scene.background = new THREE.Color(0x0c2747);
      (this.scene.fog as THREE.FogExp2).color.setHex(0x0c2747);
      this.sunLight.color.setHex(0xfff7e6);
      this.sunLight.intensity = 1.8;
      this.hemiLight.intensity = 1.05;
    } else if (mode === "sunset") {
      this.scene.background = new THREE.Color(0x1f1428);
      (this.scene.fog as THREE.FogExp2).color.setHex(0x1f1428);
      this.sunLight.color.setHex(0xfbbf24);
      this.sunLight.intensity = 1.25;
      this.hemiLight.intensity = 0.7;
    } else {
      this.scene.background = new THREE.Color(0x03040a);
      (this.scene.fog as THREE.FogExp2).color.setHex(0x03040a);
      this.sunLight.color.setHex(0x38bdf8);
      this.sunLight.intensity = 0.85;
      this.hemiLight.intensity = 0.55;
    }
  }

  public syncEntities(entities: WorldEntityDescriptor[]): void {
    const activeIds = new Set(entities.map((e) => e.id));
    for (const [id, mesh] of this.dynamicEntities.entries()) {
      if (!activeIds.has(id)) {
        this.scene.remove(mesh);
        disposeObject3D(mesh);
        this.dynamicEntities.delete(id);
      }
    }
    for (const ent of entities) {
      let obj = this.dynamicEntities.get(ent.id);
      if (!obj) {
        obj = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.45, 1.1, 4, 8),
          new THREE.MeshStandardMaterial({ color: 0x00e5ff, emissive: 0x034052 })
        );
        this.scene.add(obj);
        this.dynamicEntities.set(ent.id, obj);
      }
      obj.position.set(ent.position[0] / 10, ent.position[1] + 1, ent.position[2] / 10);
      if (ent.rotationY !== undefined) obj.rotation.y = ent.rotationY;
    }
  }

  private updateCameraPosition(): void {
    const { radius, theta, phi } = this.spherical;
    this.camera.position.set(
      this.target.x + radius * Math.sin(phi) * Math.cos(theta),
      this.target.y + radius * Math.cos(phi),
      this.target.z + radius * Math.sin(phi) * Math.sin(theta)
    );
    this.camera.lookAt(this.target);
  }

  private bindEvents(): void {
    const dom = this.renderer.domElement;
    dom.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pointercancel", this.onPointerUp);
    dom.addEventListener("contextmenu", this.onContextMenu);
    dom.addEventListener("wheel", this.onWheel, { passive: true });
    dom.addEventListener("click", this.onClick);
    dom.addEventListener("webglcontextlost", this.onContextLost, false);
    dom.addEventListener("webglcontextrestored", this.onContextRestored, false);

    if (typeof ResizeObserver !== "undefined") {
      this.resizeObserver = new ResizeObserver(() => this.handleResize());
      this.resizeObserver.observe(this.container);
    }
  }

  private onContextMenu = (e: MouseEvent): void => {
    e.preventDefault();
  };

  private onContextLost = (e: Event): void => {
    e.preventDefault();
    this.contextLost = true;
    cancelAnimationFrame(this.rafId);
    this.callbacks.onContextLost?.();
  };

  private onContextRestored = (): void => {
    if (this.disposed) return;
    this.contextLost = false;
    this.handleResize();
    this.callbacks.onContextRestored?.();
    this.animate();
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (e.pointerType === "touch") {
      this.activeTouches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.activeTouches.size === 2) {
        const pts = Array.from(this.activeTouches.values());
        this.prevPinchDistance = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        this.prevTouchMidpoint = {
          x: (pts[0].x + pts[1].x) / 2,
          y: (pts[0].y + pts[1].y) / 2,
        };
        this.isDragging = false;
      } else if (this.activeTouches.size === 1) {
        this.isDragging = true;
        this.prevPointer = { x: e.clientX, y: e.clientY };
      }
      return;
    }

    this.isDragging = true;
    this.isPanningMouse = e.button === 2 || e.shiftKey;
    this.prevPointer = { x: e.clientX, y: e.clientY };
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (e.pointerType === "touch") {
      if (!this.activeTouches.has(e.pointerId)) return;
      this.activeTouches.set(e.pointerId, { x: e.clientX, y: e.clientY });

      if (this.activeTouches.size === 2) {
        const pts = Array.from(this.activeTouches.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        const mid = { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };

        if (this.prevPinchDistance !== null) {
          const pinchDelta = this.prevPinchDistance - dist;
          this.zoom(pinchDelta * 0.22);
        }
        if (this.prevTouchMidpoint !== null) {
          this.panByScreenDelta(mid.x - this.prevTouchMidpoint.x, mid.y - this.prevTouchMidpoint.y);
        }
        this.prevPinchDistance = dist;
        this.prevTouchMidpoint = mid;
        return;
      }
    }

    if (!this.isDragging) return;
    const dx = e.clientX - this.prevPointer.x;
    const dy = e.clientY - this.prevPointer.y;
    this.prevPointer = { x: e.clientX, y: e.clientY };

    if (this.isPanningMouse) {
      this.panByScreenDelta(dx, dy);
      return;
    }

    this.spherical.theta -= dx * 0.006;
    this.spherical.phi = Math.max(0.25, Math.min(Math.PI / 2.15, this.spherical.phi - dy * 0.005));
    this.updateCameraPosition();
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (e.pointerType === "touch") {
      this.activeTouches.delete(e.pointerId);
      if (this.activeTouches.size < 2) {
        this.prevPinchDistance = null;
        this.prevTouchMidpoint = null;
      }
      if (this.activeTouches.size === 1) {
        const [remaining] = Array.from(this.activeTouches.values());
        this.prevPointer = { x: remaining.x, y: remaining.y };
        this.isDragging = true;
      } else {
        this.isDragging = false;
      }
      return;
    }

    this.isDragging = false;
    this.isPanningMouse = false;
  };

  private onWheel = (e: WheelEvent): void => {
    this.zoom(e.deltaY * 0.04);
  };

  private onClick = (e: MouseEvent): void => {
    if (this.contextLost) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(Array.from(this.landmarkMeshes.values()), true);
    if (hits.length > 0 && this.callbacks.onSelectLandmark) {
      let curr: THREE.Object3D | null = hits[0].object;
      while (curr && !curr.userData?.landmarkId) curr = curr.parent;
      if (curr?.userData?.landmarkId) {
        this.callbacks.onSelectLandmark(String(curr.userData.landmarkId));
      }
    }
  };

  private handleResize(): void {
    if (this.disposed) return;
    const w = Math.max(this.container.clientWidth, 300);
    const h = Math.max(this.container.clientHeight, 300);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  private animate = (): void => {
    if (this.disposed || this.contextLost) return;
    this.rafId = requestAnimationFrame(this.animate);
    this.renderer.render(this.scene, this.camera);
    this.frameCount += 1;
    const now = performance.now();
    if (now - this.lastFpsSample >= 1000) {
      this.callbacks.onFpsUpdate?.(Math.round((this.frameCount * 1000) / (now - this.lastFpsSample)));
      this.frameCount = 0;
      this.lastFpsSample = now;
    }
  };

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    this.resizeObserver?.disconnect();
    const dom = this.renderer.domElement;
    dom.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("pointercancel", this.onPointerUp);
    dom.removeEventListener("contextmenu", this.onContextMenu);
    dom.removeEventListener("wheel", this.onWheel);
    dom.removeEventListener("click", this.onClick);
    dom.removeEventListener("webglcontextlost", this.onContextLost, false);
    dom.removeEventListener("webglcontextrestored", this.onContextRestored, false);

    disposeObject3D(this.scene);
    this.scene.clear();
    this.landmarkMeshes.clear();
    this.dynamicEntities.clear();
    this.activeTouches.clear();

    this.renderer.dispose();
    if (dom.parentElement === this.container) {
      this.container.removeChild(dom);
    }
  }
}
