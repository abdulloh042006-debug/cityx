export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "http://localhost:8080").replace(/\/+$/, "");

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export interface CityXUser {
  id: string;
  username: string;
  display_name: string;
  role: "user" | "moderator" | "admin";
  district_id: string;
  coins: number;
  gems: number;
  level: number;
  streak: number;
  reputation_score: number;
  bio: string;
  language: "uz" | "ru" | "en";
  avatar_url?: string | null;
  instagram_handle?: string | null;
  is_banned: number;
}

export interface PaymentMethod {
  code: "uzum_visa" | "uzcard";
  display_name: string;
  network: string;
  bank_name: string | null;
  recipient_name: string;
  card_last4: string;
  card_masked: string;
  enabled: boolean;
}

export interface PaymentPackage {
  id: string;
  title: string;
  reward_currency: "coins" | "gems";
  reward_amount: number;
  price_uzs: number;
}

export interface PaymentOrder {
  order_id: string;
  user_id: string;
  user_username?: string;
  package_id: string;
  payment_method_code: "uzum_visa" | "uzcard";
  payment_network_snapshot: string;
  payment_bank_snapshot: string | null;
  recipient_name_snapshot: string;
  card_last4_snapshot: string;
  expected_amount_uzs: number;
  reward_currency: "coins" | "gems";
  reward_amount: number;
  status: "pending" | "pending_review" | "approved" | "rejected" | "cancelled";
  submitted_reference: string;
  receipt_object_key: string;
  receipt_mime_type: string;
  rejection_reason: string;
  created_at: number;
  updated_at: number;
}

export interface TransferInstructions {
  order_id: string;
  payment_method_code: "uzum_visa" | "uzcard";
  network: string;
  bank_name: string | null;
  recipient_name: string;
  card_last4: string;
  card_masked: string;
  card_config_changed: boolean;
  expected_amount_uzs: number;
  reward_currency: "coins" | "gems";
  reward_amount: number;
  transfer_channel_notice: string;
  verification_notice: string;
}

export interface DistrictItem {
  id: string;
  name: string;
  code: string;
  description?: string;
  total_points: number;
  center_x: number;
  center_z: number;
}

export interface LandmarkItem {
  id: string;
  district_id: string;
  name: string;
  category: string;
  description?: string;
  current_price_coins: number;
  pos_x: number;
  pos_y: number;
  pos_z: number;
  version: number;
  owner_user_id?: string | null;
  owner_username?: string | null;
}

export interface PlaceItem {
  id: string;
  district_id: string;
  name: string;
  category: string;
  description: string;
  address_label: string;
  pos_x: number;
  pos_z: number;
}

let tokenGetter: () => string | null = () => null;
let onUnauthorized: () => void = () => {};

export function configureApiAuth(getToken: () => string | null, handle401: () => void): void {
  tokenGetter = getToken;
  onUnauthorized = handle401;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {});
  const token = tokenGetter();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (!(init.body instanceof FormData) && init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const res = await fetch(`${API_BASE_URL}${path}`, { ...init, headers });
  const text = await res.text();
  let data: Record<string, unknown> = {};
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    data = { error: text || `HTTP ${res.status}` };
  }

  if (!res.ok) {
    if (res.status === 401) onUnauthorized();
    const msg =
      (typeof data.error === "string" && data.error) ||
      (typeof data.detail === "string" && data.detail) ||
      `HTTP ${res.status}`;
    throw new ApiError(res.status, msg);
  }
  return data as T;
}

export const api = {
  getOverview: () => request<{ ok: boolean; overview: Record<string, unknown> }>("/api/city/overview"),
  getCityMap: () =>
    request<{
      ok: boolean;
      world_size_m: number;
      districts: DistrictItem[];
      landmarks: LandmarkItem[];
      taxi_fares: Record<string, { fare_coins: number; eta_min: number }>;
      user_home: Record<string, unknown> | null;
    }>("/api/city/map"),
  getPlaces: (districtId?: string, category?: string) => {
    const p = new URLSearchParams();
    if (districtId) p.set("district_id", districtId);
    if (category) p.set("category", category);
    const qs = p.toString() ? `?${p.toString()}` : "";
    return request<{ ok: boolean; places: PlaceItem[] }>(`/api/places${qs}`);
  },
  getEvents: () => request<{ ok: boolean; events: Array<Record<string, unknown>> }>("/api/events"),
  getElections: () => request<{ ok: boolean; elections: Array<Record<string, unknown>> }>("/api/elections"),
  discoverProfiles: (q = "", districtId = "") => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (districtId) p.set("district_id", districtId);
    const qs = p.toString() ? `?${p.toString()}` : "";
    return request<{ ok: boolean; profiles: Array<Record<string, unknown>> }>(`/api/social/profiles${qs}`);
  },
  getPublicProfile: (username: string) =>
    request<{
      ok: boolean;
      profile: Record<string, unknown>;
      home: Record<string, unknown> | null;
      home_likes_count: number;
      owned_landmarks: Array<Record<string, unknown>>;
    }>(`/api/social/profiles/${encodeURIComponent(username)}`),

  register: (payload: { username: string; password: string; instagram_handle?: string; district_id?: string }) =>
    request<{ ok: boolean; accessToken: string; user: CityXUser }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  login: (payload: { username: string; password: string }) =>
    request<{ ok: boolean; accessToken: string; user: CityXUser }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  miniAppAuth: (initData: string) =>
    request<{ ok: boolean; accessToken: string; user: CityXUser }>("/api/miniapp/auth", {
      method: "POST",
      body: JSON.stringify({ initData }),
    }),
  logout: () => request<{ ok: boolean }>("/api/auth/logout", { method: "POST" }),
  requestRecovery: (identifier: string) =>
    request<{ ok: boolean; accepted: boolean; email_delivery_configured: boolean; delivery_notice: string }>(
      "/api/auth/recovery/request",
      { method: "POST", body: JSON.stringify({ identifier }) }
    ),
  confirmRecovery: (token: string, new_password: string) =>
    request<{ ok: boolean; status: string }>("/api/auth/recovery/confirm", {
      method: "POST",
      body: JSON.stringify({ token, new_password }),
    }),

  getProfileMe: () =>
    request<{
      ok: boolean;
      user: CityXUser;
      home: Record<string, unknown> | null;
      vehicles: Array<Record<string, unknown>>;
      owned_landmarks: Array<Record<string, unknown>>;
      home_likes_count: number;
    }>("/api/profile/me"),
  updateProfile: (payload: {
    display_name?: string;
    bio?: string;
    instagram_handle?: string;
    avatar_url?: string;
    district_id?: string;
  }) => request<{ ok: boolean; user: CityXUser }>("/api/profile/me", { method: "PATCH", body: JSON.stringify(payload) }),
  getDashboard: () => request<{ ok: boolean } & Record<string, unknown>>("/api/dashboard"),
  claimDaily: () =>
    request<{ ok: boolean; coins_awarded: number; gems_awarded: number; coins_balance: number; gems_balance: number }>(
      "/api/economy/daily-claim",
      { method: "POST" }
    ),
  updateHome: (payload: { floors: number; has_pool: boolean; has_helipad: boolean }) =>
    request<{ ok: boolean; home: Record<string, unknown> }>("/api/homes/me", { method: "POST", body: JSON.stringify(payload) }),
  bookTaxi: (destination_district_id: string, request_id: string) =>
    request<{ ok: boolean; ride_id: string; district_name: string; fare_coins: number; balance_after: number; idempotent_replay: boolean }>(
      "/api/city/taxi",
      { method: "POST", body: JSON.stringify({ destination_district_id, request_id }) }
    ),
  acquireLandmark: (objectId: string, expected_version: number) =>
    request<{ ok: boolean; object_id: string; new_version: number; next_price_coins: number }>(
      `/api/objects/${encodeURIComponent(objectId)}/acquire`,
      { method: "POST", body: JSON.stringify({ expected_version }) }
    ),

  getWallet: () =>
    request<{ ok: boolean; coins: number; gems: number; transactions: Array<Record<string, unknown>> }>("/api/wallet"),
  getPaymentMethods: () => request<{ ok: boolean; methods: PaymentMethod[] }>("/api/payments/methods"),
  getPaymentPackages: () => request<{ ok: boolean; packages: PaymentPackage[] }>("/api/payments/packages"),
  createPaymentOrder: (payload: { package_id: string; payment_method_code: "uzum_visa" | "uzcard"; idempotency_key: string }) =>
    request<{ ok: boolean; order: PaymentOrder; transfer_instructions: TransferInstructions; idempotent_replay: boolean }>(
      "/api/payments/orders",
      { method: "POST", body: JSON.stringify(payload) }
    ),
  listMyOrders: () => request<{ ok: boolean; orders: PaymentOrder[] }>("/api/payments/orders"),
  uploadReceipt: (orderId: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<{ ok: boolean; order: PaymentOrder }>(`/api/payments/orders/${encodeURIComponent(orderId)}/receipt`, {
      method: "POST",
      body: fd,
    });
  },
  submitPaymentProof: (orderId: string, submitted_reference: string) =>
    request<{ ok: boolean; order: PaymentOrder }>(`/api/payments/orders/${encodeURIComponent(orderId)}/submit`, {
      method: "POST",
      body: JSON.stringify({ submitted_reference }),
    }),
  cancelPaymentOrder: (orderId: string) =>
    request<{ ok: boolean; order: PaymentOrder }>(`/api/payments/orders/${encodeURIComponent(orderId)}/cancel`, {
      method: "POST",
    }),

  getSettings: () =>
    request<{ ok: boolean; settings: { language: "uz" | "ru" | "en"; classic_mode: boolean; notify_prefs: Record<string, boolean> } }>(
      "/api/settings"
    ),
  updateSettings: (payload: { language?: "uz" | "ru" | "en"; classic_mode?: boolean; notify_prefs?: Record<string, boolean> }) =>
    request<{ ok: boolean; settings: Record<string, unknown> }>("/api/settings", { method: "PATCH", body: JSON.stringify(payload) }),
  getNotifications: () => request<{ ok: boolean; notifications: Array<Record<string, unknown>> }>("/api/notifications"),
  markNotificationRead: (id: string) =>
    request<{ ok: boolean }>(`/api/notifications/${encodeURIComponent(id)}/read`, { method: "POST" }),

  getFriends: () => request<{ ok: boolean; friends: Array<Record<string, unknown>> }>("/api/social/friends"),
  requestFriend: (target_username: string) =>
    request<{ ok: boolean; friendship: Record<string, unknown> }>("/api/social/friends/request", {
      method: "POST",
      body: JSON.stringify({ target_username }),
    }),
  acceptFriend: (friendshipId: string) =>
    request<{ ok: boolean }>(`/api/social/friends/${encodeURIComponent(friendshipId)}/accept`, { method: "POST" }),
  likeHome: (homeId: string) =>
    request<{ ok: boolean; likes_count: number }>(`/api/social/homes/${encodeURIComponent(homeId)}/like`, { method: "POST" }),
  rsvpEvent: (eventId: string, join: boolean) =>
    request<{ ok: boolean; joined: boolean; attendees_count: number }>(`/api/events/${encodeURIComponent(eventId)}/rsvp`, {
      method: "POST",
      body: JSON.stringify({ join }),
    }),
  castVote: (electionId: string, candidate_id: string) =>
    request<{ ok: boolean }>(`/api/elections/${encodeURIComponent(electionId)}/vote`, {
      method: "POST",
      body: JSON.stringify({ candidate_id }),
    }),

  adminOverview: () => request<{ ok: boolean; overview: Record<string, number> }>("/api/admin/overview"),
  adminPayments: (status = "", method = "") => {
    const p = new URLSearchParams();
    if (status) p.set("status", status);
    if (method) p.set("method", method);
    const qs = p.toString() ? `?${p.toString()}` : "";
    return request<{ ok: boolean; orders: PaymentOrder[] }>(`/api/admin/payments${qs}`);
  },
  adminApprovePayment: (orderId: string) =>
    request<{ ok: boolean; order: PaymentOrder }>(`/api/admin/payments/${encodeURIComponent(orderId)}/approve`, {
      method: "POST",
    }),
  adminRejectPayment: (orderId: string, rejection_reason: string) =>
    request<{ ok: boolean; order: PaymentOrder }>(`/api/admin/payments/${encodeURIComponent(orderId)}/reject`, {
      method: "POST",
      body: JSON.stringify({ rejection_reason }),
    }),
  adminUsers: () => request<{ ok: boolean; users: Array<Record<string, unknown>> }>("/api/admin/users"),
  adminBanUser: (userId: string, reason: string) =>
    request<{ ok: boolean }>(`/api/admin/users/${encodeURIComponent(userId)}/ban`, {
      method: "POST",
      body: JSON.stringify({ reason }),
    }),
  adminIssueRecoveryToken: (userId: string) =>
    request<{ ok: boolean; recovery_token: string; expires_in_seconds: number }>(
      `/api/admin/users/${encodeURIComponent(userId)}/recovery-token`,
      { method: "POST" }
    ),
  adminAuditLogs: () =>
    request<{ ok: boolean; admin_audit_logs: Array<Record<string, unknown>>; payment_audit_logs: Array<Record<string, unknown>> }>(
      "/api/admin/audit-logs"
    ),
};
