#!/usr/bin/env python3
"""
CITYX — NEXT-GENERATION TELEGRAM BOT (Telegram Bot API 10.5+)
==============================================================
Project:  CityX (https://cityx.uz)
Bot:      @cityx_bot
Runtime:  Python 3.10+ (Zero external dependencies — Pure Standard Library)

Implemented Capabilities:
1.  Telegram Bot API 10.5 Programmatic Bot Settings (`setMySettings` + `getMe` verification)
2.  Private Chat Topic Navigation (9 logical CityX areas)
3.  Telegram HTML Widgets (Bot API 10.4/10.5):
    - `sendWidget`, `sendSharedWidget`, `answerWidgetQuery`,
      `editMessageWidgetData`, `editSharedWidgetData`
    - `widget_query` & `shared_widget_query` handlers
    - Built-in CI/Startup QuickJS Sandbox Validator (<=32KB UTF-8, <=4KB zlib-9,
      zero disallowed inputs, zero network APIs, zero secrets)
    - All 10 CityX Widgets (Welcome, Daily Dashboard, Property, Garage, Racing,
      District Battle, Event, Taxi, Transaction, Election)
    - Strict Production Scope Guard (Private chats in prod; group/inline/forward
      flagged off until Telegram enables them in production)
4.  Telegram Rich Messages (`sendRichMessage` + automatic HTML fallback)
5.  Ephemeral Group Messages (`ephemeral_message_parameters` + authoritative DB logs)
6.  Unified Dual-Mode Callback Query Processor (HMAC signed tokens, TTL, ownership,
    idempotency & deduplication)
7.  Telegram Mini App `initData` HMAC-SHA256 & 300s freshness verifier + HTTP server
8.  Unified Payment Service:
    - Telegram Stars (`XTR` — `pre_checkout_query` & `successful_payment`)
    - Uzbekistan Fiat Adapters (Click, Payme, Uzum — `UZS`)
    - TON Wallet strictly DISABLED by non-negotiable policy
9.  Deterministic Fallback Pipeline (Widget -> Rich Message -> Standard HTML + InlineKeyboard)

Quick Start:
    export BOT_TOKEN="123456:ABC-DEF..."
    export BOT_USERNAME="cityx_bot"
    export CITYX_WEB_URL="https://cityx.uz"
    python3 cityx_bot.py
"""

from __future__ import annotations

import base64
import datetime
import hashlib
import hmac
import json
import logging
import os
import queue
import re
import signal
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zlib
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional, Tuple

# =============================================================================
# 1. CONFIGURATION & RUNTIME CAPABILITY REGISTRY
# =============================================================================

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
)
logger = logging.getLogger("cityx.bot")


@dataclass(frozen=True)
class Config:
    bot_token: str = os.getenv("BOT_TOKEN", "")
    bot_username: str = os.getenv("BOT_USERNAME", "cityx_bot")
    web_base_url: str = os.getenv("CITYX_WEB_URL", "https://cityx.uz").rstrip("/")
    miniapp_short_name: str = os.getenv("MINIAPP_SHORT_NAME", "app")
    api_base_url: str = os.getenv("TELEGRAM_API_BASE", "https://api.telegram.org").rstrip("/")
    environment: str = os.getenv("CITYX_ENV", "production").lower()  # production | test_server
    db_path: str = os.getenv("CITYX_DB_PATH", "cityx_bot.sqlite3")
    signing_secret: str = os.getenv("CITYX_SIGNING_SECRET", "")
    http_host: str = os.getenv("HTTP_HOST", "0.0.0.0")
    http_port: int = int(os.getenv("HTTP_PORT", "8080"))
    webhook_url: str = os.getenv("WEBHOOK_URL", "")
    webhook_secret: str = os.getenv("WEBHOOK_SECRET", "")

    # Payment provider secrets (keep separate and isolated)
    click_secret_key: str = os.getenv("CLICK_SECRET_KEY", "")
    payme_merchant_key: str = os.getenv("PAYME_MERCHANT_KEY", "")
    uzum_webhook_secret: str = os.getenv("UZUM_WEBHOOK_SECRET", "")

    # Non-Negotiable TON Wallet Lock (NEVER enable without executive/legal/security sign-off)
    ton_wallet_enabled: bool = False


class CapabilityRegistry:
    """
    Runtime Telegram Bot API 10.5 Capability Registry.
    Strictly distinguishes production availability from test-server capabilities.
    """

    BOT_API_BASELINE = "10.5"
    BOT_API_RELEASE_DATE = "2026-11-22"

    def __init__(self, environment: str) -> None:
        self.is_test_server = environment == "test_server"
        self.flags: Dict[str, bool] = {
            # Production-enabled Bot API 10.4 / 10.5 features
            "widgets_private_chat": os.getenv("CAP_WIDGETS_PRIVATE", "true").lower() == "true",
            "rich_messages": os.getenv("CAP_RICH_MESSAGES", "true").lower() == "true",
            "ephemeral_group_messages": os.getenv("CAP_EPHEMERAL", "true").lower() == "true",
            "private_chat_topics": os.getenv("CAP_PRIVATE_TOPICS", "true").lower() == "true",
            "programmatic_settings": os.getenv("CAP_SET_MY_SETTINGS", "true").lower() == "true",
            "telegram_stars": os.getenv("CAP_STARS", "true").lower() == "true",
            # Test-server-only features as of Nov 2026 (strictly OFF in production)
            "widgets_groups": self.is_test_server,
            "widgets_inline": self.is_test_server,
            "widgets_shared_forwards": self.is_test_server,
            # Permanently disabled until explicit legal & security sign-off
            "ton_wallet": False,
        }

    def enabled(self, feature: str) -> bool:
        return bool(self.flags.get(feature, False))

    def can_send_widget_in_chat(self, chat_type: str) -> bool:
        """Enforce Bot API 10.4/10.5 production chat-type availability rules."""
        if chat_type == "private":
            return self.enabled("widgets_private_chat")
        if chat_type in ("group", "supergroup"):
            return self.enabled("widgets_groups")
        return False


# =============================================================================
# 2. AUTHORITATIVE CITYX BACKEND STORAGE (SQLite Single-File Persistence)
# =============================================================================

class CityXDatabase:
    """
    Unified CityX identity, virtual economy, properties, garage, racing,
    district battles, events, elections, idempotency, and payment audit ledger.
    Designed to mirror PostgreSQL schemas cleanly without duplicating identity logic.
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()
        self._seed_defaults()

    def _init_schema(self) -> None:
        with self._lock:
            cur = self.conn.cursor()
            cur.executescript(
                """
                PRAGMA journal_mode=WAL;
                PRAGMA foreign_keys=ON;

                -- Canonical CityX User Account (shared across Bot, Widgets, Mini App, cityx.uz)
                CREATE TABLE IF NOT EXISTS cityx_users (
                    user_id TEXT PRIMARY KEY,
                    username TEXT NOT NULL,
                    district TEXT NOT NULL DEFAULT 'Downtown',
                    coins INTEGER NOT NULL DEFAULT 1000,
                    gems INTEGER NOT NULL DEFAULT 25,
                    level INTEGER NOT NULL DEFAULT 2,
                    streak INTEGER NOT NULL DEFAULT 1,
                    quest_done INTEGER NOT NULL DEFAULT 2,
                    quest_total INTEGER NOT NULL DEFAULT 5,
                    last_daily_claim TEXT DEFAULT '',
                    classic_mode INTEGER NOT NULL DEFAULT 0,
                    notify_prefs TEXT NOT NULL DEFAULT '{"properties":true,"quests":true,"social":true,"events":true,"garage":true,"district":true}',
                    created_at INTEGER NOT NULL
                );

                -- Verified Identity Linking (prevents duplicate accounts across Telegram & Web)
                CREATE TABLE IF NOT EXISTS user_identities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL REFERENCES cityx_users(user_id),
                    provider TEXT NOT NULL,           -- 'telegram' | 'web_email' | 'web_passkey'
                    external_id TEXT NOT NULL,
                    verified_at INTEGER NOT NULL,
                    UNIQUE(provider, external_id)
                );

                -- Private Chat Topic Mapping (9 logical areas)
                CREATE TABLE IF NOT EXISTS user_topics (
                    telegram_user_id INTEGER NOT NULL,
                    topic_key TEXT NOT NULL,
                    message_thread_id INTEGER NOT NULL,
                    PRIMARY KEY (telegram_user_id, topic_key)
                );

                -- Virtual Properties (public fields only shown in widgets)
                CREATE TABLE IF NOT EXISTS properties (
                    property_id TEXT PRIMARY KEY,
                    owner_user_id TEXT NOT NULL REFERENCES cityx_users(user_id),
                    name TEXT NOT NULL,
                    district TEXT NOT NULL,
                    building_level INTEGER NOT NULL DEFAULT 1,
                    est_value_coins INTEGER NOT NULL DEFAULT 12500,
                    upgrade_status TEXT NOT NULL DEFAULT 'Ready for Level 2'
                );

                -- Garage Vehicles
                CREATE TABLE IF NOT EXISTS vehicles (
                    vehicle_id TEXT PRIMARY KEY,
                    owner_user_id TEXT NOT NULL REFERENCES cityx_users(user_id),
                    name TEXT NOT NULL,
                    vehicle_class TEXT NOT NULL,
                    rating INTEGER NOT NULL,
                    upgrade_pct INTEGER NOT NULL DEFAULT 40,
                    energy_pct INTEGER NOT NULL DEFAULT 80
                );

                -- District Battle Seasons & Contributions
                CREATE TABLE IF NOT EXISTS district_scores (
                    district TEXT PRIMARY KEY,
                    points INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS district_participants (
                    user_id TEXT PRIMARY KEY REFERENCES cityx_users(user_id),
                    district TEXT NOT NULL,
                    points INTEGER NOT NULL DEFAULT 0
                );

                -- CityX Live Events
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    location TEXT NOT NULL,
                    start_ts INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS event_rsvps (
                    event_id TEXT NOT NULL REFERENCES events(event_id),
                    user_id TEXT NOT NULL REFERENCES cityx_users(user_id),
                    joined_at INTEGER NOT NULL,
                    PRIMARY KEY (event_id, user_id)
                );

                -- Official CityX Elections (strict unique vote per citizen)
                CREATE TABLE IF NOT EXISTS elections (
                    election_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    published INTEGER NOT NULL DEFAULT 0,
                    candidates_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS election_votes (
                    election_id TEXT NOT NULL REFERENCES elections(election_id),
                    user_id TEXT NOT NULL REFERENCES cityx_users(user_id),
                    candidate_id TEXT NOT NULL,
                    voted_at INTEGER NOT NULL,
                    PRIMARY KEY (election_id, user_id)
                );

                -- Unified Payment Orders & Immutable Audit Log
                CREATE TABLE IF NOT EXISTS payment_orders (
                    order_id TEXT PRIMARY KEY,
                    provider TEXT NOT NULL,           -- 'telegram_stars' | 'click' | 'payme' | 'uzum'
                    provider_reference TEXT DEFAULT '',
                    user_id TEXT NOT NULL REFERENCES cityx_users(user_id),
                    amount_minor INTEGER NOT NULL,
                    currency TEXT NOT NULL,           -- 'XTR' | 'UZS'
                    status TEXT NOT NULL DEFAULT 'pending', -- pending | authorized | paid | failed | refunded
                    idempotency_key TEXT NOT NULL UNIQUE,
                    webhook_verified_at INTEGER DEFAULT 0,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS payment_audit_logs (
                    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    details_json TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );

                -- Widget Instance Tracking (binds message_id -> widget_id, entity_id, owner)
                CREATE TABLE IF NOT EXISTS widget_instances (
                    chat_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    widget_id TEXT NOT NULL,
                    owner_user_id TEXT NOT NULL,
                    entity_id TEXT DEFAULT '',
                    state_json TEXT NOT NULL DEFAULT '{}',
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY (chat_id, message_id)
                );

                -- Idempotency & Duplicate Request Guard
                CREATE TABLE IF NOT EXISTS idempotency_keys (
                    idem_key TEXT PRIMARY KEY,
                    created_at INTEGER NOT NULL
                );

                -- Beta Invitations & Independent Referral Tracking
                CREATE TABLE IF NOT EXISTS beta_invites (
                    invite_code TEXT PRIMARY KEY,
                    created_by_admin INTEGER NOT NULL,
                    max_uses INTEGER NOT NULL DEFAULT 10,
                    uses_count INTEGER NOT NULL DEFAULT 0,
                    created_at INTEGER NOT NULL
                );

                -- Authoritative Moderation & Ephemeral Audit Log
                CREATE TABLE IF NOT EXISTS moderation_logs (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER NOT NULL,
                    target_telegram_id INTEGER NOT NULL,
                    action TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );
                """
            )
            self.conn.commit()

    def _seed_defaults(self) -> None:
        with self._lock:
            cur = self.conn.cursor()
            # Seed districts
            for name, pts in [
                ("Downtown", 14820),
                ("Tech Park", 13690),
                ("Tashkent Harbor", 11940),
                ("Skyline Arena", 10450),
            ]:
                cur.execute(
                    "INSERT OR IGNORE INTO district_scores (district, points) VALUES (?, ?)",
                    (name, pts),
                )
            # Seed default upcoming CityX event (starts 6 hours from first boot)
            cur.execute(
                """
                INSERT OR IGNORE INTO events (event_id, title, location, start_ts)
                VALUES (?, ?, ?, ?)
                """,
                ("evt_neon_grandprix", "Neon Grand Prix & District Expo", "Central Plaza 3D Arena", int(time.time()) + 21600),
            )
            # Seed default CityX Mayor Election
            candidates = [
                {"id": "cand_aziza", "name": "Aziza K.", "platform": "Green Mobility & Tech Grants"},
                {"id": "cand_timur", "name": "Timur R.", "platform": "Racing League & Lower Property Tax"},
                {"id": "cand_sardor", "name": "Sardor M.", "platform": "Harbor Expansion & Builder Rewards"},
            ]
            cur.execute(
                """
                INSERT OR IGNORE INTO elections (election_id, title, published, candidates_json)
                VALUES (?, ?, ?, ?)
                """,
                ("elec_2026_q4", "CityX Council Election 2026", 0, json.dumps(candidates)),
            )
            self.conn.commit()

    def acquire_idempotency(self, key: str, ttl_seconds: int = 3600) -> bool:
        """Return True if lock acquired for the first time, False if duplicate."""
        now = int(time.time())
        with self._lock:
            cur = self.conn.cursor()
            cur.execute("DELETE FROM idempotency_keys WHERE created_at < ?", (now - ttl_seconds,))
            try:
                cur.execute(
                    "INSERT INTO idempotency_keys (idem_key, created_at) VALUES (?, ?)",
                    (key, now),
                )
                self.conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False

    def get_or_create_telegram_user(self, tg_user: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        """Resolve canonical CityX user_id from Telegram user object; never create duplicates."""
        tg_id = str(tg_user["id"])
        username = tg_user.get("username") or tg_user.get("first_name") or f"citizen_{tg_id[-4:]}"
        now = int(time.time())

        with self._lock:
            cur = self.conn.cursor()
            row = cur.execute(
                """
                SELECT u.* FROM cityx_users u
                JOIN user_identities i ON i.user_id = u.user_id
                WHERE i.provider = 'telegram' AND i.external_id = ?
                """,
                (tg_id,),
            ).fetchone()
            if row:
                if row["username"] != username:
                    cur.execute("UPDATE cityx_users SET username = ? WHERE user_id = ?", (username, row["user_id"]))
                    self.conn.commit()
                return dict(row) | {"username": username}, False

            user_id = f"cx_{uuid.uuid4().hex[:16]}"
            cur.execute(
                """
                INSERT INTO cityx_users (user_id, username, created_at)
                VALUES (?, ?, ?)
                """,
                (user_id, username, now),
            )
            cur.execute(
                """
                INSERT INTO user_identities (user_id, provider, external_id, verified_at)
                VALUES (?, 'telegram', ?, ?)
                """,
                (user_id, tg_id, now),
            )
            # Provision starter property and 2 starter vehicles for immediate demo/testing
            cur.execute(
                """
                INSERT INTO properties (property_id, owner_user_id, name, district, building_level, est_value_coins, upgrade_status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (f"prop_{user_id[-6:]}", user_id, "Skyline Loft #104", "Downtown", 2, 18500, "Upgrade Ready (500 CX)"),
            )
            cur.execute(
                """
                INSERT INTO vehicles (vehicle_id, owner_user_id, name, vehicle_class, rating, upgrade_pct, energy_pct)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (f"veh_{user_id[-6:]}_1", user_id, "CityX Volt GT", "S-CLASS", 842, 65, 75),
            )
            cur.execute(
                """
                INSERT INTO vehicles (vehicle_id, owner_user_id, name, vehicle_class, rating, upgrade_pct, energy_pct)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (f"veh_{user_id[-6:]}_2", user_id, "Samarkand Drift X", "A-CLASS", 715, 45, 90),
            )
            # Provision a sample pending transaction order for Transaction Widget inspection
            sample_order_id = f"ORD-{uuid.uuid4().hex[:8].upper()}"
            cur.execute(
                """
                INSERT INTO payment_orders (
                    order_id, provider, provider_reference, user_id, amount_minor,
                    currency, status, idempotency_key, created_at, updated_at
                ) VALUES (?, 'telegram_stars', 'STARS-PENDING', ?, 150, 'XTR', 'pending', ?, ?, ?)
                """,
                (sample_order_id, user_id, f"init_{sample_order_id}", now, now),
            )
            self.conn.commit()
            user_row = cur.execute("SELECT * FROM cityx_users WHERE user_id = ?", (user_id,)).fetchone()
            return dict(user_row), True


# =============================================================================
# 3. TELEGRAM BOT API 10.5 HTTP CLIENT
# =============================================================================

class TelegramAPIError(Exception):
    def __init__(self, method: str, error_code: int, description: str, parameters: Optional[Dict[str, Any]] = None):
        super().__init__(f"Telegram API error on {method} [{error_code}]: {description}")
        self.method = method
        self.error_code = error_code
        self.description = description
        self.parameters = parameters or {}


class TelegramBotClient:
    """
    Lightweight, zero-dependency Telegram Bot API 10.5 client.
    Supports Bot API 10.5 `setMySettings`, Bot API 10.4/10.5 HTML Widgets,
    Bot API 10.1+ Rich Messages, Bot API 10.2+ Ephemeral Messages, and Stars payments.
    """

    def __init__(self, config: Config) -> None:
        self.config = config
        self.base_url = f"{config.api_base_url}/bot{config.bot_token}"

    def call(self, method: str, payload: Optional[Dict[str, Any]] = None, timeout: int = 25) -> Any:
        if not self.config.bot_token:
            raise RuntimeError("BOT_TOKEN environment variable is not set.")

        url = f"{self.base_url}/{method}"
        body = json.dumps(payload or {}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json; charset=utf-8"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8")
                parsed = json.loads(raw)
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            try:
                parsed_err = json.loads(err_body)
                raise TelegramAPIError(
                    method,
                    parsed_err.get("error_code", exc.code),
                    parsed_err.get("description", err_body),
                    parsed_err.get("parameters"),
                ) from exc
            except json.JSONDecodeError:
                raise TelegramAPIError(method, exc.code, err_body) from exc
        except urllib.error.URLError as exc:
            raise TelegramAPIError(method, 0, f"Network error: {exc.reason}") from exc

        if not parsed.get("ok"):
            raise TelegramAPIError(
                method,
                parsed.get("error_code", 0),
                parsed.get("description", "Unknown Bot API error"),
                parsed.get("parameters"),
            )
        return parsed.get("result")

    # --- Bot API 10.5 Settings & Discovery ---
    def get_me(self) -> Dict[str, Any]:
        return self.call("getMe")

    def set_my_settings(self, settings: Dict[str, Any]) -> bool:
        return bool(self.call("setMySettings", settings))

    # --- Bot API 10.4 / 10.5 HTML Widgets ---
    def send_widget(
        self,
        chat_id: int,
        html: str,
        *,
        width: int = 0,
        height: int = 0,
        allow_queries: bool = True,
        chat_data: Optional[Dict[str, Any]] = None,
        public_data: Optional[Dict[str, Any]] = None,
        caption: Optional[str] = None,
        parse_mode: str = "HTML",
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "chat_id": chat_id,
            "html": html,
            "width": width,
            "height": height,
            "allow_queries": allow_queries,
        }
        if chat_data is not None:
            payload["chat_data"] = json.dumps(chat_data, ensure_ascii=False, separators=(",", ":"))
        if public_data is not None:
            payload["public_data"] = json.dumps(public_data, ensure_ascii=False, separators=(",", ":"))
        if caption:
            payload["caption"] = caption
            payload["parse_mode"] = parse_mode
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if message_thread_id:
            payload["message_thread_id"] = message_thread_id
        return self.call("sendWidget", payload)

    def send_shared_widget(
        self,
        chat_id: int,
        widget_id: str,
        *,
        chat_data: Optional[Dict[str, Any]] = None,
        caption: Optional[str] = None,
        parse_mode: str = "HTML",
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"chat_id": chat_id, "widget_id": widget_id}
        if chat_data is not None:
            payload["chat_data"] = json.dumps(chat_data, ensure_ascii=False, separators=(",", ":"))
        if caption:
            payload["caption"] = caption
            payload["parse_mode"] = parse_mode
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if message_thread_id:
            payload["message_thread_id"] = message_thread_id
        return self.call("sendSharedWidget", payload)

    def answer_widget_query(self, widget_query_id: str, text: str = "") -> bool:
        payload: Dict[str, Any] = {"widget_query_id": widget_query_id}
        if text:
            # Bot API widget answer limit is 1 KB
            payload["text"] = text[:200]
        return bool(self.call("answerWidgetQuery", payload))

    def edit_message_widget_data(
        self,
        *,
        chat_id: Optional[int] = None,
        message_id: Optional[int] = None,
        inline_message_id: Optional[str] = None,
        chat_data: Optional[Dict[str, Any]] = None,
        public_data: Optional[Dict[str, Any]] = None,
    ) -> Any:
        payload: Dict[str, Any] = {}
        if inline_message_id:
            payload["inline_message_id"] = inline_message_id
        else:
            payload["chat_id"] = chat_id
            payload["message_id"] = message_id
        if chat_data is not None:
            payload["chat_data"] = json.dumps(chat_data, ensure_ascii=False, separators=(",", ":"))
        if public_data is not None:
            payload["public_data"] = json.dumps(public_data, ensure_ascii=False, separators=(",", ":"))
        return self.call("editMessageWidgetData", payload)

    def edit_shared_widget_data(self, widget_id: str, public_data: Dict[str, Any]) -> bool:
        return bool(
            self.call(
                "editSharedWidgetData",
                {
                    "widget_id": widget_id,
                    "public_data": json.dumps(public_data, ensure_ascii=False, separators=(",", ":")),
                },
            )
        )

    # --- Bot API 10.1+ Rich Messages ---
    def send_rich_message(
        self,
        chat_id: int,
        rich_message: Dict[str, Any],
        *,
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
        ephemeral_message_parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"chat_id": chat_id, "rich_message": rich_message}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if message_thread_id:
            payload["message_thread_id"] = message_thread_id
        if ephemeral_message_parameters:
            payload["ephemeral_message_parameters"] = ephemeral_message_parameters
        return self.call("sendRichMessage", payload)

    # --- Standard & Ephemeral Messages ---
    def send_message(
        self,
        chat_id: int,
        text: str,
        *,
        parse_mode: str = "HTML",
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
        ephemeral_message_parameters: Optional[Dict[str, Any]] = None,
        reply_parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode,
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if message_thread_id:
            payload["message_thread_id"] = message_thread_id
        if ephemeral_message_parameters:
            payload["ephemeral_message_parameters"] = ephemeral_message_parameters
        if reply_parameters:
            payload["reply_parameters"] = reply_parameters
        return self.call("sendMessage", payload)

    def answer_callback_query(self, callback_query_id: str, text: str = "", show_alert: bool = False) -> bool:
        payload: Dict[str, Any] = {"callback_query_id": callback_query_id, "show_alert": show_alert}
        if text:
            payload["text"] = text[:200]
        return bool(self.call("answerCallbackQuery", payload))

    def create_forum_topic(self, chat_id: int, name: str) -> Dict[str, Any]:
        return self.call("createForumTopic", {"chat_id": chat_id, "name": name[:128]})

    # --- Telegram Stars Payments ---
    def send_stars_invoice(
        self,
        chat_id: int,
        title: str,
        description: str,
        payload_id: str,
        stars_amount: int,
        message_thread_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "chat_id": chat_id,
            "title": title,
            "description": description,
            "payload": payload_id,
            "provider_token": "",  # Must be empty string for Telegram Stars (XTR)
            "currency": "XTR",
            "prices": [{"label": title, "amount": stars_amount}],
        }
        if message_thread_id:
            body["message_thread_id"] = message_thread_id
        return self.call("sendInvoice", body)

    def answer_pre_checkout_query(self, query_id: str, ok: bool, error_message: str = "") -> bool:
        payload: Dict[str, Any] = {"pre_checkout_query_id": query_id, "ok": ok}
        if not ok and error_message:
            payload["error_message"] = error_message
        return bool(self.call("answerPreCheckoutQuery", payload))

    def get_updates(self, offset: int = 0, timeout: int = 20) -> List[Dict[str, Any]]:
        return self.call(
            "getUpdates",
            {
                "offset": offset,
                "timeout": timeout,
                "allowed_updates": [
                    "message",
                    "callback_query",
                    "widget_query",
                    "shared_widget_query",
                    "pre_checkout_query",
                    "chat_join_request",
                ],
            },
            timeout=timeout + 10,
        )


# =============================================================================
# 4. WIDGET VALIDATOR & ALL 10 CITYX HTML WIDGET TEMPLATES (A - J)
# =============================================================================

MAX_WIDGET_HTML_BYTES = 32768
MAX_WIDGET_ZLIB9_BYTES = 4096
MAX_WIDGET_QUERY_BYTES = 64

DISALLOWED_WIDGET_PATTERNS = [
    (re.compile(r"<\s*(input|select|textarea)\b", re.I), "Disallowed form control (<input>/<select>/<textarea>)"),
    (re.compile(r"\b(fetch|XMLHttpRequest|WebSocket)\b"), "Disallowed network API inside offline QuickJS sandbox"),
    (re.compile(r"https?://[^\s\"']+\.(js|css|woff2?|ttf)\b", re.I), "External JS/CSS/font resource not allowed"),
    (re.compile(r"\b\d+\s*vh\b", re.I), "Height-relative unit (vh) is not supported in Telegram Widgets"),
]

WIDGET_TEMPLATES: Dict[str, str] = {
    # A. CityX Welcome Widget
    "cityx_welcome": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:14px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.brand{font-weight:700;font-size:15px;color:var(--tg-theme-accent-text-color)}
.pill{font-size:11px;padding:2px 8px;border-radius:99px;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-subtitle-text-color)}
.box{background:var(--tg-theme-secondary-bg-color);border-radius:10px;padding:8px 10px;margin:8px 0;display:flex;justify-content:space-between;align-items:center}
.mut{font-size:12px;color:var(--tg-theme-hint-color)}.val{font-weight:700;font-size:15px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px}
button{width:100%;padding:8px 10px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color);margin-top:6px}
button[disabled]{opacity:.55}
</style>
<div class="hdr"><span class="brand">CITYX</span><span class="pill" id="dist">CityX</span></div>
<div id="greet">Welcome to CityX!</div>
<div class="box">
  <div><div class="mut">Coins Balance</div><div class="val" id="coins">0</div></div>
  <div style="text-align:right"><div class="mut">Daily Reward</div><div class="val" id="dstat">—</div></div>
</div>
<button class="pri" id="enter">Enter 3D City</button>
<div class="grid">
  <button id="bDaily">Daily Reward</button><button id="bDash">Dashboard</button>
  <button id="bProp">Properties</button><button id="bGar">Garage</button>
</div>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  document.getElementById('dist').textContent=String(S.district||'CityX');
  document.getElementById('greet').textContent='Welcome, @'+String(S.username||'citizen')+'. Your digital city is live.';
  document.getElementById('coins').textContent=Number(S.coins||0).toLocaleString()+' CX';
  document.getElementById('dstat').textContent=S.dailyReady?'Ready':'Claimed';
  document.getElementById('bDaily').disabled=busy||!S.dailyReady;
}
async function ask(cmd){if(busy)return;busy=true;draw();try{W.HapticFeedback&&W.HapticFeedback.impactOccurred('light');await W.request(cmd)}catch{}busy=false;draw();}
document.getElementById('enter').onclick=()=>S.miniAppUrl&&W.openTelegramLink(S.miniAppUrl);
document.getElementById('bDaily').onclick=()=>ask('w:daily');
document.getElementById('bDash').onclick=()=>ask('w:dash');
document.getElementById('bProp').onclick=()=>ask('w:prop');
document.getElementById('bGar').onclick=()=>ask('w:gar');
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # B. CityX Daily Dashboard Widget
    "cityx_daily_dashboard": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.ttl{font-weight:700;font-size:15px}.tag{font-size:11px;font-weight:600;color:var(--tg-theme-accent-text-color)}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px}
.card{background:var(--tg-theme-secondary-bg-color);border-radius:8px;padding:7px;text-align:center}
.k{font-size:11px;color:var(--tg-theme-hint-color)}.v{font-weight:700;font-size:14px;margin-top:2px}
.barw{background:var(--tg-theme-secondary-bg-color);border-radius:8px;padding:8px;margin-bottom:8px}
.row{display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px}
.track{height:7px;border-radius:99px;background:var(--tg-theme-section-separator-color);overflow:hidden}
.fill{height:100%;background:var(--tg-theme-button-color);width:0%}
.meta{display:flex;justify-content:space-between;font-size:12px;color:var(--tg-theme-subtitle-text-color);margin-bottom:8px}
.acts{display:flex;gap:6px}
button{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{flex:0 0 80px;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}
.note{font-size:11px;color:var(--tg-theme-hint-color);margin-top:6px;min-height:14px}button[disabled]{opacity:.5}
</style>
<div class="top"><span class="ttl">Daily Dashboard</span><span class="tag" id="lvl">LVL 1</span></div>
<div class="stats">
  <div class="card"><div class="k">Coins</div><div class="v" id="c">0</div></div>
  <div class="card"><div class="k">Gems</div><div class="v" id="g">0</div></div>
  <div class="card"><div class="k">Streak</div><div class="v" id="st">0d</div></div>
</div>
<div class="barw">
  <div class="row"><span>Daily Quests</span><strong id="qt">0/0</strong></div>
  <div class="track"><div class="fill" id="qf"></div></div>
</div>
<div class="meta"><span id="dist">District</span><strong id="rk">Rank #—</strong></div>
<div class="acts"><button class="pri" id="claim">Claim Reward</button><button class="sec" id="ref">Sync</button></div>
<div class="note" id="msg"></div>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  const d=Number(S.questDone||0),t=Math.max(1,Number(S.questTotal||1));
  document.getElementById('lvl').textContent='LVL '+Number(S.level||1);
  document.getElementById('c').textContent=Number(S.coins||0).toLocaleString();
  document.getElementById('g').textContent=Number(S.gems||0).toLocaleString();
  document.getElementById('st').textContent=Number(S.streak||0)+'d';
  document.getElementById('qt').textContent=d+'/'+t;
  document.getElementById('qf').style.width=Math.min(100,Math.round(d/t*100))+'%';
  document.getElementById('dist').textContent=String(S.district||'District');
  document.getElementById('rk').textContent='Rank #'+(S.rank||'—');
  const cb=document.getElementById('claim');cb.disabled=busy||!S.claimable;
  cb.textContent=S.claimable?'Claim Daily Reward':'Reward Claimed';
  document.getElementById('ref').disabled=busy;document.getElementById('msg').textContent=String(S.msg||'');
}
async function ask(p){if(busy)return;busy=true;draw();try{const r=await W.request(p);if(r)document.getElementById('msg').textContent=r}catch{document.getElementById('msg').textContent='Retry shortly.'}busy=false;draw();}
document.getElementById('claim').onclick=()=>ask('d:claim');
document.getElementById('ref').onclick=()=>ask('d:refresh');
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # C. Property Widget (never exposes private owner details)
    "cityx_property": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hero{background:var(--tg-theme-secondary-bg-color);border-radius:10px;padding:10px;display:flex;gap:10px;align-items:center;margin-bottom:8px}
.ico{width:44px;height:44px;border-radius:8px;background:var(--tg-theme-button-color);display:flex;align-items:center;justify-content:center;flex:0 0 44px}
.name{font-weight:700;font-size:15px}.sub{font-size:12px;color:var(--tg-theme-hint-color)}
.rows{border-top:1px solid var(--tg-theme-section-separator-color);margin:6px 0}
.r{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--tg-theme-section-separator-color)}
.k{color:var(--tg-theme-hint-color)}.v{font-weight:600}.acts{display:flex;gap:6px;margin-top:8px}
button{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}button[disabled]{opacity:.5}
</style>
<div class="hero">
  <div class="ico"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--tg-theme-button-text-color)" stroke-width="2"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 11h2M13 11h2M9 15h2M13 15h2"/></svg></div>
  <div><div class="name" id="nm">Property</div><div class="sub" id="ds">District</div></div>
</div>
<div class="rows">
  <div class="r"><span class="k">Public Owner</span><span class="v" id="ow">@public</span></div>
  <div class="r"><span class="k">Building Level</span><span class="v" id="lv">Lvl 1</span></div>
  <div class="r"><span class="k">Est. Value</span><span class="v" id="vl">0 CX</span></div>
  <div class="r"><span class="k">Upgrade Status</span><span class="v" id="up">—</span></div>
</div>
<div class="acts"><button class="sec" id="upg">Upgrade</button><button class="pri" id="open">Open in Mini App</button></div>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  document.getElementById('nm').textContent=String(S.name||'Property');
  document.getElementById('ds').textContent=String(S.district||'CityX');
  document.getElementById('ow').textContent=String(S.ownerHandle||'Citizen');
  document.getElementById('lv').textContent='Level '+Number(S.level||1);
  document.getElementById('vl').textContent=Number(S.valueCoins||0).toLocaleString()+' CX';
  document.getElementById('up').textContent=String(S.upgradeStatus||'Ready');
  document.getElementById('upg').disabled=busy||!S.canUpgrade;
}
document.getElementById('upg').onclick=async()=>{if(busy)return;busy=true;draw();try{await W.request('p:upg')}catch{}busy=false;draw();};
document.getElementById('open').onclick=()=>S.miniAppUrl&&W.openTelegramLink(S.miniAppUrl);
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # D. Garage Widget
    "cityx_garage": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.ttl{font-weight:700;font-size:15px}.cls{font-size:11px;padding:2px 8px;border-radius:99px;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-accent-text-color);font-weight:700}
.box{background:var(--tg-theme-secondary-bg-color);border-radius:10px;padding:9px;margin-bottom:8px}
.row{display:flex;justify-content:space-between;font-size:12px;margin:4px 0}
.tr{height:6px;border-radius:99px;background:var(--tg-theme-section-separator-color);overflow:hidden;margin-bottom:6px}
.fl{height:100%;background:var(--tg-theme-button-color);width:0%}
.nav{display:grid;grid-template-columns:44px 1fr 44px;gap:6px;margin-bottom:6px}
button{padding:8px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}
.pri{width:100%;background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}button[disabled]{opacity:.5}
</style>
<div class="hdr"><span class="ttl" id="vn">Vehicle</span><span class="cls" id="vc">CLASS</span></div>
<div class="box">
  <div class="row"><span>Performance Rating</span><strong id="pr">0 PR</strong></div>
  <div class="row"><span>Upgrade Progress</span><strong id="up">0%</strong></div>
  <div class="tr"><div class="fl" id="ub"></div></div>
  <div class="row"><span>Energy / Fuel</span><strong id="en">100%</strong></div>
  <div class="tr"><div class="fl" id="eb"></div></div>
</div>
<div class="nav"><button id="prev">‹</button><button id="refuel">Recharge</button><button id="next">›</button></div>
<button class="pri" id="open">Open Garage in Mini App</button>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  document.getElementById('vn').textContent=String(S.name||'Vehicle');
  document.getElementById('vc').textContent=String(S.vClass||'STANDARD');
  document.getElementById('pr').textContent=Number(S.rating||0)+' PR';
  const u=Math.min(100,Math.max(0,Number(S.upgPct||0))),e=Math.min(100,Math.max(0,Number(S.energyPct||0)));
  document.getElementById('up').textContent=u+'%';document.getElementById('ub').style.width=u+'%';
  document.getElementById('en').textContent=e+'%';document.getElementById('eb').style.width=e+'%';
  const m=Number(S.total||1)>1;document.getElementById('prev').disabled=busy||!m;
  document.getElementById('next').disabled=busy||!m;document.getElementById('refuel').disabled=busy||e>=100;
}
async function ask(c){if(busy)return;busy=true;draw();try{await W.request(c)}catch{}busy=false;draw();}
document.getElementById('prev').onclick=()=>ask('g:prev');document.getElementById('next').onclick=()=>ask('g:next');
document.getElementById('refuel').onclick=()=>ask('g:refuel');
document.getElementById('open').onclick=()=>S.miniAppUrl&&W.openTelegramLink(S.miniAppUrl);
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # E. Racing Widget (launches Mini App for actual 3D driving)
    "cityx_racing": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.ttl{font-weight:700;font-size:15px}.rec{font-size:12px;color:var(--tg-theme-accent-text-color);font-weight:600}
.tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:8px}
.tab{padding:6px;border:0;border-radius:7px;font:600 12px system-ui,sans-serif;cursor:pointer;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}
.tab.on{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.lb{background:var(--tg-theme-secondary-bg-color);border-radius:8px;padding:7px 9px;margin-bottom:8px}
.lr{display:flex;justify-content:space-between;font-size:12px;padding:3px 0}
.st{font-size:12px;color:var(--tg-theme-hint-color);margin-bottom:8px}.acts{display:flex;gap:6px}
button.act{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}button[disabled]{opacity:.5}
</style>
<div class="hdr"><span class="ttl">CityX Racing</span><span class="rec" id="rec">Record: —</span></div>
<div class="tabs" id="tabs"></div><div class="lb" id="lb"></div><div class="st" id="st"></div>
<div class="acts"><button class="act sec" id="acc">Accept Challenge</button><button class="act pri" id="play">Race in Mini App</button></div>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  document.getElementById('rec').textContent='Record: '+String(S.record||'—');
  document.getElementById('st').textContent=String(S.status||'Select a track & accept challenge.');
  const ts=Array.isArray(S.tracks)?S.tracks.slice(0,3):['Sprint','Drift','Circuit'];
  const sel=Number(S.selected||0),tb=document.getElementById('tabs');tb.innerHTML='';
  ts.forEach((t,i)=>{const b=document.createElement('button');b.className='tab'+(i===sel?' on':'');b.textContent=String(t);b.disabled=busy;b.onclick=()=>ask('r:sel:'+i);tb.appendChild(b);});
  const lb=document.getElementById('lb');lb.innerHTML='';
  (Array.isArray(S.top3)?S.top3.slice(0,3):[]).forEach((x,i)=>{
    const r=document.createElement('div');r.className='lr';
    const l=document.createElement('span');l.textContent='#'+(i+1)+' '+String(x.u||'Driver');
    const v=document.createElement('strong');v.textContent=String(x.t||'—');
    r.appendChild(l);r.appendChild(v);lb.appendChild(r);
  });
  document.getElementById('acc').disabled=busy;
}
async function ask(c){if(busy)return;busy=true;draw();try{await W.request(c)}catch{}busy=false;draw();}
document.getElementById('acc').onclick=()=>ask('r:accept');
document.getElementById('play').onclick=()=>S.miniAppRaceUrl&&W.openTelegramLink(S.miniAppRaceUrl);
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # F. District Battle Widget
    "cityx_district_battle": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.ttl{font-weight:700;font-size:15px}.st{font-size:11px;font-weight:700;color:var(--tg-theme-accent-text-color)}
.list{background:var(--tg-theme-secondary-bg-color);border-radius:10px;padding:8px;margin-bottom:8px}
.row{margin-bottom:6px}.row:last-child{margin-bottom:0}.hd{display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px}
.tr{height:6px;border-radius:99px;background:var(--tg-theme-section-separator-color);overflow:hidden}
.fl{height:100%;background:var(--tg-theme-button-color)}
.me{display:flex;justify-content:space-between;font-size:12px;color:var(--tg-theme-subtitle-text-color);margin-bottom:8px}
.acts{display:flex;gap:6px}button{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{flex:0 0 76px;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}button[disabled]{opacity:.5}
</style>
<div class="hdr"><span class="ttl" id="sn">District Battle</span><span class="st" id="cs">LIVE</span></div>
<div class="list" id="dl"></div>
<div class="me"><span id="ud">District: —</span><strong id="up">0 pts</strong></div>
<div class="acts"><button class="pri" id="join">Join Battle</button><button class="sec" id="sync">Sync</button></div>
<script>
const W=TelegramWidget;let P={},C={},busy=false;
function draw(){
  try{P=JSON.parse(W.publicData||'{}')}catch{P={}}try{C=JSON.parse(W.chatData||'{}')}catch{C={}}
  document.getElementById('sn').textContent=String(P.season||'District Battle');
  document.getElementById('cs').textContent=String(P.status||'ACTIVE');
  const ds=Array.isArray(P.districts)?P.districts.slice(0,4):[];
  const mx=Math.max(1,...ds.map(x=>Number(x.pts||0))),el=document.getElementById('dl');el.innerHTML='';
  ds.forEach((d,i)=>{
    const r=document.createElement('div');r.className='row';
    const h=document.createElement('div');h.className='hd';
    const n=document.createElement('span');n.textContent='#'+(i+1)+' '+String(d.name||'District');
    const p=document.createElement('strong');p.textContent=Number(d.pts||0).toLocaleString()+' pts';
    h.appendChild(n);h.appendChild(p);
    const tr=document.createElement('div');tr.className='tr';
    const fl=document.createElement('div');fl.className='fl';fl.style.width=Math.round(Number(d.pts||0)/mx*100)+'%';
    tr.appendChild(fl);r.appendChild(h);r.appendChild(tr);el.appendChild(r);
  });
  document.getElementById('ud').textContent='District: '+String(C.userDistrict||'Downtown');
  document.getElementById('up').textContent='Your pts: '+Number(C.userPts||0).toLocaleString();
  const jb=document.getElementById('join');jb.disabled=busy||!!C.joined;jb.textContent=C.joined?'Participating (+100)':'Participate Now';
  document.getElementById('sync').disabled=busy;
}
async function ask(c){if(busy)return;busy=true;draw();try{await W.request(c)}catch{}busy=false;draw();}
document.getElementById('join').onclick=()=>ask('b:join');document.getElementById('sync').onclick=()=>ask('b:sync');
W.onEvent('publicDataChanged',draw);W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # G. CityX Event Widget
    "cityx_event": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.badge{display:inline-block;font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-accent-text-color);margin-bottom:6px}
.ttl{font-weight:700;font-size:15px;margin-bottom:4px}.loc{font-size:12px;color:var(--tg-theme-hint-color);margin-bottom:8px}
.cd{background:var(--tg-theme-secondary-bg-color);border-radius:10px;padding:9px;text-align:center;margin-bottom:8px}
.tm{font-weight:700;font-size:17px;letter-spacing:.5px}.sub{font-size:11px;color:var(--tg-theme-hint-color);margin-top:2px}
.acts{display:flex;gap:6px}button{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}button[disabled]{opacity:.5}
</style>
<div class="badge" id="st">UPCOMING EVENT</div><div class="ttl" id="tt">CityX Event</div><div class="loc" id="lc">—</div>
<div class="cd"><div class="tm" id="tm">--:--:--</div><div class="sub" id="at">0 registered</div></div>
<div class="acts"><button class="pri" id="btn">Join Event</button><button class="sec" id="open">Details</button></div>
<script>
const W=TelegramWidget;let P={},C={},busy=false;
function fmt(s){if(s<=0)return'LIVE NOW';const d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60),x=s%60,p=n=>String(n).padStart(2,'0');return(d?d+'d ':'')+p(h)+':'+p(m)+':'+p(x);}
function tick(){const ts=Number(P.startTs||0);document.getElementById('tm').textContent=ts?fmt(Math.floor(ts-Date.now()/1000)):'TBA';}
function draw(){
  try{P=JSON.parse(W.publicData||'{}')}catch{P={}}try{C=JSON.parse(W.chatData||'{}')}catch{C={}}
  document.getElementById('tt').textContent=String(P.title||'CityX Event');
  document.getElementById('lc').textContent=String(P.location||'CityX');
  document.getElementById('at').textContent=Number(P.attendees||0).toLocaleString()+' registered';
  document.getElementById('st').textContent=C.joined?'REGISTERED':'UPCOMING EVENT';
  const b=document.getElementById('btn');b.disabled=busy;b.textContent=C.joined?'Leave Event':'Join Event';b.className=C.joined?'sec':'pri';
  tick();
}
document.getElementById('btn').onclick=async()=>{if(busy)return;busy=true;draw();try{await W.request(C.joined?'e:leave':'e:join')}catch{}busy=false;draw();};
document.getElementById('open').onclick=()=>C.miniAppUrl&&W.openTelegramLink(C.miniAppUrl);
W.onEvent('publicDataChanged',draw);W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();setInterval(tick,1000);W.ready&&W.ready();
</script>""",

    # H. Taxi Widget (predefined destination buttons; zero keyboard input)
    "cityx_taxi": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.ttl{font-weight:700;font-size:15px;margin-bottom:2px}.frm{font-size:12px;color:var(--tg-theme-hint-color);margin-bottom:8px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px}
.dst{padding:7px;border:0;border-radius:8px;font:600 12px system-ui,sans-serif;cursor:pointer;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}
.dst.on{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.box{background:var(--tg-theme-secondary-bg-color);border-radius:8px;padding:8px 10px;display:flex;justify-content:space-between;margin-bottom:8px}
.acts{display:flex;gap:6px}button.act{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}button[disabled]{opacity:.5}
</style>
<div class="ttl">CityX Taxi</div><div class="frm" id="frm">Pickup: —</div><div class="grid" id="ds"></div>
<div class="box">
  <div><div style="font-size:11px;color:var(--tg-theme-hint-color)">Estimated Fare</div><strong id="fare">0 CX</strong></div>
  <div style="text-align:right"><div style="font-size:11px;color:var(--tg-theme-hint-color)">ETA</div><strong id="eta">— min</strong></div>
</div>
<div class="acts"><button class="act pri" id="go">Confirm Travel</button><button class="act sec" id="map">Full Route</button></div>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  document.getElementById('frm').textContent='Pickup: '+String(S.from||'Downtown');
  const ds=Array.isArray(S.dests)?S.dests.slice(0,4):['Downtown','Tech Park','Harbor','Arena'];
  const sel=Number(S.selIdx||0),el=document.getElementById('ds');el.innerHTML='';
  ds.forEach((d,i)=>{const b=document.createElement('button');b.className='dst'+(i===sel?' on':'');b.textContent=String(d);b.disabled=busy||!!S.booked;b.onclick=()=>ask('t:d:'+i);el.appendChild(b);});
  document.getElementById('fare').textContent=Number(S.fareCoins||0).toLocaleString()+' CX';
  document.getElementById('eta').textContent=Number(S.etaMin||2)+' min';
  const gb=document.getElementById('go');gb.disabled=busy||!!S.booked;gb.textContent=S.booked?'Ride Confirmed':'Confirm Travel';
}
async function ask(c){if(busy)return;busy=true;draw();try{await W.request(c)}catch{}busy=false;draw();}
document.getElementById('go').onclick=()=>ask('t:go');
document.getElementById('map').onclick=()=>S.miniAppRouteUrl&&W.openTelegramLink(S.miniAppRouteUrl);
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # I. Transaction Widget (read-only refresh; NEVER marks order paid on tap)
    "cityx_transaction": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.ttl{font-weight:700;font-size:15px}.st{font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px;background:var(--tg-theme-secondary-bg-color)}
.amt{font-size:20px;font-weight:700;margin:4px 0 8px}.rows{border-top:1px solid var(--tg-theme-section-separator-color);margin-bottom:8px}
.r{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--tg-theme-section-separator-color);font-size:12px}
.k{color:var(--tg-theme-hint-color)}.v{font-weight:600}.acts{display:flex;gap:6px}
button{flex:1;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer}
.pri{background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.sec{background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color)}
.note{font-size:11px;color:var(--tg-theme-hint-color);margin-top:6px}button[disabled]{opacity:.5}
</style>
<div class="hdr"><span class="ttl">Transaction Status</span><span class="st" id="st">PENDING</span></div>
<div class="amt" id="am">0</div>
<div class="rows">
  <div class="r"><span class="k">Reference</span><span class="v" id="rf">—</span></div>
  <div class="r"><span class="k">Provider</span><span class="v" id="pv">—</span></div>
  <div class="r"><span class="k">Verification</span><span class="v" id="cf">Awaiting Webhook</span></div>
  <div class="r"><span class="k">Last Sync</span><span class="v" id="up">—</span></div>
</div>
<div class="acts"><button class="sec" id="chk">Refresh Status</button><button class="pri" id="rcp">View Receipt</button></div>
<div class="note">Payment confirmation requires verified backend webhook.</div>
<script>
const W=TelegramWidget;let S={},busy=false;
function draw(){
  try{S=JSON.parse(W.chatData||'{}')}catch{S={}}
  document.getElementById('st').textContent=String(S.status||'PENDING').toUpperCase();
  document.getElementById('am').textContent=String(S.amount||'0')+' '+String(S.currency||'');
  document.getElementById('rf').textContent=String(S.ref||'—');
  document.getElementById('pv').textContent=String(S.provider||'CityX');
  document.getElementById('cf').textContent=S.confirmed?'Verified by Server':'Unconfirmed';
  document.getElementById('up').textContent=String(S.updatedAt||'—');
  document.getElementById('chk').disabled=busy;document.getElementById('rcp').disabled=!S.receiptUrl;
}
document.getElementById('chk').onclick=async()=>{if(busy)return;busy=true;draw();try{await W.request('tx:check')}catch{}busy=false;draw();};
document.getElementById('rcp').onclick=()=>S.receiptUrl&&W.openLink(S.receiptUrl);
W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",

    # J. CityX Election Widget (eligibility & unique vote enforced in backend DB)
    "cityx_election": r"""<!doctype html><style>
*{box-sizing:border-box}body{margin:10px 12px;font:13px/1.35 system-ui,sans-serif;color:var(--tg-theme-text-color)}
.hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.ttl{font-weight:700;font-size:15px}.el{font-size:11px;font-weight:600;color:var(--tg-theme-accent-text-color)}
.cands{display:flex;flex-direction:column;gap:6px;margin:8px 0}
.c{width:100%;text-align:left;padding:8px 10px;border:1px solid var(--tg-theme-section-separator-color);border-radius:8px;background:var(--tg-theme-secondary-bg-color);color:var(--tg-theme-text-color);cursor:pointer}
.c.on{border-color:var(--tg-theme-button-color);outline:1px solid var(--tg-theme-button-color)}
.cn{font-weight:700;font-size:13px}.cm{font-size:11px;color:var(--tg-theme-hint-color)}
.bar{height:5px;border-radius:99px;background:var(--tg-theme-button-color);margin-top:5px}
.pri{width:100%;padding:9px;border:0;border-radius:8px;font:600 13px system-ui,sans-serif;cursor:pointer;background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color)}
.note{font-size:11px;color:var(--tg-theme-hint-color);margin-top:6px}button[disabled]{opacity:.55}
</style>
<div class="hdr"><span class="ttl" id="tt">CityX Election</span><span class="el" id="el">Checking...</span></div>
<div class="cands" id="cs"></div>
<button class="pri" id="cast">Confirm Official Vote</button>
<div class="note" id="nt">Eligibility and unique vote verified by CityX backend.</div>
<script>
const W=TelegramWidget;let P={},C={},busy=false;
function draw(){
  try{P=JSON.parse(W.publicData||'{}')}catch{P={}}try{C=JSON.parse(W.chatData||'{}')}catch{C={}}
  document.getElementById('tt').textContent=String(P.title||'CityX Election');
  document.getElementById('el').textContent=C.votedId?'Vote Recorded':(C.eligible?'Eligible':'Ineligible');
  const ls=Array.isArray(P.candidates)?P.candidates.slice(0,4):[],bx=document.getElementById('cs');bx.innerHTML='';
  ls.forEach((cd,i)=>{
    const b=document.createElement('button'),sel=(C.pendingIdx===i)||(C.votedId&&C.votedId===cd.id);
    b.className='c'+(sel?' on':'');b.disabled=busy||!C.eligible||!!C.votedId||!!P.published;
    const n=document.createElement('div');n.className='cn';n.textContent=String(cd.name||'Candidate');
    const m=document.createElement('div');m.className='cm';m.textContent=String(cd.platform||'')+(P.published?' — '+Number(cd.pct||0)+'%':'');
    b.appendChild(n);b.appendChild(m);
    if(P.published){const br=document.createElement('div');br.className='bar';br.style.width=Math.min(100,Number(cd.pct||0))+'%';b.appendChild(br);}
    b.onclick=()=>ask('el:pick:'+i);bx.appendChild(b);
  });
  const cb=document.getElementById('cast');
  cb.disabled=busy||!C.eligible||!!C.votedId||!!P.published||(typeof C.pendingIdx!=='number');
  cb.textContent=P.published?'Results Published':(C.votedId?'Vote Confirmed':'Confirm Official Vote');
  if(C.reason)document.getElementById('nt').textContent=String(C.reason);
}
async function ask(c){if(busy)return;busy=true;draw();try{await W.request(c)}catch{}busy=false;draw();}
document.getElementById('cast').onclick=()=>ask('el:cast');
W.onEvent('publicDataChanged',draw);W.onEvent('chatDataChanged',draw);W.onEvent('themeChanged',draw);draw();W.ready&&W.ready();
</script>""",
}


def validate_all_widget_templates() -> Dict[str, Tuple[int, int]]:
    """
    Validate every CityX HTML widget against Telegram Bot API 10.4/10.5 constraints:
    - Raw UTF-8 <= 32,768 bytes
    - Zlib level-9 compressed <= 4,096 bytes
    - Zero NUL characters
    - Zero disallowed form controls or network APIs
    """
    report: Dict[str, Tuple[int, int]] = {}
    for wid, html in WIDGET_TEMPLATES.items():
        if "\x00" in html:
            raise ValueError(f"Widget {wid} contains NUL byte.")
        raw_bytes = html.encode("utf-8")
        compressed = zlib.compress(raw_bytes, level=9)
        if len(raw_bytes) > MAX_WIDGET_HTML_BYTES:
            raise ValueError(f"Widget {wid} exceeds 32 KB raw limit ({len(raw_bytes)} bytes).")
        if len(compressed) > MAX_WIDGET_ZLIB9_BYTES:
            raise ValueError(f"Widget {wid} exceeds 4 KB zlib-9 limit ({len(compressed)} bytes).")
        for pattern, reason in DISALLOWED_WIDGET_PATTERNS:
            if pattern.search(html):
                raise ValueError(f"Widget {wid} failed QuickJS policy check: {reason}")
        report[wid] = (len(raw_bytes), len(compressed))
    return report


# =============================================================================
# 5. SECURITY UTILITIES: SIGNED CALLBACKS & MINI APP initData VERIFICATION
# =============================================================================

class SecurityGuard:
    """Handles HMAC-signed expiring callbacks and Telegram Mini App initData verification."""

    def __init__(self, config: Config) -> None:
        self.config = config

    def sign_callback(self, action: str, entity_id: str = "", ttl_seconds: int = 3600) -> str:
        """Create compact signed callback_data (strictly <= 64 bytes)."""
        if not self.config.signing_secret:
            raise RuntimeError("CITYX_SIGNING_SECRET must be configured and persisted across restarts.")
        if not action or ":" in action or ":" in entity_id:
            raise ValueError("Callback action and entity id must be non-empty colon-free values.")
        if not 1 <= ttl_seconds <= 7 * 24 * 3600:
            raise ValueError("Callback lifetime must be between 1 second and 7 days.")
        exp = int(time.time()) + ttl_seconds
        base = f"v1:{action}:{entity_id}:{exp}"
        sig = hmac.new(self.config.signing_secret.encode(), base.encode(), hashlib.sha256).hexdigest()[:20]
        token = f"{base}:{sig}"
        if len(token.encode("utf-8")) > 64:
            raise ValueError(f"Callback payload exceeds 64 bytes: {token}")
        return token

    def verify_callback(self, data: str) -> Tuple[bool, str, str, str]:
        """Validate callback HMAC signature and expiration. Returns (ok, action, entity_id, error)."""
        if not self.config.signing_secret or len(data.encode("utf-8")) > 64:
            return False, "", "", "Invalid callback configuration or size."
        parts = data.split(":")
        if len(parts) != 5 or parts[0] != "v1":
            return False, "", "", "Invalid callback format."
        _, action, entity_id, exp_str, sig = parts
        base = f"v1:{action}:{entity_id}:{exp_str}"
        expected = hmac.new(self.config.signing_secret.encode(), base.encode(), hashlib.sha256).hexdigest()[:20]
        if not hmac.compare_digest(sig, expected):
            return False, "", "", "Tampered callback signature."
        try:
            exp = int(exp_str)
        except ValueError:
            return False, "", "", "Malformed callback expiration."
        if int(time.time()) >= exp:
            return False, action, entity_id, "Expired action. Please refresh."
        return True, action, entity_id, ""

    def verify_miniapp_init_data(self, init_data: str, max_age_seconds: int = 300) -> Dict[str, Any]:
        """
        Official Telegram Mini App initData server-side cryptographic validation:
        1. Parse query string & extract `hash`.
        2. Build sorted `data_check_string`.
        3. Compute HMAC-SHA256 using secret key HMAC-SHA256("WebAppData", BOT_TOKEN).
        4. Enforce `auth_date` freshness window (default 300 seconds).
        """
        if not init_data:
            raise ValueError("Missing initData.")
        if len(init_data.encode("utf-8")) > 16_384:
            raise ValueError("initData is too large.")
        pairs = urllib.parse.parse_qsl(init_data, keep_blank_values=True, strict_parsing=True, max_num_fields=64)
        if len({key for key, _ in pairs}) != len(pairs):
            raise ValueError("Duplicate initData fields.")
        parsed = dict(pairs)
        received_hash = parsed.pop("hash", "")
        if not received_hash:
            raise ValueError("Missing hash in initData.")

        data_check_string = "\n".join(f"{k}={parsed[k]}" for k in sorted(parsed.keys()))
        secret_key = hmac.new(b"WebAppData", self.config.bot_token.encode("utf-8"), hashlib.sha256).digest()
        computed_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()

        if not hmac.compare_digest(computed_hash, received_hash):
            raise ValueError("Invalid initData HMAC signature.")

        try:
            auth_date = int(parsed.get("auth_date", "0"))
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid initData auth_date.") from exc
        if max_age_seconds <= 0 or auth_date > int(time.time()) + 30 or int(time.time()) - auth_date > max_age_seconds:
            raise ValueError("Expired initData session.")

        user_raw = parsed.get("user")
        if not user_raw:
            raise ValueError("Missing user object in initData.")
        return json.loads(user_raw)


# =============================================================================
# 6. RICH MESSAGES & EPHEMERAL SERVICE
# =============================================================================

class RichMessageFactory:
    """Reusable CityX Bot API 10.1+/10.5 Rich Message templates with HTML fallbacks."""

    @staticmethod
    def economy_notification(
        tx_type: str, amount_fmt: str, balance_after: str, status: str, order_id: str, web_url: str
    ) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
        rich = {
            "blocks": [
                {"type": "heading", "level": 3, "text": "CityX Economy Update"},
                {
                    "type": "table",
                    "headers": ["Field", "Value"],
                    "rows": [
                        ["Type", tx_type],
                        ["Amount", amount_fmt],
                        ["Balance After", balance_after],
                        ["Status", status.upper()],
                        ["Reference", order_id],
                    ],
                },
            ]
        }
        fallback_html = (
            f"<b>CityX Economy Update</b>\n"
            f"Type: {tx_type}\n"
            f"Amount: <b>{amount_fmt}</b>\n"
            f"Balance After: {balance_after}\n"
            f"Status: <b>{status.upper()}</b>\n"
            f"Ref: <code>{order_id}</code>"
        )
        markup = {
            "inline_keyboard": [
                [{"text": "Transaction History", "web_app": {"url": f"{web_url}/app/economy/transactions"}}]
            ]
        }
        return rich, fallback_html, markup

    @staticmethod
    def property_acquisition(
        prop_name: str, district: str, prev_owner: str, new_owner: str, amount_fmt: str, tx_ref: str, prop_id: str, web_url: str
    ) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
        rich = {
            "blocks": [
                {"type": "heading", "level": 2, "text": "Property Acquisition Confirmed"},
                {
                    "type": "table",
                    "headers": ["Attribute", "Details"],
                    "rows": [
                        ["Property", f"{prop_name} ({district})"],
                        ["Previous Owner", prev_owner],
                        ["New Owner", new_owner],
                        ["Purchase Amount", amount_fmt],
                        ["Transaction Ref", tx_ref],
                    ],
                },
                {
                    "type": "expandable_blockquote",
                    "blocks": [
                        {
                            "type": "paragraph",
                            "text": "Deed stored authoritatively in CityX Registry. Manage upgrades inside the Mini App.",
                        }
                    ],
                },
            ]
        }
        fallback_html = (
            f"<b>Property Acquisition Confirmed</b>\n"
            f"Property: {prop_name} ({district})\n"
            f"Previous Owner: {prev_owner}\nNew Owner: {new_owner}\n"
            f"Amount: <b>{amount_fmt}</b>\nRef: <code>{tx_ref}</code>"
        )
        markup = {
            "inline_keyboard": [
                [{"text": "Inspect Property in 3D", "web_app": {"url": f"{web_url}/app/property/{prop_id}"}}]
            ]
        }
        return rich, fallback_html, markup


# =============================================================================
# 7. UNIFIED PAYMENT SERVICE (TELEGRAM STARS + CLICK / PAYME / UZUM)
# =============================================================================

class UnifiedPaymentService:
    """
    Authoritative CityX payment ledger supporting Telegram Stars (XTR) and
    isolated Uzbekistan fiat adapters (Click, Payme, Uzum — UZS).
    TON wallet is strictly disabled.
    """

    def __init__(self, config: Config, db: CityXDatabase) -> None:
        self.config = config
        self.db = db

    def create_order(self, user_id: str, provider: str, amount_minor: int, currency: str, idempotency_key: str) -> str:
        if provider == "ton":
            raise PermissionError("TON wallet integration is disabled by CityX security & legal policy.")
        if provider not in {"telegram_stars", "click", "payme", "uzum"}:
            raise ValueError("Unsupported payment provider.")
        if not isinstance(amount_minor, int) or isinstance(amount_minor, bool) or amount_minor <= 0:
            raise ValueError("Payment amount must be a positive integer in the provider currency's minor units.")
        if not idempotency_key or len(idempotency_key) > 200:
            raise ValueError("A non-empty idempotency key of at most 200 characters is required.")
        if provider == "telegram_stars" and currency != "XTR":
            raise ValueError("Telegram Stars orders must use currency XTR.")
        if provider in ("click", "payme", "uzum") and currency != "UZS":
            raise ValueError("Uzbekistan payment providers must use currency UZS.")

        order_id = f"CX-{uuid.uuid4().hex[:10].upper()}"
        now = int(time.time())
        with self.db._lock:
            cur = self.db.conn.cursor()
            existing = cur.execute(
                "SELECT order_id FROM payment_orders WHERE idempotency_key = ?", (idempotency_key,)
            ).fetchone()
            if existing:
                return existing["order_id"]
            cur.execute(
                """
                INSERT INTO payment_orders (
                    order_id, provider, user_id, amount_minor, currency,
                    status, idempotency_key, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?)
                """,
                (order_id, provider, user_id, amount_minor, currency, idempotency_key, now, now),
            )
            cur.execute(
                "INSERT INTO payment_audit_logs (order_id, event_type, details_json, created_at) VALUES (?, ?, ?, ?)",
                (order_id, "order_created", json.dumps({"provider": provider, "amount": amount_minor, "currency": currency}), now),
            )
            self.db.conn.commit()
        return order_id

    def mark_order_paid_via_verified_webhook(
        self, order_id: str, provider: str, provider_reference: str, gems_reward: int
    ) -> Optional[Dict[str, Any]]:
        """
        The ONLY permitted path to transition a payment order to `paid`.
        Protected by idempotency check so webhook replays never double-credit Gems.
        """
        now = int(time.time())
        with self.db._lock:
            cur = self.db.conn.cursor()
            order = cur.execute("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,)).fetchone()
            if not order or order["provider"] != provider:
                return None
            if order["status"] == "paid":
                return dict(order)  # Idempotent replay protection
            if order["status"] != "pending" or not provider_reference or gems_reward < 0:
                return None

            cur.execute(
                """
                UPDATE payment_orders
                SET status = 'paid', provider_reference = ?, webhook_verified_at = ?, updated_at = ?
                WHERE order_id = ?
                """,
                (provider_reference, now, now, order_id),
            )
            cur.execute(
                "UPDATE cityx_users SET gems = gems + ? WHERE user_id = ?",
                (gems_reward, order["user_id"]),
            )
            cur.execute(
                "INSERT INTO payment_audit_logs (order_id, event_type, details_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    order_id,
                    "webhook_verified_paid",
                    json.dumps({"provider": provider, "provider_reference": provider_reference, "gems_credited": gems_reward}),
                    now,
                ),
            )
            self.db.conn.commit()
            updated = cur.execute("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,)).fetchone()
            return dict(updated)

    def verify_click_signature(self, params: Dict[str, str]) -> bool:
        """Click.uz MD5 signature verification (isolated Uzbekistan adapter)."""
        if not self.config.click_secret_key:
            return False
        raw = (
            f"{params.get('click_trans_id', '')}{params.get('service_id', '')}"
            f"{self.config.click_secret_key}{params.get('merchant_trans_id', '')}"
            f"{params.get('amount', '')}{params.get('action', '')}{params.get('sign_time', '')}"
        )
        expected = hashlib.md5(raw.encode("utf-8")).hexdigest()
        return hmac.compare_digest(expected, params.get("sign_string", ""))

    def verify_payme_basic_auth(self, auth_header: str) -> bool:
        """Payme.uz JSON-RPC Basic Auth verification."""
        if not self.config.payme_merchant_key or not auth_header.startswith("Basic "):
            return False
        try:
            decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
            _, key = decoded.split(":", 1)
            return hmac.compare_digest(key, self.config.payme_merchant_key)
        except (ValueError, UnicodeDecodeError):
            return False

    def verify_uzum_signature(self, raw_body: bytes, signature_header: str) -> bool:
        """Uzum Bank HMAC-SHA256 webhook signature verification."""
        if not self.config.uzum_webhook_secret or not signature_header:
            return False
        expected = hmac.new(self.config.uzum_webhook_secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature_header)


# =============================================================================
# 8. CITYX BOT CORE ENGINE (WIDGETS, TOPICS, CALLBACKS, FALLBACKS)
# =============================================================================

PRIVATE_TOPICS: List[Tuple[str, str]] = [
    ("home", "CityX Home"),
    ("profile", "My Profile"),
    ("city", "Virtual City"),
    ("properties", "My Properties"),
    ("garage", "Garage"),
    ("games", "Games"),
    ("economy", "Economy"),
    ("events", "Events"),
    ("support", "Support"),
]

TAXI_DESTINATIONS = [
    {"name": "Downtown", "fare": 120, "eta": 2},
    {"name": "Tech Park", "fare": 180, "eta": 4},
    {"name": "Harbor", "fare": 240, "eta": 5},
    {"name": "Arena", "fare": 160, "eta": 3},
]

RACING_TRACKS = [
    {
        "name": "Sprint",
        "record": "01:12.44",
        "top3": [{"u": "@aziza_gt", "t": "01:12.44"}, {"u": "@timur_x", "t": "01:13.08"}, {"u": "@bek_uz", "t": "01:14.21"}],
    },
    {
        "name": "Drift",
        "record": "48,900 pts",
        "top3": [{"u": "@drift_king", "t": "48,900"}, {"u": "@sardor_m", "t": "46,200"}, {"u": "@malika_v", "t": "44,750"}],
    },
    {
        "name": "Circuit",
        "record": "02:38.19",
        "top3": [{"u": "@timur_x", "t": "02:38.19"}, {"u": "@aziza_gt", "t": "02:39.05"}, {"u": "@jasur_99", "t": "02:41.60"}],
    },
]


class CityXBotEngine:
    """Orchestrates Telegram Bot API 10.5 updates, widgets, fallbacks, and payments."""

    def __init__(self, config: Config, db: CityXDatabase, api: TelegramBotClient) -> None:
        self.config = config
        self.db = db
        self.api = api
        self.caps = CapabilityRegistry(config.environment)
        self.sec = SecurityGuard(config)
        self.payments = UnifiedPaymentService(config, db)
        self._update_lock = threading.RLock()

    def miniapp_link(self, startapp_param: str = "home") -> str:
        return f"https://t.me/{self.config.bot_username}/{self.config.miniapp_short_name}?startapp={startapp_param}"

    # -------------------------------------------------------------------------
    # Bot API 10.5 Startup Settings Sync (`setMySettings` + `getMe` check)
    # -------------------------------------------------------------------------
    def sync_bot_settings(self) -> None:
        if not self.caps.enabled("programmatic_settings"):
            return
        desired = {
            "has_inline_mode": False,  # Least privilege until inline widgets graduate to prod
            "inline_query_placeholder": "Search CityX districts or events...",
            "can_read_all_group_messages": False,  # Privacy mode ON
            "can_join_groups": True,
            "has_topics_enabled": self.caps.enabled("private_chat_topics"),
            "has_topic_sidebar": self.caps.enabled("private_chat_topics"),
            "callback_query_mode": "inline_or_message",
        }
        try:
            self.api.set_my_settings(desired)
            bot_info = self.api.get_me()
            logger.info(
                "Bot API 10.5 settings synced & verified via getMe (BotFullInfo): @%s | topic_sidebar=%s | privacy_disabled=%s",
                bot_info.get("username"),
                bot_info.get("has_topic_sidebar"),
                bot_info.get("can_read_all_group_messages"),
            )
        except TelegramAPIError as exc:
            logger.warning("setMySettings verification skipped/fallback (%s): %s", exc.error_code, exc.description)

    # -------------------------------------------------------------------------
    # Outbound Dispatcher with Deterministic Fallback (Widget -> Rich -> HTML)
    # -------------------------------------------------------------------------
    def dispatch_widget_or_fallback(
        self,
        *,
        chat_id: int,
        chat_type: str,
        user: Dict[str, Any],
        widget_id: str,
        chat_data: Dict[str, Any],
        fallback_caption: str,
        fallback_markup: Dict[str, Any],
        public_data: Optional[Dict[str, Any]] = None,
        entity_id: str = "",
        topic_key: Optional[str] = None,
    ) -> None:
        thread_id = self._get_topic_thread(chat_id, topic_key) if (chat_type == "private" and topic_key) else None
        use_widget = self.caps.can_send_widget_in_chat(chat_type) and not bool(user.get("classic_mode"))

        if use_widget:
            try:
                msg = self.api.send_widget(
                    chat_id=chat_id,
                    html=WIDGET_TEMPLATES[widget_id],
                    width=0,
                    height=0,
                    allow_queries=True,
                    chat_data=chat_data,
                    public_data=public_data,
                    caption=fallback_caption,
                    reply_markup=fallback_markup,
                    message_thread_id=thread_id,
                )
                self._register_widget_instance(
                    chat_id, msg["message_id"], widget_id, user["user_id"], entity_id, chat_data
                )
                return
            except TelegramAPIError as exc:
                logger.warning("sendWidget(%s) failed [%s]: %s — degrading to fallback", widget_id, exc.error_code, exc.description)

        # Deterministic Fallback: Standard HTML + Inline Keyboard
        self._safe_send_message(chat_id, fallback_caption, reply_markup=fallback_markup, message_thread_id=thread_id)

    def dispatch_rich_or_fallback(
        self,
        chat_id: int,
        rich_message: Dict[str, Any],
        fallback_html: str,
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
    ) -> None:
        if self.caps.enabled("rich_messages"):
            try:
                self.api.send_rich_message(
                    chat_id=chat_id,
                    rich_message=rich_message,
                    reply_markup=reply_markup,
                    message_thread_id=message_thread_id,
                )
                return
            except TelegramAPIError as exc:
                logger.warning("sendRichMessage failed [%s]: %s — falling back to HTML", exc.error_code, exc.description)
        self._safe_send_message(chat_id, fallback_html, reply_markup=reply_markup, message_thread_id=message_thread_id)

    def send_ephemeral_group_notice(
        self,
        *,
        chat_id: int,
        target_telegram_id: int,
        text: str,
        audit_action: str,
        callback_query_id: Optional[str] = None,
        reply_ephemeral_message_id: Optional[int] = None,
    ) -> None:
        """
        Bot API 10.2+ Ephemeral group notice.
        ALWAYS writes authoritative record to DB before sending ephemeral UI feedback.
        """
        with self.db._lock:
            self.db.conn.execute(
                "INSERT INTO moderation_logs (chat_id, target_telegram_id, action, reason, created_at) VALUES (?, ?, ?, ?, ?)",
                (chat_id, target_telegram_id, audit_action, text[:500], int(time.time())),
            )
            self.db.conn.commit()

        if not self.caps.enabled("ephemeral_group_messages"):
            return

        ephemeral_params: Dict[str, Any] = {"receiver_user_id": target_telegram_id}
        if callback_query_id:
            ephemeral_params["callback_query_id"] = callback_query_id
        reply_params = {"ephemeral_message_id": reply_ephemeral_message_id} if reply_ephemeral_message_id else None

        try:
            self.api.send_message(
                chat_id=chat_id,
                text=text,
                ephemeral_message_parameters=ephemeral_params,
                reply_parameters=reply_params,
            )
        except TelegramAPIError as exc:
            logger.warning("Ephemeral group notice failed [%s]: %s", exc.error_code, exc.description)

    def _safe_send_message(
        self,
        chat_id: int,
        text: str,
        reply_markup: Optional[Dict[str, Any]] = None,
        message_thread_id: Optional[int] = None,
    ) -> None:
        try:
            self.api.send_message(chat_id, text, reply_markup=reply_markup, message_thread_id=message_thread_id)
        except TelegramAPIError as exc:
            # If thread_id caused error on client without private topics, retry without thread_id
            if message_thread_id and exc.error_code == 400:
                self.api.send_message(chat_id, text, reply_markup=reply_markup)
            else:
                logger.error("sendMessage failed: %s", exc)

    def _get_topic_thread(self, telegram_user_id: int, topic_key: str) -> Optional[int]:
        row = self.db.conn.execute(
            "SELECT message_thread_id FROM user_topics WHERE telegram_user_id = ? AND topic_key = ?",
            (telegram_user_id, topic_key),
        ).fetchone()
        return int(row["message_thread_id"]) if row else None

    def _register_widget_instance(
        self, chat_id: int, message_id: int, widget_id: str, owner_user_id: str, entity_id: str, state: Dict[str, Any]
    ) -> None:
        with self.db._lock:
            self.db.conn.execute(
                """
                INSERT OR REPLACE INTO widget_instances
                (chat_id, message_id, widget_id, owner_user_id, entity_id, state_json, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (chat_id, message_id, widget_id, owner_user_id, entity_id, json.dumps(state), int(time.time())),
            )
            self.db.conn.commit()

    # -------------------------------------------------------------------------
    # State Builders & Senders for All 10 CityX Widgets
    # -------------------------------------------------------------------------
    def _today_utc5(self) -> str:
        tz_uz = datetime.timezone(datetime.timedelta(hours=5))
        return datetime.datetime.now(tz_uz).strftime("%Y-%m-%d")

    def _refresh_user(self, user_id: str) -> Dict[str, Any]:
        row = self.db.conn.execute("SELECT * FROM cityx_users WHERE user_id = ?", (user_id,)).fetchone()
        return dict(row)

    def send_welcome_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        daily_ready = user["last_daily_claim"] != self._today_utc5()
        chat_data = {
            "username": user["username"],
            "coins": user["coins"],
            "dailyReady": daily_ready,
            "district": user["district"],
            "miniAppUrl": self.miniapp_link("home"),
        }
        caption = (
            f"<b>CityX Digital City</b> — Welcome, @{user['username']}!\n"
            f"Balance: <b>{user['coins']:,} CX</b> | District: <b>{user['district']}</b>"
        )
        markup = {
            "inline_keyboard": [
                [{"text": "Enter 3D City", "web_app": {"url": f"{self.config.web_base_url}/app"}}],
                [
                    {"text": "Dashboard", "callback_data": self.sec.sign_callback("open", "dashboard")},
                    {"text": "Properties", "callback_data": self.sec.sign_callback("open", "property")},
                    {"text": "Garage", "callback_data": self.sec.sign_callback("open", "garage")},
                ],
                [
                    {"text": "Racing", "callback_data": self.sec.sign_callback("open", "racing")},
                    {"text": "Taxi", "callback_data": self.sec.sign_callback("open", "taxi")},
                    {"text": "Events", "callback_data": self.sec.sign_callback("open", "event")},
                ],
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_welcome",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            topic_key="home",
        )

    def send_daily_dashboard_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        user = self._refresh_user(user["user_id"])
        claimable = user["last_daily_claim"] != self._today_utc5()
        rank = self._get_district_rank(user["district"])
        chat_data = {
            "coins": user["coins"],
            "gems": user["gems"],
            "level": user["level"],
            "questDone": user["quest_done"],
            "questTotal": user["quest_total"],
            "streak": user["streak"],
            "rank": rank,
            "district": user["district"],
            "claimable": claimable,
            "msg": "Tap Claim to collect +150 CX & +2 Gems" if claimable else "Daily reward already claimed today.",
        }
        caption = f"<b>CityX Daily Dashboard</b> | LVL {user['level']} | {user['coins']:,} CX | {user['gems']} Gems"
        markup = {
            "inline_keyboard": [
                [{"text": "Claim Daily Reward", "callback_data": self.sec.sign_callback("daily", "claim")}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_daily_dashboard",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            topic_key="home",
        )

    def send_property_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        prop = self.db.conn.execute(
            "SELECT * FROM properties WHERE owner_user_id = ? LIMIT 1", (user["user_id"],)
        ).fetchone()
        if not prop:
            self._safe_send_message(chat_id, "You do not own a property yet. Visit the Mini App real estate market!")
            return
        # Strictly public fields only — never expose private owner metadata
        chat_data = {
            "id": prop["property_id"],
            "name": prop["name"],
            "district": prop["district"],
            "ownerHandle": f"@{user['username']}",
            "level": prop["building_level"],
            "valueCoins": prop["est_value_coins"],
            "upgradeStatus": prop["upgrade_status"],
            "canUpgrade": user["coins"] >= 500,
            "miniAppUrl": self.miniapp_link(f"property_{prop['property_id']}"),
        }
        caption = f"<b>{prop['name']}</b> ({prop['district']}) — Level {prop['building_level']} | Est. {prop['est_value_coins']:,} CX"
        markup = {
            "inline_keyboard": [
                [{"text": "Open Property in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/property/{prop['property_id']}"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_property",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            entity_id=prop["property_id"],
            topic_key="properties",
        )

    def send_garage_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any], idx: int = 0) -> None:
        rows = self.db.conn.execute(
            "SELECT * FROM vehicles WHERE owner_user_id = ? ORDER BY vehicle_id", (user["user_id"],)
        ).fetchall()
        if not rows:
            self._safe_send_message(chat_id, "Your garage is empty.")
            return
        idx = idx % len(rows)
        v = rows[idx]
        chat_data = {
            "vehId": v["vehicle_id"],
            "name": v["name"],
            "vClass": v["vehicle_class"],
            "rating": v["rating"],
            "upgPct": v["upgrade_pct"],
            "energyPct": v["energy_pct"],
            "idx": idx,
            "total": len(rows),
            "miniAppUrl": self.miniapp_link(f"garage_{v['vehicle_id']}"),
        }
        caption = f"<b>CityX Garage</b> — {v['name']} ({v['vehicle_class']}, {v['rating']} PR)"
        markup = {
            "inline_keyboard": [
                [{"text": "Open Garage in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/garage"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_garage",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            entity_id=v["vehicle_id"],
            topic_key="garage",
        )

    def send_racing_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any], sel: int = 0) -> None:
        track = RACING_TRACKS[sel % len(RACING_TRACKS)]
        chat_data = {
            "tracks": [t["name"] for t in RACING_TRACKS],
            "selected": sel % len(RACING_TRACKS),
            "record": track["record"],
            "top3": track["top3"],
            "status": f"Track: {track['name']} — Accept challenge, then launch 3D race in Mini App.",
            "miniAppRaceUrl": self.miniapp_link(f"race_{track['name'].lower()}"),
        }
        caption = f"<b>CityX Racing</b> — {track['name']} Challenge | Record: {track['record']}"
        markup = {
            "inline_keyboard": [
                [{"text": "Launch 3D Race in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/racing"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_racing",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            topic_key="games",
        )

    def send_district_battle_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        public_data, chat_data = self._build_district_battle_state(user)
        caption = f"<b>CityX District Battle</b> — Your District: {user['district']}"
        markup = {
            "inline_keyboard": [
                [{"text": "Open Virtual City Map", "web_app": {"url": f"{self.config.web_base_url}/app/city"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_district_battle",
            chat_data=chat_data,
            public_data=public_data,
            fallback_caption=caption,
            fallback_markup=markup,
            topic_key="city",
        )

    def send_event_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        public_data, chat_data = self._build_event_state(user, "evt_neon_grandprix")
        caption = f"<b>CityX Event</b> — {public_data['title']} ({public_data['location']})"
        markup = {
            "inline_keyboard": [
                [{"text": "Event Details in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/events/evt_neon_grandprix"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_event",
            chat_data=chat_data,
            public_data=public_data,
            fallback_caption=caption,
            fallback_markup=markup,
            entity_id="evt_neon_grandprix",
            topic_key="events",
        )

    def send_taxi_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        dest = TAXI_DESTINATIONS[1]
        chat_data = {
            "from": user["district"],
            "dests": [d["name"] for d in TAXI_DESTINATIONS],
            "selIdx": 1,
            "fareCoins": dest["fare"],
            "etaMin": dest["eta"],
            "booked": False,
            "miniAppRouteUrl": self.miniapp_link("taxi_route"),
        }
        caption = f"<b>CityX Taxi</b> — Pickup: {user['district']} | Est. Fare: {dest['fare']} CX"
        markup = {
            "inline_keyboard": [
                [{"text": "Open Full Route in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/city/taxi"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_taxi",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            topic_key="city",
        )

    def send_transaction_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        order = self.db.conn.execute(
            "SELECT * FROM payment_orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 1", (user["user_id"],)
        ).fetchone()
        if not order:
            self._safe_send_message(chat_id, "No recent transactions found.")
            return
        chat_data = self._build_transaction_state(dict(order))
        caption = f"<b>Transaction {order['order_id']}</b> — {order['amount_minor']} {order['currency']} ({order['status'].upper()})"
        markup = {
            "inline_keyboard": [
                [{"text": "Buy 150 Gems (Telegram Stars)", "callback_data": self.sec.sign_callback("pay", "stars_150")}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_transaction",
            chat_data=chat_data,
            fallback_caption=caption,
            fallback_markup=markup,
            entity_id=order["order_id"],
            topic_key="economy",
        )

    def send_election_widget(self, chat_id: int, chat_type: str, user: Dict[str, Any]) -> None:
        public_data, chat_data = self._build_election_state(user, "elec_2026_q4")
        caption = f"<b>{public_data['title']}</b> — Official CityX Citizen Vote"
        markup = {
            "inline_keyboard": [
                [{"text": "Election Info in Mini App", "web_app": {"url": f"{self.config.web_base_url}/app/events/elections"}}]
            ]
        }
        self.dispatch_widget_or_fallback(
            chat_id=chat_id,
            chat_type=chat_type,
            user=user,
            widget_id="cityx_election",
            chat_data=chat_data,
            public_data=public_data,
            fallback_caption=caption,
            fallback_markup=markup,
            entity_id="elec_2026_q4",
            topic_key="events",
        )

    # --- Shared State Helpers ---
    def _get_district_rank(self, district: str) -> int:
        rows = self.db.conn.execute("SELECT district FROM district_scores ORDER BY points DESC").fetchall()
        for idx, r in enumerate(rows, start=1):
            if r["district"] == district:
                return idx
        return 1

    def _build_district_battle_state(self, user: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        rows = self.db.conn.execute("SELECT district, points FROM district_scores ORDER BY points DESC").fetchall()
        part = self.db.conn.execute(
            "SELECT * FROM district_participants WHERE user_id = ?", (user["user_id"],)
        ).fetchone()
        public_data = {
            "season": "Season 4 — Tashkent Cup",
            "status": "LIVE",
            "districts": [{"name": r["district"], "pts": r["points"]} for r in rows],
        }
        chat_data = {
            "userDistrict": user["district"],
            "userPts": part["points"] if part else 0,
            "joined": bool(part),
        }
        return public_data, chat_data

    def _build_event_state(self, user: Dict[str, Any], event_id: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        ev = self.db.conn.execute("SELECT * FROM events WHERE event_id = ?", (event_id,)).fetchone()
        cnt = self.db.conn.execute("SELECT COUNT(*) AS c FROM event_rsvps WHERE event_id = ?", (event_id,)).fetchone()["c"]
        rsvp = self.db.conn.execute(
            "SELECT 1 FROM event_rsvps WHERE event_id = ? AND user_id = ?", (event_id, user["user_id"])
        ).fetchone()
        public_data = {
            "eventId": ev["event_id"],
            "title": ev["title"],
            "location": ev["location"],
            "startTs": ev["start_ts"],
            "attendees": cnt,
        }
        chat_data = {"joined": bool(rsvp), "miniAppUrl": self.miniapp_link(f"event_{event_id}")}
        return public_data, chat_data

    def _build_transaction_state(self, order: Dict[str, Any]) -> Dict[str, Any]:
        ts = datetime.datetime.fromtimestamp(order["updated_at"], datetime.timezone.utc).strftime("%H:%M:%S UTC")
        return {
            "ref": order["order_id"],
            "amount": order["amount_minor"],
            "currency": order["currency"],
            "provider": order["provider"].replace("_", " ").title(),
            "status": order["status"],
            "confirmed": order["status"] == "paid" and order["webhook_verified_at"] > 0,
            "receiptUrl": f"{self.config.web_base_url}/receipts/{order['order_id']}" if order["status"] == "paid" else "",
            "updatedAt": ts,
        }

    def _build_election_state(
        self, user: Dict[str, Any], election_id: str, pending_idx: Optional[int] = None
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        elec = self.db.conn.execute("SELECT * FROM elections WHERE election_id = ?", (election_id,)).fetchone()
        candidates = json.loads(elec["candidates_json"])
        vote = self.db.conn.execute(
            "SELECT candidate_id FROM election_votes WHERE election_id = ? AND user_id = ?",
            (election_id, user["user_id"]),
        ).fetchone()
        eligible = user["level"] >= 2
        if elec["published"]:
            total = self.db.conn.execute(
                "SELECT COUNT(*) AS c FROM election_votes WHERE election_id = ?", (election_id,)
            ).fetchone()["c"]
            for c in candidates:
                c_votes = self.db.conn.execute(
                    "SELECT COUNT(*) AS c FROM election_votes WHERE election_id = ? AND candidate_id = ?",
                    (election_id, c["id"]),
                ).fetchone()["c"]
                c["pct"] = round((c_votes / total) * 100) if total else 0
        public_data = {
            "electionId": election_id,
            "title": elec["title"],
            "published": bool(elec["published"]),
            "candidates": candidates,
        }
        chat_data: Dict[str, Any] = {
            "eligible": eligible,
            "votedId": vote["candidate_id"] if vote else "",
            "reason": (
                "Official vote recorded."
                if vote
                else ("Citizen Level 2+ required to vote." if not eligible else "Select a candidate and confirm.")
            ),
        }
        if pending_idx is not None:
            chat_data["pendingIdx"] = pending_idx
        return public_data, chat_data

    # -------------------------------------------------------------------------
    # UPDATE ROUTER (Messages, Widget Queries, Callbacks, Payments)
    # -------------------------------------------------------------------------
    def handle_update(self, update: Dict[str, Any]) -> None:
        # A single SQLite connection is shared across handlers; serialize update transactions.
        with self._update_lock:
            self._process_update(update)

    def _process_update(self, update: Dict[str, Any]) -> None:
        try:
            if "message" in update:
                self._handle_message(update["message"])
            elif "widget_query" in update:
                self._handle_widget_query(update["widget_query"], is_shared=False)
            elif "shared_widget_query" in update:
                self._handle_widget_query(update["shared_widget_query"], is_shared=True)
            elif "callback_query" in update:
                self._handle_callback_query(update["callback_query"])
            elif "pre_checkout_query" in update:
                self._handle_pre_checkout_query(update["pre_checkout_query"])
        except Exception as exc:
            logger.exception("Unhandled error while processing update %s: %s", update.get("update_id"), exc)

    def _handle_message(self, msg: Dict[str, Any]) -> None:
        tg_user = msg.get("from")
        chat = msg.get("chat", {})
        if not tg_user or not chat:
            return
        chat_id = int(chat["id"])
        chat_type = chat.get("type", "private")

        # Handle Telegram Stars successful_payment webhook inside message update
        if "successful_payment" in msg:
            self._handle_stars_successful_payment(chat_id, tg_user, msg["successful_payment"])
            return

        text = (msg.get("text") or "").strip()
        if not text.startswith("/"):
            return

        user, is_new = self.db.get_or_create_telegram_user(tg_user)
        parts = text.split(maxsplit=1)
        cmd = parts[0].split("@")[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if cmd == "/start":
            if arg.startswith("beta_"):
                logger.info("User %s entered via controlled beta invite code %s", user["user_id"], arg)
            elif arg.startswith("prop_"):
                self.send_property_widget(chat_id, chat_type, user)
                return
            elif arg.startswith("event_"):
                self.send_event_widget(chat_id, chat_type, user)
                return
            self.send_welcome_widget(chat_id, chat_type, user)
        elif cmd == "/dashboard":
            self.send_daily_dashboard_widget(chat_id, chat_type, user)
        elif cmd == "/property":
            self.send_property_widget(chat_id, chat_type, user)
        elif cmd == "/garage":
            self.send_garage_widget(chat_id, chat_type, user)
        elif cmd == "/racing":
            self.send_racing_widget(chat_id, chat_type, user)
        elif cmd == "/battle":
            self.send_district_battle_widget(chat_id, chat_type, user)
        elif cmd == "/event":
            self.send_event_widget(chat_id, chat_type, user)
        elif cmd == "/taxi":
            self.send_taxi_widget(chat_id, chat_type, user)
        elif cmd == "/tx":
            self.send_transaction_widget(chat_id, chat_type, user)
        elif cmd == "/election":
            self.send_election_widget(chat_id, chat_type, user)
        elif cmd == "/classic":
            new_mode = 0 if user["classic_mode"] else 1
            with self.db._lock:
                self.db.conn.execute("UPDATE cityx_users SET classic_mode = ? WHERE user_id = ?", (new_mode, user["user_id"]))
                self.db.conn.commit()
            mode_name = "Classic Fallback Mode (Inline Keyboards)" if new_mode else "Next-Gen HTML Widgets Mode"
            self._safe_send_message(chat_id, f"Switched to <b>{mode_name}</b>.")
        elif cmd == "/topics" and chat_type == "private":
            self._provision_private_topics(chat_id)
        elif cmd == "/stars":
            self._send_stars_gem_pack(chat_id, user)
        elif cmd == "/help":
            self._safe_send_message(
                chat_id,
                (
                    "<b>CityX Commands (Bot API 10.5+)</b>\n"
                    "/start — Welcome Widget\n"
                    "/dashboard — Daily Dashboard Widget\n"
                    "/property — Property Widget\n"
                    "/garage — Garage Widget\n"
                    "/racing — Racing Widget\n"
                    "/battle — District Battle Widget\n"
                    "/event — Live Event Widget\n"
                    "/taxi — Virtual Taxi Widget\n"
                    "/tx — Transaction Status Widget\n"
                    "/election — CityX Election Widget\n"
                    "/stars — Purchase Gems via Telegram Stars\n"
                    "/topics — Organize Private Chat Topics\n"
                    "/classic — Toggle Fallback Classic Mode"
                ),
            )

    def _provision_private_topics(self, chat_id: int) -> None:
        """Create the 9 logical CityX private chat topics where supported."""
        created = 0
        for key, title in PRIVATE_TOPICS:
            if self._get_topic_thread(chat_id, key):
                continue
            try:
                res = self.api.create_forum_topic(chat_id, title)
                with self.db._lock:
                    self.db.conn.execute(
                        "INSERT OR REPLACE INTO user_topics (telegram_user_id, topic_key, message_thread_id) VALUES (?, ?, ?)",
                        (chat_id, key, res["message_thread_id"]),
                    )
                    self.db.conn.commit()
                created += 1
            except TelegramAPIError as exc:
                logger.info("Private topic '%s' skipped (%s): %s", title, exc.error_code, exc.description)
                break
        if created:
            self._safe_send_message(chat_id, f"Organized <b>{created}</b> CityX topics in your sidebar.")
        else:
            self._safe_send_message(chat_id, "Private chat topics are already active or not supported on this client.")

    # -------------------------------------------------------------------------
    # HTML Widget Query Router (`widget_query` & `shared_widget_query`)
    # -------------------------------------------------------------------------
    def _handle_widget_query(self, query: Dict[str, Any], is_shared: bool) -> None:
        query_id = query["id"]
        tg_user = query["from"]
        data = str(query.get("data") or "")

        # 1. Payload length & idempotency checks
        if len(data.encode("utf-8")) > MAX_WIDGET_QUERY_BYTES:
            self.api.answer_widget_query(query_id, "Invalid request size.")
            return
        if not self.db.acquire_idempotency(f"wq:{query_id}", ttl_seconds=120):
            self.api.answer_widget_query(query_id, "Already processed.")
            return

        user, _ = self.db.get_or_create_telegram_user(tg_user)
        msg = query.get("message") or {}
        chat_id = msg.get("chat", {}).get("id", tg_user["id"])
        message_id = msg.get("message_id")
        inline_message_id = query.get("inline_message_id")

        # 2. Verify message ownership for private widgets
        inst = None
        if message_id:
            row = self.db.conn.execute(
                "SELECT * FROM widget_instances WHERE chat_id = ? AND message_id = ?", (chat_id, message_id)
            ).fetchone()
            inst = dict(row) if row else None
            if inst and not is_shared and inst["owner_user_id"] != user["user_id"]:
                self.api.answer_widget_query(query_id, "Access denied: not your widget.")
                return

        state = json.loads(inst["state_json"]) if inst else {}

        # 3. Dispatch validated widget actions
        if data == "w:daily" or data == "d:claim":
            self._action_claim_daily(query_id, user, chat_id, message_id, inline_message_id, is_welcome=(data == "w:daily"))
        elif data == "w:dash":
            self.api.answer_widget_query(query_id, "Opening Dashboard...")
            self.send_daily_dashboard_widget(chat_id, "private", user)
        elif data == "w:prop":
            self.api.answer_widget_query(query_id, "Opening Property...")
            self.send_property_widget(chat_id, "private", user)
        elif data == "w:gar":
            self.api.answer_widget_query(query_id, "Opening Garage...")
            self.send_garage_widget(chat_id, "private", user)
        elif data == "d:refresh":
            self._action_refresh_dashboard(query_id, user, chat_id, message_id, inline_message_id)
        elif data == "p:upg":
            self._action_upgrade_property(query_id, user, inst, chat_id, message_id, inline_message_id)
        elif data in ("g:prev", "g:next", "g:refuel"):
            self._action_garage(query_id, user, data, state, chat_id, message_id, inline_message_id)
        elif data.startswith("r:sel:") or data == "r:accept":
            self._action_racing(query_id, user, data, state, chat_id, message_id, inline_message_id)
        elif data in ("b:join", "b:sync"):
            self._action_district_battle(query_id, user, data, chat_id, message_id, inline_message_id)
        elif data in ("e:join", "e:leave"):
            self._action_event(query_id, user, data, chat_id, message_id, inline_message_id)
        elif data.startswith("t:d:") or data == "t:go":
            self._action_taxi(query_id, user, data, state, chat_id, message_id, inline_message_id)
        elif data == "tx:check":
            self._action_check_transaction(query_id, user, inst, chat_id, message_id, inline_message_id)
        elif data.startswith("el:pick:") or data == "el:cast":
            self._action_election(query_id, user, data, state, chat_id, message_id, inline_message_id)
        else:
            self.api.answer_widget_query(query_id, "Unsupported widget action.")

    def _push_widget_state(
        self,
        chat_id: int,
        message_id: Optional[int],
        inline_message_id: Optional[str],
        chat_data: Optional[Dict[str, Any]] = None,
        public_data: Optional[Dict[str, Any]] = None,
    ) -> None:
        if message_id and chat_data is not None:
            with self.db._lock:
                self.db.conn.execute(
                    "UPDATE widget_instances SET state_json = ?, updated_at = ? WHERE chat_id = ? AND message_id = ?",
                    (json.dumps(chat_data), int(time.time()), chat_id, message_id),
                )
                self.db.conn.commit()
        try:
            self.api.edit_message_widget_data(
                chat_id=chat_id,
                message_id=message_id,
                inline_message_id=inline_message_id,
                chat_data=chat_data,
                public_data=public_data,
            )
        except TelegramAPIError as exc:
            logger.warning("editMessageWidgetData failed: %s", exc)

    def _action_claim_daily(
        self, query_id: str, user: Dict[str, Any], chat_id: int, message_id: Optional[int], inline_id: Optional[str], is_welcome: bool
    ) -> None:
        today = self._today_utc5()
        idem = f"daily:{user['user_id']}:{today}"
        if not self.db.acquire_idempotency(idem, ttl_seconds=86400) or user["last_daily_claim"] == today:
            self.api.answer_widget_query(query_id, "Already claimed today!")
            return
        with self.db._lock:
            self.db.conn.execute(
                """
                UPDATE cityx_users
                SET coins = coins + 150, gems = gems + 2, streak = streak + 1, last_daily_claim = ?
                WHERE user_id = ?
                """,
                (today, user["user_id"]),
            )
            self.db.conn.commit()
        updated = self._refresh_user(user["user_id"])
        self.api.answer_widget_query(query_id, "Claimed +150 CX & +2 Gems!")
        if is_welcome:
            new_state = {
                "username": updated["username"],
                "coins": updated["coins"],
                "dailyReady": False,
                "district": updated["district"],
                "miniAppUrl": self.miniapp_link("home"),
            }
        else:
            new_state = {
                "coins": updated["coins"],
                "gems": updated["gems"],
                "level": updated["level"],
                "questDone": updated["quest_done"],
                "questTotal": updated["quest_total"],
                "streak": updated["streak"],
                "rank": self._get_district_rank(updated["district"]),
                "district": updated["district"],
                "claimable": False,
                "msg": "Claimed +150 CX & +2 Gems!",
            }
        self._push_widget_state(chat_id, message_id, inline_id, chat_data=new_state)

    def _action_refresh_dashboard(
        self, query_id: str, user: Dict[str, Any], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        updated = self._refresh_user(user["user_id"])
        claimable = updated["last_daily_claim"] != self._today_utc5()
        self.api.answer_widget_query(query_id, "Synced!")
        self._push_widget_state(
            chat_id,
            message_id,
            inline_id,
            chat_data={
                "coins": updated["coins"],
                "gems": updated["gems"],
                "level": updated["level"],
                "questDone": updated["quest_done"],
                "questTotal": updated["quest_total"],
                "streak": updated["streak"],
                "rank": self._get_district_rank(updated["district"]),
                "district": updated["district"],
                "claimable": claimable,
                "msg": "Synced with CityX backend.",
            },
        )

    def _action_upgrade_property(
        self, query_id: str, user: Dict[str, Any], inst: Optional[Dict[str, Any]], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        prop_id = inst["entity_id"] if inst else ""
        with self.db._lock:
            u = self._refresh_user(user["user_id"])
            prop = self.db.conn.execute(
                "SELECT * FROM properties WHERE property_id = ? AND owner_user_id = ?", (prop_id, u["user_id"])
            ).fetchone()
            if not prop:
                self.api.answer_widget_query(query_id, "Property not found.")
                return
            if u["coins"] < 500:
                self.api.answer_widget_query(query_id, "Need 500 CX to upgrade.")
                return
            new_lvl = prop["building_level"] + 1
            new_val = prop["est_value_coins"] + 2500
            changed = self.db.conn.execute(
                "UPDATE cityx_users SET coins = coins - 500 WHERE user_id = ? AND coins >= 500", (u["user_id"],)
            ).rowcount
            if not changed:
                self.db.conn.rollback()
                self.api.answer_widget_query(query_id, "Need 500 CX to upgrade.")
                return
            self.db.conn.execute(
                "UPDATE properties SET building_level = ?, est_value_coins = ?, upgrade_status = ? WHERE property_id = ? AND owner_user_id = ?",
                (new_lvl, new_val, f"Upgraded to Level {new_lvl}", prop_id, u["user_id"]),
            )
            self.db.conn.commit()
        u = self._refresh_user(user["user_id"])
        self.api.answer_widget_query(query_id, f"Upgraded to Level {new_lvl}!")
        self._push_widget_state(
            chat_id,
            message_id,
            inline_id,
            chat_data={
                "id": prop_id,
                "name": prop["name"],
                "district": prop["district"],
                "ownerHandle": f"@{u['username']}",
                "level": new_lvl,
                "valueCoins": new_val,
                "upgradeStatus": f"Upgraded to Level {new_lvl}",
                "canUpgrade": u["coins"] >= 500,
                "miniAppUrl": self.miniapp_link(f"property_{prop_id}"),
            },
        )

    def _action_garage(
        self, query_id: str, user: Dict[str, Any], cmd: str, state: Dict[str, Any], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        rows = self.db.conn.execute(
            "SELECT * FROM vehicles WHERE owner_user_id = ? ORDER BY vehicle_id", (user["user_id"],)
        ).fetchall()
        if not rows:
            self.api.answer_widget_query(query_id, "No vehicles.")
            return
        idx = int(state.get("idx", 0)) % len(rows)
        if cmd == "g:prev":
            idx = (idx - 1) % len(rows)
            self.api.answer_widget_query(query_id, "Previous vehicle")
        elif cmd == "g:next":
            idx = (idx + 1) % len(rows)
            self.api.answer_widget_query(query_id, "Next vehicle")
        elif cmd == "g:refuel":
            v_id = rows[idx]["vehicle_id"]
            with self.db._lock:
                self.db.conn.execute("UPDATE vehicles SET energy_pct = 100 WHERE vehicle_id = ?", (v_id,))
                self.db.conn.commit()
            rows = self.db.conn.execute(
                "SELECT * FROM vehicles WHERE owner_user_id = ? ORDER BY vehicle_id", (user["user_id"],)
            ).fetchall()
            self.api.answer_widget_query(query_id, "Vehicle energy recharged to 100%!")
        v = rows[idx]
        self._push_widget_state(
            chat_id,
            message_id,
            inline_id,
            chat_data={
                "vehId": v["vehicle_id"],
                "name": v["name"],
                "vClass": v["vehicle_class"],
                "rating": v["rating"],
                "upgPct": v["upgrade_pct"],
                "energyPct": v["energy_pct"],
                "idx": idx,
                "total": len(rows),
                "miniAppUrl": self.miniapp_link(f"garage_{v['vehicle_id']}"),
            },
        )

    def _action_racing(
        self, query_id: str, user: Dict[str, Any], cmd: str, state: Dict[str, Any], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        sel = int(state.get("selected", 0))
        if cmd.startswith("r:sel:"):
            sel = int(cmd.split(":")[-1]) % len(RACING_TRACKS)
            track = RACING_TRACKS[sel]
            status = f"Selected {track['name']}. Tap Accept Challenge or launch 3D Race."
            self.api.answer_widget_query(query_id, f"Track: {track['name']}")
        else:
            track = RACING_TRACKS[sel % len(RACING_TRACKS)]
            status = f"Challenge accepted on {track['name']}! Open Mini App to start 3D race."
            self.api.answer_widget_query(query_id, "Challenge accepted!")
        self._push_widget_state(
            chat_id,
            message_id,
            inline_id,
            chat_data={
                "tracks": [t["name"] for t in RACING_TRACKS],
                "selected": sel % len(RACING_TRACKS),
                "record": track["record"],
                "top3": track["top3"],
                "status": status,
                "miniAppRaceUrl": self.miniapp_link(f"race_{track['name'].lower()}"),
            },
        )

    def _action_district_battle(
        self, query_id: str, user: Dict[str, Any], cmd: str, chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        if cmd == "b:join":
            with self.db._lock:
                existing = self.db.conn.execute(
                    "SELECT 1 FROM district_participants WHERE user_id = ?", (user["user_id"],)
                ).fetchone()
                if not existing:
                    self.db.conn.execute(
                        "INSERT INTO district_participants (user_id, district, points) VALUES (?, ?, 100)",
                        (user["user_id"], user["district"]),
                    )
                    self.db.conn.execute(
                        "UPDATE district_scores SET points = points + 100 WHERE district = ?", (user["district"],)
                    )
                    self.db.conn.commit()
                    self.api.answer_widget_query(query_id, f"Joined {user['district']} (+100 pts)!")
                else:
                    self.api.answer_widget_query(query_id, "Already participating!")
        else:
            self.api.answer_widget_query(query_id, "Standings refreshed.")
        public_data, chat_data = self._build_district_battle_state(user)
        self._push_widget_state(chat_id, message_id, inline_id, chat_data=chat_data, public_data=public_data)

    def _action_event(
        self, query_id: str, user: Dict[str, Any], cmd: str, chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        event_id = "evt_neon_grandprix"
        with self.db._lock:
            if cmd == "e:join":
                self.db.conn.execute(
                    "INSERT OR IGNORE INTO event_rsvps (event_id, user_id, joined_at) VALUES (?, ?, ?)",
                    (event_id, user["user_id"], int(time.time())),
                )
                self.api.answer_widget_query(query_id, "Registered for event!")
            else:
                self.db.conn.execute(
                    "DELETE FROM event_rsvps WHERE event_id = ? AND user_id = ?", (event_id, user["user_id"])
                )
                self.api.answer_widget_query(query_id, "Registration cancelled.")
            self.db.conn.commit()
        public_data, chat_data = self._build_event_state(user, event_id)
        self._push_widget_state(chat_id, message_id, inline_id, chat_data=chat_data, public_data=public_data)

    def _action_taxi(
        self, query_id: str, user: Dict[str, Any], cmd: str, state: Dict[str, Any], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        sel = int(state.get("selIdx", 0)) % len(TAXI_DESTINATIONS)
        booked = bool(state.get("booked", False))
        if cmd.startswith("t:d:") and not booked:
            sel = int(cmd.split(":")[-1]) % len(TAXI_DESTINATIONS)
            dest = TAXI_DESTINATIONS[sel]
            self.api.answer_widget_query(query_id, f"Destination: {dest['name']} ({dest['fare']} CX)")
        elif cmd == "t:go" and not booked:
            dest = TAXI_DESTINATIONS[sel]
            u = self._refresh_user(user["user_id"])
            if u["coins"] < dest["fare"]:
                self.api.answer_widget_query(query_id, "Insufficient Coins for fare.")
                return
            with self.db._lock:
                self.db.conn.execute(
                    "UPDATE cityx_users SET coins = coins - ?, district = ? WHERE user_id = ?",
                    (dest["fare"], dest["name"], u["user_id"]),
                )
                self.db.conn.commit()
            booked = True
            self.api.answer_widget_query(query_id, f"Taxi confirmed to {dest['name']}!")
        else:
            dest = TAXI_DESTINATIONS[sel]
            self.api.answer_widget_query(query_id, "Ride already confirmed.")
        dest = TAXI_DESTINATIONS[sel]
        self._push_widget_state(
            chat_id,
            message_id,
            inline_id,
            chat_data={
                "from": state.get("from", user["district"]),
                "dests": [d["name"] for d in TAXI_DESTINATIONS],
                "selIdx": sel,
                "fareCoins": dest["fare"],
                "etaMin": dest["eta"],
                "booked": booked,
                "miniAppRouteUrl": self.miniapp_link(f"taxi_{dest['name'].lower().replace(' ', '_')}"),
            },
        )

    def _action_check_transaction(
        self, query_id: str, user: Dict[str, Any], inst: Optional[Dict[str, Any]], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        """
        STRICT SECURITY RULE: Never mark a transaction paid from a widget button press.
        This action ONLY reads authoritative order state from the backend database.
        """
        order_id = inst["entity_id"] if inst else ""
        row = self.db.conn.execute(
            "SELECT * FROM payment_orders WHERE order_id = ? AND user_id = ?", (order_id, user["user_id"])
        ).fetchone()
        if not row:
            self.api.answer_widget_query(query_id, "Order not found.")
            return
        self.api.answer_widget_query(query_id, f"Verified server status: {row['status'].upper()}")
        self._push_widget_state(chat_id, message_id, inline_id, chat_data=self._build_transaction_state(dict(row)))

    def _action_election(
        self, query_id: str, user: Dict[str, Any], cmd: str, state: Dict[str, Any], chat_id: int, message_id: Optional[int], inline_id: Optional[str]
    ) -> None:
        election_id = "elec_2026_q4"
        elec = self.db.conn.execute("SELECT * FROM elections WHERE election_id = ?", (election_id,)).fetchone()
        if not elec or not elec["published"]:
            self.api.answer_widget_query(query_id, "This election is not open.")
            return
        candidates = json.loads(elec["candidates_json"])

        if user["level"] < 2:
            self.api.answer_widget_query(query_id, "Ineligible: Level 2+ required.")
            return

        if cmd.startswith("el:pick:"):
            idx = int(cmd.split(":")[-1]) % len(candidates)
            self.api.answer_widget_query(query_id, f"Selected {candidates[idx]['name']}")
            pub, ch = self._build_election_state(user, election_id, pending_idx=idx)
            self._push_widget_state(chat_id, message_id, inline_id, chat_data=ch, public_data=pub)
            return

        if cmd == "el:cast":
            idx = state.get("pendingIdx")
            if idx is None or not (0 <= int(idx) < len(candidates)):
                self.api.answer_widget_query(query_id, "Select a candidate first.")
                return
            cand = candidates[int(idx)]
            try:
                with self.db._lock:
                    self.db.conn.execute(
                        "INSERT INTO election_votes (election_id, user_id, candidate_id, voted_at) VALUES (?, ?, ?, ?)",
                        (election_id, user["user_id"], cand["id"], int(time.time())),
                    )
                    self.db.conn.commit()
                self.api.answer_widget_query(query_id, f"Official vote recorded for {cand['name']}!")
            except sqlite3.IntegrityError:
                self.api.answer_widget_query(query_id, "You have already voted in this election.")
            pub, ch = self._build_election_state(user, election_id)
            self._push_widget_state(chat_id, message_id, inline_id, chat_data=ch, public_data=pub)

    # -------------------------------------------------------------------------
    # Dual-Mode Callback Query Processor (Bot API 10.5)
    # -------------------------------------------------------------------------
    def _handle_callback_query(self, cb: Dict[str, Any]) -> None:
        cb_id = cb["id"]
        if not self.db.acquire_idempotency(f"cb:{cb_id}", ttl_seconds=120):
            self.api.answer_callback_query(cb_id)
            return

        data = cb.get("data", "")
        ok, action, entity_id, err = self.sec.verify_callback(data)
        if not ok:
            self.api.answer_callback_query(cb_id, err, show_alert=True)
            return

        user, _ = self.db.get_or_create_telegram_user(cb["from"])
        # Support both message-backed and inline_message_id delivery modes
        msg = cb.get("message") or {}
        chat_id = msg.get("chat", {}).get("id", cb["from"]["id"])
        chat_type = msg.get("chat", {}).get("type", "private")

        if action == "open":
            self.api.answer_callback_query(cb_id, f"Opening {entity_id}...")
            dispatch = {
                "dashboard": self.send_daily_dashboard_widget,
                "property": self.send_property_widget,
                "garage": self.send_garage_widget,
                "racing": self.send_racing_widget,
                "taxi": self.send_taxi_widget,
                "event": self.send_event_widget,
            }
            if entity_id in dispatch:
                dispatch[entity_id](chat_id, chat_type, user)
        elif action == "daily" and entity_id == "claim":
            today = self._today_utc5()
            if user["last_daily_claim"] == today:
                self.api.answer_callback_query(cb_id, "Daily reward already claimed today!", show_alert=True)
                return
            with self.db._lock:
                self.db.conn.execute(
                    "UPDATE cityx_users SET coins = coins + 150, gems = gems + 2, streak = streak + 1, last_daily_claim = ? WHERE user_id = ?",
                    (today, user["user_id"]),
                )
                self.db.conn.commit()
            self.api.answer_callback_query(cb_id, "Claimed +150 CX & +2 Gems!", show_alert=True)
        elif action == "pay" and entity_id == "stars_150":
            self.api.answer_callback_query(cb_id, "Preparing Telegram Stars invoice...")
            self._send_stars_gem_pack(chat_id, user)
        else:
            self.api.answer_callback_query(cb_id, "Action processed.")

    # -------------------------------------------------------------------------
    # Telegram Stars Payments (`XTR`)
    # -------------------------------------------------------------------------
    def _send_stars_gem_pack(self, chat_id: int, user: Dict[str, Any]) -> None:
        if not self.caps.enabled("telegram_stars"):
            self._safe_send_message(chat_id, "Telegram Stars payments are temporarily unavailable.")
            return
        order_id = self.payments.create_order(
            user_id=user["user_id"],
            provider="telegram_stars",
            amount_minor=150,
            currency="XTR",
            idempotency_key=f"stars_pack:{user['user_id']}:{int(time.time() // 10)}",
        )
        try:
            self.api.send_stars_invoice(
                chat_id=chat_id,
                title="CityX 150 Gems Pack",
                description="Instant 150 CityX Gems for digital customization & city perks.",
                payload_id=order_id,
                stars_amount=150,
                message_thread_id=self._get_topic_thread(chat_id, "economy"),
            )
        except TelegramAPIError as exc:
            logger.error("Failed to send Stars invoice: %s", exc)

    def _handle_pre_checkout_query(self, pcq: Dict[str, Any]) -> None:
        order_id = pcq.get("invoice_payload", "")
        row = self.db.conn.execute("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,)).fetchone()
        tg_user_id = str((pcq.get("from") or {}).get("id", ""))
        identity = self.db.conn.execute(
            "SELECT 1 FROM user_identities WHERE user_id = ? AND provider = 'telegram' AND external_id = ?",
            (row["user_id"], tg_user_id),
        ).fetchone() if row else None
        if (not row or row["status"] != "pending" or row["provider"] != "telegram_stars"
                or row["currency"] != "XTR" or row["amount_minor"] != 150 or not identity
                or pcq.get("currency") != "XTR" or pcq.get("total_amount") != row["amount_minor"]):
            self.api.answer_pre_checkout_query(pcq["id"], ok=False, error_message="Order expired or invalid.")
            return
        self.api.answer_pre_checkout_query(pcq["id"], ok=True)

    def _handle_stars_successful_payment(self, chat_id: int, tg_user: Dict[str, Any], payment: Dict[str, Any]) -> None:
        order_id = payment.get("invoice_payload", "")
        charge_id = payment.get("telegram_payment_charge_id", "")
        tg_user_id = str((tg_user or {}).get("id", ""))
        candidate = self.db.conn.execute("SELECT * FROM payment_orders WHERE order_id = ?", (order_id,)).fetchone()
        identity = self.db.conn.execute(
            "SELECT 1 FROM user_identities WHERE user_id = ? AND provider = 'telegram' AND external_id = ?",
            (candidate["user_id"], tg_user_id),
        ).fetchone() if candidate else None
        if (not candidate or not identity or candidate["provider"] != "telegram_stars"
                or candidate["currency"] != payment.get("currency")
                or candidate["amount_minor"] != payment.get("total_amount") or candidate["amount_minor"] != 150):
            logger.warning("Rejected mismatched Telegram Stars payment for order %s", order_id)
            return
        order = self.payments.mark_order_paid_via_verified_webhook(
            order_id=order_id,
            provider="telegram_stars",
            provider_reference=charge_id,
            gems_reward=150,
        )
        if not order:
            return
        user = self._refresh_user(order["user_id"])
        rich, fallback_html, markup = RichMessageFactory.economy_notification(
            tx_type="Telegram Stars Purchase (+150 Gems)",
            amount_fmt=f"{order['amount_minor']} XTR",
            balance_after=f"{user['gems']} Gems | {user['coins']:,} CX",
            status="paid",
            order_id=order_id,
            web_url=self.config.web_base_url,
        )
        self.dispatch_rich_or_fallback(
            chat_id=chat_id,
            rich_message=rich,
            fallback_html=fallback_html,
            reply_markup=markup,
            message_thread_id=self._get_topic_thread(chat_id, "economy"),
        )


# =============================================================================
# 9. HTTP SERVER: WEBHOOKS, MINI APP initData AUTH & CLICK / PAYME / UZUM
# =============================================================================

def start_http_server(engine: CityXBotEngine) -> ThreadingHTTPServer:
    """
    Starts lightweight HTTP server exposing:
    - GET  /health
    - POST /telegram/webhook      (Bot API 10.5 webhook with secret-token check)
    - POST /api/miniapp/auth      (Mini App initData HMAC-SHA256 & 300s freshness)
    - POST /webhooks/click        (Uzbekistan Click.uz verified webhook)
    - POST /webhooks/payme        (Uzbekistan Payme.uz JSON-RPC verified webhook)
    - POST /webhooks/uzum         (Uzbekistan Uzum verified webhook)
    """

    update_queue: queue.Queue[Dict[str, Any]] = queue.Queue(maxsize=100)

    def update_worker() -> None:
        while True:
            update = update_queue.get()
            try:
                engine.handle_update(update)
            finally:
                update_queue.task_done()

    threading.Thread(target=update_worker, name="telegram-update-worker", daemon=True).start()

    class CityXHTTPHandler(BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            logger.debug("HTTP %s - " + fmt, self.address_string(), *args)

        def _send_json(self, status: int, data: Dict[str, Any]) -> None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path == "/health":
                self._send_json(
                    200,
                    {
                        "status": "ok",
                        "bot_api_baseline": CapabilityRegistry.BOT_API_BASELINE,
                        "environment": engine.config.environment,
                        "ton_wallet_enabled": False,
                    },
                )
            else:
                self._send_json(404, {"error": "Not found"})

        def do_POST(self) -> None:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self._send_json(400, {"error": "Invalid Content-Length"})
                return
            if length <= 0 or length > 1_000_000:
                self._send_json(413 if length > 1_000_000 else 400, {"error": "Invalid request size"})
                return
            raw_body = self.rfile.read(length)
            if len(raw_body) != length:
                self._send_json(400, {"error": "Incomplete request body"})
                return

            if self.path == "/telegram/webhook":
                secret = self.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
                if not engine.config.webhook_secret or not hmac.compare_digest(secret, engine.config.webhook_secret):
                    self._send_json(403, {"error": "Forbidden"})
                    return
                try:
                    update = json.loads(raw_body.decode("utf-8"))
                    if not isinstance(update, dict):
                        raise ValueError("Update must be a JSON object")
                    update_queue.put_nowait(update)
                    self._send_json(200, {"ok": True})
                except queue.Full:
                    self._send_json(503, {"error": "Update queue is full"})
                except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
                    self._send_json(400, {"error": "Invalid update payload"})
                return

            if self.path == "/api/miniapp/auth":
                try:
                    payload = json.loads(raw_body.decode("utf-8"))
                    tg_user = engine.sec.verify_miniapp_init_data(payload.get("initData", ""), max_age_seconds=300)
                    user, is_new = engine.db.get_or_create_telegram_user(tg_user)
                    self._send_json(
                        200,
                        {
                            "ok": True,
                            "isNew": is_new,
                            "user": {
                                "userId": user["user_id"],
                                "username": user["username"],
                                "district": user["district"],
                                "coins": user["coins"],
                                "gems": user["gems"],
                                "level": user["level"],
                            },
                        },
                    )
                except ValueError as exc:
                    self._send_json(401, {"ok": False, "error": str(exc)})
                return

            if self.path == "/webhooks/click":
                params = dict(urllib.parse.parse_qsl(raw_body.decode("utf-8")))
                if not engine.payments.verify_click_signature(params):
                    self._send_json(403, {"error": -1, "error_note": "SIGN CHECK FAILED"})
                    return
                order_id = params.get("merchant_trans_id", "")
                if params.get("action") == "1":  # Complete
                    engine.payments.mark_order_paid_via_verified_webhook(
                        order_id, "click", params.get("click_trans_id", ""), gems_reward=150
                    )
                self._send_json(200, {"error": 0, "error_note": "Success"})
                return

            if self.path == "/webhooks/payme":
                if not engine.payments.verify_payme_basic_auth(self.headers.get("Authorization", "")):
                    self._send_json(401, {"error": {"code": -32504, "message": "Unauthorized"}})
                    return
                rpc = json.loads(raw_body.decode("utf-8"))
                method = rpc.get("method")
                params = rpc.get("params", {})
                if method == "PerformTransaction":
                    order_id = params.get("account", {}).get("order_id", "")
                    engine.payments.mark_order_paid_via_verified_webhook(
                        order_id, "payme", str(params.get("id", "")), gems_reward=150
                    )
                self._send_json(200, {"result": {"state": 2, "perform_time": int(time.time() * 1000)}})
                return

            if self.path == "/webhooks/uzum":
                sig = self.headers.get("X-Uzum-Signature", "")
                if not engine.payments.verify_uzum_signature(raw_body, sig):
                    self._send_json(403, {"error": "Invalid Uzum signature"})
                    return
                data = json.loads(raw_body.decode("utf-8"))
                if data.get("status") == "CONFIRMED":
                    engine.payments.mark_order_paid_via_verified_webhook(
                        data.get("orderId", ""), "uzum", str(data.get("transId", "")), gems_reward=150
                    )
                self._send_json(200, {"status": "OK"})
                return

            self._send_json(404, {"error": "Endpoint not found"})

    server = ThreadingHTTPServer((engine.config.http_host, engine.config.http_port), CityXHTTPHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    logger.info("HTTP Server listening on http://%s:%d", engine.config.http_host, engine.config.http_port)
    return server


# =============================================================================
# 10. ENTRYPOINT (STARTUP VALIDATION + POLLING / WEBHOOK LOOP)
# =============================================================================

def main() -> None:
    # Step 1: Run mandatory QuickJS / zlib-9 Widget validation before booting
    widget_sizes = validate_all_widget_templates()
    logger.info("Validated %d CityX HTML Widgets (Bot API 10.4/10.5 limits):", len(widget_sizes))
    for wid, (raw_b, zlib_b) in widget_sizes.items():
        logger.info("  • %-22s | raw=%4d B / 32768 B | zlib9=%4d B / 4096 B", wid, raw_b, zlib_b)

    config = Config()
    if config.ton_wallet_enabled:
        raise RuntimeError("SECURITY VIOLATION: TON wallet must remain disabled.")

    if config.bot_token and not config.signing_secret:
        raise RuntimeError("Set CITYX_SIGNING_SECRET to a stable secret before starting the bot.")
    if config.webhook_url and not config.webhook_secret:
        raise RuntimeError("Set WEBHOOK_SECRET to a stable secret when using webhook mode.")

    db = CityXDatabase(config.db_path)
    api = TelegramBotClient(config)
    engine = CityXBotEngine(config, db, api)

    # Step 2: Start Mini App Auth & Payment Webhook HTTP Server
    http_server = start_http_server(engine)

    if not config.bot_token:
        logger.warning("BOT_TOKEN is empty. Widget validation & HTTP server started in dry-run mode.")
        logger.warning("Set BOT_TOKEN environment variable and restart to connect to Telegram.")
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            http_server.shutdown()
            return

    # Step 3: Sync Bot API 10.5 programmatic settings via setMySettings
    engine.sync_bot_settings()

    stop_event = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop_event.set())
    signal.signal(signal.SIGTERM, lambda *_: stop_event.set())

    # Step 4: Webhook Mode OR Long Polling Mode
    if config.webhook_url:
        api.call(
            "setWebhook",
            {
                "url": f"{config.webhook_url.rstrip('/')}/telegram/webhook",
                "secret_token": config.webhook_secret,
                "allowed_updates": [
                    "message",
                    "callback_query",
                    "widget_query",
                    "shared_widget_query",
                    "pre_checkout_query",
                ],
            },
        )
        logger.info("Running in WEBHOOK mode at %s/telegram/webhook", config.webhook_url.rstrip("/"))
        while not stop_event.is_set():
            stop_event.wait(1.0)
    else:
        try:
            api.call("deleteWebhook", {"drop_pending_updates": False})
        except TelegramAPIError:
            pass
        logger.info("Running in LONG POLLING mode for @%s ...", config.bot_username)
        offset = 0
        while not stop_event.is_set():
            try:
                updates = api.get_updates(offset=offset, timeout=20)
                for upd in updates:
                    offset = max(offset, int(upd["update_id"]) + 1)
                    engine.handle_update(upd)
            except TelegramAPIError as exc:
                retry = exc.parameters.get("retry_after", 3)
                logger.warning("Polling API error [%s]: %s (retrying in %ss)", exc.error_code, exc.description, retry)
                stop_event.wait(float(retry))
            except Exception as exc:
                logger.exception("Unexpected polling error: %s", exc)
                stop_event.wait(3.0)

    logger.info("Shutting down CityX Bot gracefully...")
    http_server.shutdown()


if __name__ == "__main__":
    main()