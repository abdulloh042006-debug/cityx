# CityX — Next-Generation 3D Social Metaverse Platform

## Architecture Overview
- `db/schema.sql`: Complete 20-table relational schema (`users`, `profiles`, `homes`, `districts`, `city_objects`, `ownerships`, `inventory`, `vehicles`, `transactions`, `referrals`, `likes`, `friendships`, `events`, `votes`, `fireworks`, `games`, `game_scores`, `notifications`, `reports`, `admin_audit_logs`).
- `backend/service.py`: Zero-dependency server business logic with PBKDF2-SHA256 + HMAC auth, atomic optimistic-lock landmark acquisition, referral anti-abuse, game score anti-cheat, 1-vote-per-election protection, firework moderation, RBAC admin audit logs, and Click/Payme/Uzum/Telegram Stars webhook signature verification.
- `frontend/cityx_metaverse_v2.html`: Standalone interactive 3D WebGL client with 8 city districts, mobile-first navigation, 3D driving mode, playable Snake & Bounce mini-games, customizable 1–50 floor homes, localStorage persistence, and 2D fallback map.
- `tests/test_cityx_backend.py`: Automated integration test suite.

## Run Tests
```bash
python3 tests/test_cityx_backend.py
```

## Production Notes
Real-money payment providers (Telegram Stars, Click, Payme, Uzum) require live merchant credentials in `.env`. Without credentials, webhook verification returns `501 Not Configured` and never fakes real-money transactions.
