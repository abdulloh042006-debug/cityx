"""
CityX 3D Social Metaverse — Core Backend Service (Zero-Dependency Python 3.11 + SQLite3)
Implements:
- PBKDF2-SHA256 password hashing & HMAC-SHA256 stateless auth tokens
- Atomic landmark ownership acquisition (prevents double-buy race conditions)
- Referral anti-abuse (blocks self-referral & duplicate claims)
- Anti-cheat game score validation (checks score vs. duration bounds)
- 1-vote-per-election-cycle enforcement
- Automatic firework text moderation
- Server-side RBAC admin endpoints + immutable admin_audit_logs
- Payment provider webhook verification architecture (Telegram Stars, Click, Payme, Uzum)
"""
import hashlib
import hmac
import json
import os
import re
import sqlite3
import time
import uuid
from datetime import datetime, timedelta, timezone

BANNED_WORDS = {"spam", "scam", "hack", "exploit", "abuse"}

class CityXService:
    def __init__(self, db_path=":memory:", secret_key=None):
        self.db_path = db_path
        self.secret_key = (secret_key or os.environ.get("CITYX_JWT_SECRET") or "dev-only-change-in-prod").encode()
        self.conn = sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self._init_schema()
        self._seed_defaults()

    def _init_schema(self):
        schema_file = os.path.join(os.path.dirname(__file__), "..", "db", "schema.sql")
        with open(schema_file, "r", encoding="utf-8") as f:
            self.conn.executescript(f.read())

    def _seed_defaults(self):
        districts = [
            ("residential", "Residential District", "RES", "Foydalanuvchilar uylari va mahallalar"),
            ("downtown", "Downtown", "DTW", "Nest One va biznes osmono'parlari"),
            ("business", "Business District", "BIZ", "Savdo markazlari va do'konlar"),
            ("entertainment", "Entertainment District", "ENT", "Humo Arena, Magic City va o'yin zali"),
            ("nature", "Nature District", "NAT", "Yangi O'zbekiston bog'i, ko'l va chinorlar"),
            ("university", "University District", "UNI", "TATU, O'zMU, Inha universitetlari"),
            ("vip", "VIP District", "VIP", "Islom Sivilizatsiyasi Markazi va noyob binolar"),
            ("transport", "Transport District", "TRN", "Halqa yo'li metrosi, vokzal va aeroport"),
        ]
        for d in districts:
            self.conn.execute(
                "INSERT OR IGNORE INTO districts (id, name, code, description) VALUES (?, ?, ?, ?)", d
            )
        objects = [
            ("obj_tvtower", "downtown", "Toshkent Teleminorasi (375m)", "landmark", "Markaziy ramz", 1, 5000, 5000, 0, 0, 0),
            ("obj_nestone", "downtown", "Nest One (266.5m)", "landmark", "51 qavatli osmono'par", 1, 4500, 4500, 38, 0, -38),
            ("obj_minor", "vip", "Minor Masjidi", "landmark", "Oq marmar va firuza gumbaz", 1, 3500, 3500, -38, 0, -38),
            ("obj_chorsu", "business", "Chorsu Bozori", "landmark", "86m firuza gumbaz", 1, 3000, 3000, -38, 0, 2),
            ("obj_humo", "entertainment", "Humo Arena", "stadium", "Humo qanoti muz saroyi", 1, 2500, 2500, 38, 0, 2),
            ("obj_cic", "vip", "Islom Sivilizatsiyasi Markazi", "landmark", "65m mozaika gumbaz (2026)", 1, 6000, 6000, 0, 0, -42),
        ]
        for o in objects:
            self.conn.execute(
                """INSERT OR IGNORE INTO city_objects
                   (id, district_id, name, category, description, is_unique, base_price_coins, current_price_coins, pos_x, pos_y, pos_z)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", o
            )
        games = [
            ("game_snake", "snake", "CityX Snake", 18.0),
            ("game_bounce", "bounce", "CityX Bounce", 22.0),
        ]
        for g in games:
            self.conn.execute("INSERT OR IGNORE INTO games (id, code, name, max_score_per_sec) VALUES (?, ?, ?, ?)", g)

    # --- AUTH & SECURITY ---
    def _hash_password(self, password: str) -> str:
        salt = os.urandom(16).hex()
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100_000).hex()
        return f"{salt}:{dk}"

    def _verify_password(self, password: str, stored: str) -> bool:
        salt, dk = stored.split(":")
        cand = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100_000).hex()
        return hmac.compare_digest(cand, dk)

    def create_token(self, user_id: str, role: str) -> str:
        payload = json.dumps({"sub": user_id, "role": role, "exp": int(time.time()) + 86400}, separators=(",", ":"))
        sig = hmac.new(self.secret_key, payload.encode(), hashlib.sha256).hexdigest()
        return f"{payload.encode().hex()}.{sig}"

    def verify_token(self, token: str):
        try:
            hex_p, sig = token.split(".")
            raw = bytes.fromhex(hex_p)
            expected = hmac.new(self.secret_key, raw, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(sig, expected):
                return None
            data = json.loads(raw.decode())
            if data["exp"] < time.time():
                return None
            return data
        except Exception:
            return None

    def register_user(self, username: str, password: str, instagram_handle: str = "", district_id: str = "residential", role: str = "user"):
        clean = re.sub(r"[^a-zA-Z0-9._]", "", username).lower()
        if len(clean) < 3 or len(clean) > 24:
            return 400, {"error": "Username must be 3-24 valid characters"}
        uid = f"usr_{uuid.uuid4().hex[:12]}"
        home_id = f"hom_{uuid.uuid4().hex[:10]}"
        plot_code = f"P-{uuid.uuid4().hex[:5].upper()}"
        try:
            self.conn.execute("BEGIN IMMEDIATE")
            self.conn.execute(
                "INSERT INTO users (id, username, password_hash, role) VALUES (?, ?, ?, ?)",
                (uid, clean, self._hash_password(password), role),
            )
            self.conn.execute(
                "INSERT INTO profiles (user_id, display_name, instagram_handle, district_id, coins, gems) VALUES (?, ?, ?, ?, 10000, 25)",
                (uid, clean, instagram_handle.lstrip("@"), district_id),
            )
            self.conn.execute(
                "INSERT INTO homes (id, user_id, district_id, plot_code, floors) VALUES (?, ?, ?, ?, 2)",
                (home_id, uid, district_id, plot_code),
            )
            self.conn.execute("COMMIT")
            return 201, {"user_id": uid, "username": clean, "home_id": home_id, "plot_code": plot_code, "token": self.create_token(uid, role)}
        except sqlite3.IntegrityError:
            self.conn.execute("ROLLBACK")
            return 409, {"error": "Username already taken"}

    # --- HOME PERSISTENCE ---
    def update_home(self, user_id: str, floors: int, has_pool: bool = False, has_helipad: bool = False):
        if not (1 <= floors <= 50):
            return 400, {"error": "Floors must be between 1 and 50"}
        self.conn.execute(
            "UPDATE homes SET floors = ?, has_pool = ?, has_helipad = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
            (floors, int(has_pool), int(has_helipad), user_id),
        )
        row = self.conn.execute("SELECT * FROM homes WHERE user_id = ?", (user_id,)).fetchone()
        return 200, dict(row)

    # --- ATOMIC OWNERSHIP LOCK (PREVENTS DOUBLE BUY) ---
    def acquire_object(self, user_id: str, object_id: str, expected_version: int):
        try:
            self.conn.execute("BEGIN IMMEDIATE")
            obj = self.conn.execute("SELECT * FROM city_objects WHERE id = ?", (object_id,)).fetchone()
            if not obj:
                self.conn.execute("ROLLBACK")
                return 404, {"error": "Object not found"}
            if obj["version"] != expected_version:
                self.conn.execute("ROLLBACK")
                return 409, {"error": "Object already acquired or price changed — refresh required"}

            prof = self.conn.execute("SELECT coins FROM profiles WHERE user_id = ?", (user_id,)).fetchone()
            price = obj["current_price_coins"]
            if prof["coins"] < price:
                self.conn.execute("ROLLBACK")
                return 402, {"error": "Insufficient coins"}

            existing = self.conn.execute("SELECT * FROM ownerships WHERE object_id = ?", (object_id,)).fetchone()
            if existing and existing["owner_user_id"] == user_id:
                self.conn.execute("ROLLBACK")
                return 409, {"error": "You already own this object"}

            # Deduct coins & credit previous owner 90% cashback if overbid
            self.conn.execute("UPDATE profiles SET coins = coins - ? WHERE user_id = ?", (price, user_id))
            if existing:
                cashback = int(existing["acquired_price_coins"] * 0.9)
                self.conn.execute("UPDATE profiles SET coins = coins + ? WHERE user_id = ?", (cashback, existing["owner_user_id"]))
                self.conn.execute("DELETE FROM ownerships WHERE object_id = ?", (object_id,))

            next_price = int(price * 1.2)
            self.conn.execute(
                "INSERT INTO ownerships (id, object_id, owner_user_id, acquired_price_coins) VALUES (?, ?, ?, ?)",
                (f"own_{uuid.uuid4().hex[:10]}", object_id, user_id, price),
            )
            self.conn.execute(
                "UPDATE city_objects SET current_price_coins = ?, version = version + 1 WHERE id = ?",
                (next_price, object_id),
            )
            self.conn.execute(
                "INSERT INTO transactions (id, user_id, provider, currency, amount, status) VALUES (?, ?, 'internal_coins', 'COINS', ?, 'paid')",
                (f"tx_{uuid.uuid4().hex[:10]}", user_id, price),
            )
            self.conn.execute("COMMIT")
            return 200, {"object_id": object_id, "owner_user_id": user_id, "paid_coins": price, "next_price_coins": next_price, "new_version": expected_version + 1}
        except Exception as exc:
            self.conn.execute("ROLLBACK")
            return 500, {"error": str(exc)}

    # --- REFERRAL ANTI-ABUSE ---
    def claim_referral(self, referrer_id: str, referred_id: str, ip_hash: str = ""):
        if referrer_id == referred_id:
            return 400, {"error": "Self-referral is prohibited"}
        try:
            self.conn.execute("BEGIN IMMEDIATE")
            self.conn.execute(
                "INSERT INTO referrals (id, referrer_user_id, referred_user_id, ip_hash, reward_granted) VALUES (?, ?, ?, ?, 1)",
                (f"ref_{uuid.uuid4().hex[:10]}", referrer_id, referred_id, ip_hash),
            )
            self.conn.execute("UPDATE profiles SET coins = coins + 500 WHERE user_id = ?", (referrer_id,))
            self.conn.execute("UPDATE homes SET floors = MIN(50, floors + 1) WHERE user_id = ?", (referrer_id,))
            self.conn.execute("COMMIT")
            return 200, {"status": "reward_granted", "bonus_coins": 500, "bonus_floors": 1}
        except sqlite3.IntegrityError:
            self.conn.execute("ROLLBACK")
            return 409, {"error": "Referral already claimed for this user"}

    # --- ANTI-CHEAT GAME SCORE VALIDATION ---
    def submit_game_score(self, user_id: str, game_code: str, score: int, duration_sec: float):
        game = self.conn.execute("SELECT * FROM games WHERE code = ?", (game_code,)).fetchone()
        if not game:
            return 404, {"error": "Unknown game"}
        if score < 0 or duration_sec < 2.0 or (score / duration_sec) > game["max_score_per_sec"]:
            return 400, {"error": "Score rejected by server anti-cheat validation"}
        coins = min(500, max(5, score // 2))
        self.conn.execute("BEGIN IMMEDIATE")
        self.conn.execute(
            "INSERT INTO game_scores (id, game_id, user_id, score, duration_sec, coins_awarded) VALUES (?, ?, ?, ?, ?, ?)",
            (f"gs_{uuid.uuid4().hex[:10]}", game["id"], user_id, score, duration_sec, coins),
        )
        self.conn.execute("UPDATE profiles SET coins = coins + ? WHERE user_id = ?", (coins, user_id))
        self.conn.execute("COMMIT")
        return 200, {"score": score, "coins_awarded": coins}

    # --- VIRTUAL PRESIDENT VOTING (1 VOTE PER ELECTION) ---
    def cast_vote(self, voter_id: str, candidate_id: str, cycle: str = "2026-11"):
        try:
            self.conn.execute(
                "INSERT INTO votes (id, election_cycle, voter_user_id, candidate_user_id) VALUES (?, ?, ?, ?)",
                (f"vot_{uuid.uuid4().hex[:10]}", cycle, voter_id, candidate_id),
            )
            return 200, {"status": "vote_recorded", "cycle": cycle}
        except sqlite3.IntegrityError:
            return 409, {"error": "User has already voted in this election cycle"}

    # --- FIREWORK MODERATION & QUEUE ---
    def launch_firework(self, user_id: str, message: str):
        clean = message.strip()
        if not clean or len(clean) > 24:
            return 400, {"error": "Message must be 1-24 characters"}
        lower_tokens = set(re.findall(r"[a-zA-Z0-9]+", clean.lower()))
        if lower_tokens & BANNED_WORDS:
            return 400, {"error": "Message blocked by moderation filter"}
        exp = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        fw_id = f"fw_{uuid.uuid4().hex[:10]}"
        self.conn.execute(
            "INSERT INTO fireworks (id, user_id, message, expires_at) VALUES (?, ?, ?, ?)",
            (fw_id, user_id, clean, exp),
        )
        return 201, {"firework_id": fw_id, "message": clean, "expires_at": exp}

    # --- SERVER-SIDE RBAC ADMIN + AUDIT LOG ---
    def admin_ban_user(self, actor_token: str, target_user_id: str, reason: str):
        claims = self.verify_token(actor_token)
        if not claims or claims.get("role") != "admin":
            return 403, {"error": "Admin role required (verified server-side)"}
        self.conn.execute("BEGIN IMMEDIATE")
        self.conn.execute("UPDATE users SET is_banned = 1 WHERE id = ?", (target_user_id,))
        self.conn.execute(
            "INSERT INTO admin_audit_logs (id, admin_user_id, action, target_entity, details_json) VALUES (?, ?, 'BAN_USER', ?, ?)",
            (f"aud_{uuid.uuid4().hex[:10]}", claims["sub"], target_user_id, json.dumps({"reason": reason})),
        )
        self.conn.execute("COMMIT")
        return 200, {"status": "banned", "target_user_id": target_user_id}

    # --- HONEST PAYMENT WEBHOOK ARCHITECTURE (NO FAKE REAL-MONEY SUCCESS) ---
    def verify_payment_webhook(self, provider: str, signature: str, payload: bytes):
        env_map = {
            "telegram_stars": "TELEGRAM_BOT_TOKEN",
            "click": "CLICK_SECRET_KEY",
            "payme": "PAYME_MERCHANT_KEY",
            "uzum": "UZUM_WEBHOOK_SECRET",
        }
        if provider not in env_map:
            return 400, {"error": "Unsupported payment provider"}
        secret = os.environ.get(env_map[provider])
        if not secret:
            return 501, {"error": f"{provider} merchant key not configured in environment — real payment not processed"}
        expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature):
            return 401, {"error": "Invalid webhook signature"}
        return 200, {"status": "signature_verified"}
