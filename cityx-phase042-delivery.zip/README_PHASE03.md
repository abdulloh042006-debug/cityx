# CityX — Phase 0.3 Unified Backend, Dual-Card Manual Payments & Telegram Adapter

This delivery package contains the reconciled Phase 0.3 backend implementation for CityX (`cityx.uz`, `@cityx_bot`), built directly on top of the verified 20-table schema from `cityx-complete-codebase.zip` (`db/schema.sql`) and preserving the existing gameplay logic (`backend/service.py`) and Telegram Bot API 10.5 HTML widgets (`CityX_Telegram_Bot_cleaned.py`).

## Package Structure

```text
cityx-phase03-delivery/
├── apps/
│   └── api/
│       ├── config.py                  # Render PORT, CORS, dual-card server-side env config, TON hard-lock
│       ├── main.py                    # Unified FastAPI ASGI entrypoint (REST + /telegram/webhook + /health)
│       ├── requirements.txt           # Python dependencies for FastAPI, Uvicorn, PostgreSQL (psycopg), pytest
│       ├── auth/tokens.py             # Telegram initData HMAC-SHA256, PBKDF2 passwords, strict HS256 JWT, signed callbacks
│       ├── db/store.py                # PostgreSQL (production pool) + SQLite (local/CI tests) transaction store
│       ├── domain/services.py         # Unified identity, economy ledger, dual-card manual payments, taxi, elections, gameplay
│       ├── payments/receipts.py       # Magic-byte & 5 MB binary receipt validator (PNG/JPEG/WebP/PDF) + private storage
│       └── telegram/
│           ├── widgets.py             # All 10 preserved HTML widgets + Bot API 10.5 QuickJS/zlib-9 validator
│           └── adapter.py             # Unified Telegram bot adapter preserving commands, 9 topics & fallback pipeline
├── backend/
│   └── service.py                     # Preserved CityXService compatibility bridge wired to unified store/domain
├── db/
│   ├── schema.sql                     # Original 20-table base schema preserved verbatim from cityx-complete-codebase.zip
│   ├── migrations/
│   │   ├── 001_phase03_up.sql         # Additive PostgreSQL migration + append-only triggers + least-privilege role grants
│   │   └── 001_phase03_down.sql       # Reversible rollback script (safe only before production payment traffic)
│   └── sqlite/
│       └── test_phase03_schema.sql    # SQLite-compatible reconciled schema + BEFORE UPDATE/DELETE append-only triggers
├── tests/
│   ├── test_cityx_backend.py          # Preserved legacy regression suite (8 tests)
│   ├── test_phase03_unittest.py       # Zero-dependency stdlib unittest suite (9 comprehensive test groups)
│   └── test_phase03_fastapi.py        # FastAPI TestClient HTTP suite (CORS, 401/403/404/409/422, multipart receipt upload)
├── .env.example                       # Placeholders only — NEVER commit real secrets or card numbers
├── .gitignore
├── IMPLEMENTATION_STATUS.md           # Honest separation of inspected, implemented, executed, unexecuted, and blocked items
└── README_PHASE03.md
```

## 1. Installation

### Minimal (Zero External Dependencies — Run Core & Legacy Unit Tests Immediately)
Python 3.10+ standard library is sufficient to execute `tests/test_cityx_backend.py` and `tests/test_phase03_unittest.py`.

### Full API & PostgreSQL Runtime (Local / Staging / Render)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r apps/api/requirements.txt
```

## 2. Configuration

Copy `.env.example` to `.env` (never commit `.env`):
```bash
cp .env.example .env
```

Set the required server-side secrets in `.env` (local) or Render Environment Variables (staging/production):
- `DATABASE_URL`: Managed PostgreSQL URI (mandatory when `CITYX_ENV=production`; SQLite is blocked in production).
- `CITYX_SIGNING_SECRET`: Random 32+ character secret persisted across restarts.
- `BOT_TOKEN`, `WEBHOOK_URL`, `WEBHOOK_SECRET`, `CITYX_ADMIN_TELEGRAM_IDS`.
- **Two separate manual bank-transfer cards (server-side only, never hardcoded in frontend or Git):**
  - **Card 1 (`uzum_visa`)**: `CITYX_PAYMENT_VISA_BANK_NAME="Uzum Bank"`, `CITYX_PAYMENT_VISA_NETWORK="Visa"`, `CITYX_PAYMENT_VISA_RECIPIENT="Abdullox Arslonov"`, `CITYX_PAYMENT_VISA_CARD_NUMBER="<16-digit Visa card>"`
  - **Card 2 (`uzcard`)**: `CITYX_PAYMENT_UZCARD_BANK_NAME=""` (keep empty until issuing bank is verified), `CITYX_PAYMENT_UZCARD_NETWORK="Uzcard"`, `CITYX_PAYMENT_UZCARD_RECIPIENT="Arslonov Abdulloh"`, `CITYX_PAYMENT_UZCARD_CARD_NUMBER="<16-digit Uzcard>"`

Automated payment gateways (Click, Payme, Uzum webhooks, Telegram Stars) and TON wallet remain disabled by policy.

## 3. Running Automated Tests

### Zero-dependency stdlib tests (runs anywhere with Python 3.10+)
```bash
python3 tests/test_cityx_backend.py
python3 tests/test_phase03_unittest.py
```

### Full FastAPI HTTP integration tests (after `pip install -r apps/api/requirements.txt`)
```bash
PYTHONPATH=. pytest -v tests/test_phase03_fastapi.py
```

## 4. PostgreSQL Migration & Rollback Instructions

### Pre-Migration Checklist
1. **Do NOT apply directly to production.** Test on a staging PostgreSQL database first.
2. Create separate database roles if supported by your host:
   - `cityx_migrator` (table owner, used only to run migrations)
   - `cityx_app` (runtime role used by FastAPI; `001_phase03_up.sql` revokes `UPDATE`, `DELETE`, `TRUNCATE` on `economy_ledger`, `payment_audit_logs`, and `admin_audit_logs`)
3. Take a full logical backup before running any migration:
```bash
pg_dump --format=custom --file="backup_pre_phase03_$(date +%Y%m%d_%H%M%S).dump" "$DATABASE_URL"
```

### Apply Forward Migration (UP)
```bash
# If starting from an empty database, apply the 20-table base schema first:
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/schema.sql

# Apply Phase 0.3 additive reconciliation + append-only triggers:
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/001_phase03_up.sql
```

### Rollback Procedure (DOWN)
- **If NO production manual payment orders or audit rows were created:**
```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/001_phase03_down.sql
```
- **If production traffic occurred after migration:** Do NOT drop audit or payment tables. Either roll back application code while keeping the append-only tables intact, or restore the full pre-migration snapshot:
```bash
pg_restore --clean --if-exists --dbname="$DATABASE_URL" backup_pre_phase03_<timestamp>.dump
```

## 5. Starting the Unified FastAPI Server

### Local Development
```bash
set -a && source .env && set +a
uvicorn apps.api.main:create_app --factory --host 0.0.0.0 --port "${PORT:-8080}"
```

### Render Web Service Start Command
```bash
uvicorn apps.api.main:create_app --factory --host 0.0.0.0 --port $PORT
```
Verify readiness via `GET /health` or `GET /__health`.
