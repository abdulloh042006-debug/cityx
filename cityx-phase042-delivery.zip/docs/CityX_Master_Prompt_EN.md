# MASTER PROMPT — CityX: Next-Generation 3D Social Metaverse Platform (Uzbekistan)

Act as a **Principal Product Architect, 3D WebGL / Three.js Engineer, Game Designer, Senior UX/UI Designer, Backend Engineer, and Security Engineer**.

Build **CityX** (`cityx.uz`, `@cityx.uz`, `@cityx_bot`) — a production-ready, mobile-first **3D Social Virtual City & Interactive Metaverse Platform** built for Uzbekistan (Tashkent & regional hubs), inspired by the social-game mechanics of `novaverse-uz.vercel.app` ("Yunusobod 3D City") and `@nova_metaverseBot`, but engineered as a completely original, dramatically higher-quality, scalable, high-FPS, anti-cheat-protected product.

**Core Rule:** Never copy the reference site's name, logo, code, or cluttered UI. Never use generic boxes for iconic buildings. Never fake real-money payment success or leave dead decorative buttons.

---

## 1. BRANDING & DYNAMIC BRAND IDENTITY (`CityX`)

- **Brand Name:** `CityX` (scalable across Tashkent and all Uzbekistan regions/districts).
- **True Dynamic Brand Identity System:** Do NOT use a static city illustration logo. Build a generative, modular geometric identity derived directly from the name `CityX`:
  - Core mark: a 4-axis isometric **X** crossroads made of modular 3D kinetic pillars whose extrusion height, rhythm, and accent harmonics dynamically adapt to:
    1. **Day / Core Mode** (Deep Midnight Navy `#071326`, Electric Cyan `#00E5FF`, Crisp White `#F8FAFC`)
    2. **Night Neon Mode** (Obsidian `#03040A`, Cyan Glow `#22D3EE`, Amber Window Pulses `#FBBF24`)
    3. **VIP Gold / Top-3 Mode** (Carbon `#070604`, Liquid Metallic Gold `#FACC15`)
    4. **Districts Battle Mode** (Emerald `#10B981`, Octagonal Uzbek *Girih* geometric halo)
    5. **Celebration / Fireworks Mode** (Magenta/Gold kinetic particles)
  - Support live SVG & 1024×1024 PNG logo export for Instagram (`@cityx.uz`), Telegram (`@cityx_bot`), website header lockup, and 1.5s animated loading splash.

---

## 2. MASTER-PLANNED 3D CITY ARCHITECTURE (8 DISTRICTS + FREE NAVIGATION)

Build a modular, instanced, mobile-optimized **Three.js / React Three Fiber** 3D city (target 60 FPS desktop, ≥30 FPS mobile) with **LOD**, **InstancedMesh** for trees/lamps/props, **Graphics Quality toggle (`HD / Lite`)**, and a **2D Fallback Schematic Map** for weak/non-WebGL devices.

### 2.1 Eight Distinct City Districts (Connected by Full Boulevard Grid & Pedestrian Walkways)
Never leave landmarks floating on empty grass. Connect every block with wide multi-lane asphalt avenues, white crosswalks (zebras), sidewalks (*yo‘laklar*), pedestrian alleys, streetlamps, and instanced *chinor* (plane) trees:
1. **Residential District (Mahalla):** Grid of clearly bordered residential plots — mix of occupied neighbor houses and **clickable empty green plots (`#A-02`, `#B-02`, etc.)** where users can tap to place or relocate their home.
2. **Downtown:** Central roundabout plaza with **Toshkent Teleminorasi (375m)** + **Nest One (266.5m, 51 floors)** + Hilton Tashkent City & Tashkent City Mall/Park.
3. **Business District:** **Chorsu Bozori** + commercial towers + **empty VIP Commercial Plots** reserved for future expansion.
4. **Entertainment District:** **Humo Arena** + **Magic City** + Game Center plaza.
5. **Nature District:** Artificial lake, wooden pedestrian bridge, *chinor* tree groves, and *choyxona/tapchan* rest areas.
6. **University District:** TATU, O‘zMU, Inha, and student campus blocks.
7. **VIP District:** **Minor Masjidi** + **Center of Islamic Civilization (2026)** + **Hazrati Imom** + regional icons (Samarqand *Boqiy Shahar*, Buxoro *Ark & Po-i-Kalyan*, Xiva *Kalta Minor*, *Amirsoy*).
8. **Transport District:** **Tashkent Elevated Circle Line (*Yerusti halqa yo‘li*)** 6m-high concrete viaduct + stations + 4-line Tashkent Metro network (`Chilonzor` Red, `O‘zbekiston` Blue, `Yunusobod` Green, `Halqa yo‘li` Gold/Amber — using official Tashkent station names: Texnopark, Yashnobod, Tuzel, Olmos, Rohat, Yangiobod, Qo‘yliq, Matonat, Qiyot, Tolariq, Xonobod, Quruvchilar, Turon, Qipchoq, Chinor, Minor, Bodomzor, Amir Temur, Chorsu, Paxtakor, etc.).

### 2.2 Free Camera & Mobile-First Touch Controls
- **1-finger drag (default `PAN` mode):** Smooth, bounded free panning across the entire city (never lock the camera to a single origin point).
- **2-finger touch:** Pinch-to-zoom + 2-finger rotation.
- **Double-tap / double-click any building:** Smooth camera fly-in & zoom.
- **Single tap on building:** Open contextual bottom-sheet info card without leaving the 3D scene.
- **Single tap on empty residential plot:** Move/build user's house onto that plot.
- **Compact right-side quick controls:** `+`, `−`, `↺`, `↻`, `PAN / 360°` toggle, and `Home` fly-back button.

### 2.3 Imperceptible Continuous Day–Night Lighting Cycle
- Never snap abruptly between day and night.
- Implement a smooth, continuous sinusoidal interpolation: **Day (`#7dd3fc`) → Golden Sunset (`#fb923c`) → Deep Night (`#050914`) → Dawn (`#818cf8`) → Day**.
- Smoothly interpolate sky color, fog density, sun arc altitude/color, hemisphere light, streetlamp bulbs, vehicle headlights, building window emissives, and dynamic LED facades (TV Tower, Humo Arena, Hilton). Provide `Auto / Day / Night` smooth-transition toggle.

---

## 3. HIGH-DETAIL PROCEDURAL 3D MODELS (VERIFIED UZBEKISTAN SPECS)

Model every landmark and vehicle with real architectural geometry and procedural Canvas textures (0 KB external textures where possible for instant mobile load):

1. **Toshkent Teleminorasi (375m):** Base rotunda with columns, 3 inclined conical strut legs (93m) on foundation plinths, open diagonal steel lattice cage around central shaft, 2-level glazed *Koinot* restaurant & observation deck with Uzbekistan flag-colored ceramic balcony rings and vertical window mullions, 220m upper pod, 4-stage tapered antenna spire, animated waving Uzbekistan flag, and dynamic color-shifting night LEDs.
2. **Minor Masjidi:** Stepped white marble stylobate, symmetrical 2-story hall with recessed pointed arches & colonnade, monumental blue-gold tiled *pishtaq* with carved wooden doors, 16-window drum, turquoise dome with golden finial, and 2 slender 38m white marble minarets with projecting *sherefe* balconies and turquoise caps.
3. **Nest One (266.5m, 51 floors):** *Gala* retail podium with entrance canopy, interlocking stepped curtain-wall glass shafts, vertical steel fins, signature copper-orange mechanical sky-lobby bands, crown frame, spire, and blinking red aviation beacon.
4. **Chorsu Bozori (UNESCO 2026):** Circular sunken concrete podium, colonnade drum, 86m hemisphere dome with **24 extruded 3D structural ribs** + geometric turquoise mosaic texture + golden skylight lantern, ringed by **7 smaller turquoise cupolas**.
5. **Tashkent Elevated Metro Station & 81-765.5 "Moskva" Train:** 6m concrete T-pier viaduct with crossbeams (*rigels*), concrete sleepers, twin 1520mm steel rails + yellow-shielded third rail, marble platform with yellow tactile strip, curved truss-arch solar-reflective glass/metal canopy, overhead LED strips, `TEXNOPARK` digital sign, illuminated `M` emblem. **4-car 78.52m train** with extruded aerodynamic sloped black front mask, 5-element curved LED headlights, white body, cyan roof, Uzbekistan-flag side stripes, full-width gangway bellows (*garmoshka*), and door status LEDs (white moving, green open, flashing red closing).
6. **Humo Arena:** 3 overlapping sculpted folded bird-wing aluminium roof shells, radiating feather entrance ramps, glass foyer, and animated panoramic RGB media-facade ribbon.
7. **Center of Islamic Civilization (2026):** Symmetrical 3-story cream-stone megaproject with 4 grand cardinal *pishtaqs* and a central 65m blue-turquoise-gold mosaic dome.
8. **Authentic Tashkent Vehicles (Exact Proportions & Livery):**
   - **Yutong ZK6126BEVG Electric Bus** (`12.17 × 2.55 × 3.30m`): **Steel-grey/metallic silver** body (NOT solid green — only CNG Yutong buses are green), black upper window band, green accent stripe, flush roof fairing, amber LED route matrix (`51 · YUNUSOBOD`).
   - **Official Tashkent Taxi (PKM-139):** **Ivory / off-white** (`#f5f2e6`, yellow is regional), black checkerboard + `T` on front doors, glowing **orange `TAXI` roof lantern**.
   - **Mercedes-Benz G63 AMG ("Gelik")** (`4.87 × 1.93 × 1.97m`): Sculpted hood, flared wheel arches, exposed hinges, 12-slat Panamericana chrome grille, circular LED halo headlights, hood turn-signal pods, twin side-exit exhausts, 5-spoke AMG alloys with red calipers, rear spare tire with chrome ring.
   - **Chevrolet Malibu XL** (`4.93 × 1.85 × 1.48m`), **Chevrolet Cobalt** (`4.48 × 1.74 × 1.51m`), **Chevrolet Damas** (`3.49 × 1.40 × 1.92m` tall ultra-narrow microvan).

---

## 4. YHQ TRAFFIC AI, 3D DRIVING MODE & TAXI

- **Zero-Collision Traffic AI (Uzbekistan YHQ Rules):**
  - 4-lane main boulevards (2 lanes each way) with **3-color working traffic lights (Svetofor)** and stop lines.
  - Every AI vehicle calculates exact bumper-to-bumper distance (never clips through another vehicle), illuminates bright red **brake lights** when slowing or stopping on red/yellow, activates blinking **turn signals** to politely overtake slower vehicles via the inner passing lane when clear, and returns to the right lane after passing.
- **Interactive 3D Driving Mode (`Garage → Drive`):**
  - Users select an owned vehicle (`Cobalt`, `Malibu XL`, `Gelik G63`, `Hypercar`) and drive freely through the 3D city.
  - Controls: Desktop `WASD` / Arrow keys + `Space` (Nitro) AND mobile on-screen steering/gas/brake/nitro pedals, real-time km/h speedometer, nitro gauge, and smooth third-person chase camera.
- **Virtual Taxi:** Instant fast-travel to any of the 8 districts or landmarks.

---

## 5. CUSTOMIZABLE 1–50 FLOOR HOMES & VISUAL EDITOR

- **Architectural Evolution (Not Box Scaling):**
  - **1–3 floors:** Modern Uzbek Courtyard Villa (*Hovli*) with pitched roof, porch, and **ornate carved wooden *mahalla darvoza*** gate.
  - **4–14 floors:** Premium stepped Penthouse with glass balconies.
  - **15–34 floors:** Tashkent City glass skyscraper with glowing trim.
  - **35–50 floors:** VIP Black & Gold luxury tower with exterior gold columns, red carpet entrance canopy, and rooftop **illuminated `H` helipad**.
- **Toggleable Upgrades:** Rippling LED-lit swimming pool, carved *darvoza* & perimeter fence, garage with displayed car, spinning-rotor helicopter (yard <10 floors, rooftop ≥10 floors), animated yard pet (dog/cat), and customizable facade colors.
- **Floating 3D Owner Nameplate:** Shows `@username (floors)` (upgrading to gold crown badge at VIP tier).

---

## 6. SOCIAL, MINI-GAMES, EVENTS, ECONOMY & VIRAL SHARING

- **Balanced Virtual Economy (`Coins` & `Gems`, Non-Pay-to-Win):**
  - Earn **Coins** via daily quests, playable mini-games, referrals, likes, and events.
  - **Unique Landmark Ownership + Overbid (+20%) Auction:** Any unique landmark has 1 owner (displaying their public Instagram link). Others can acquire it for +20% (previous owner receives 90% cashback) — ensuring the economy never stalls.
  - **Unlimited Decorative Items & 3D Sky Fireworks:** Users launch 1-day custom sky messages (max 24 chars, automatic profanity/spam moderation) triggering real 3D particle bursts in the sky.
  - **Districts Battle (`Tumanlar Jangi`):** Every player's floors and acquisitions add points to their chosen district/city leaderboard.
  - **Virtual City President Election:** 1 server-verified vote per user per election cycle.
- **Playable Game Center (`Games`):**
  - **Snake** (increasing speed, golden bonus food, touch D-pad + keyboard, awards Coins).
  - **Bounce** (physics jump-over-obstacles runner, awards Coins).
  - Extensible architecture for Racing, Parkour, and Daily Challenges.
- **Branded Screenshot & Share Sheet (`Stories`):**
  - `preserveDrawingBuffer: true` on WebGLRenderer; clicking **Stories** (or `PrintScreen`) composites the live 3D frame onto a clean **CityX** branded card and opens a Share Sheet modal (**Web Share API** for Instagram/Telegram, **PNG Download**, **Copy Image**).

---

## 7. MINIMALIST PREMIUM GAMING UI/UX

- Clean SVG icons (no emoji clutter), `Space Grotesk` + `Inter` typography, refined glassmorphism, crisp contrast, zero overlapping controls on narrow mobile screens.
- **7 Core Navigation Sections:** `City`, `My Home`, `Explore`, `Garage`, `Games`, `Rankings`, `Profile`.
- **Onboarding:** Branded animated loading screen → Username + District picker (or Guest viewer mode; **NEVER ask for or store Instagram passwords**) → Immediate entry into the live 3D city.

---

## 8. FULL-STACK BACKEND, 20-TABLE DATABASE, SECURITY & PAYMENTS

- **Frontend Stack:** Next.js, React, TypeScript, Tailwind CSS, Three.js / React Three Fiber, Zustand, Zod.
- **Backend & DB:** PostgreSQL / Supabase (or SQLite for local dev/tests) with all **20 relational tables**:
  `users`, `profiles`, `homes`, `districts`, `city_objects`, `ownerships`, `inventory`, `vehicles`, `transactions`, `referrals`, `likes`, `friendships`, `events`, `votes`, `fireworks`, `games`, `game_scores`, `notifications`, `reports`, `admin_audit_logs`.
- **Mandatory Server-Side Security:**
  - PBKDF2/Argon2 password hashing, signed JWT/HMAC auth, Telegram/Google OAuth.
  - **Atomic Optimistic-Lock Ownership (`BEGIN IMMEDIATE` + `version` check):** Guarantees two users can never simultaneously acquire the same landmark (`409 Conflict` on stale version).
  - **Referral Anti-Abuse:** Blocks self-referrals (`400`) and duplicate claims (`409`), tracks IP hashes.
  - **Game Score Anti-Cheat:** Validates `score / duration_sec <= max_score_per_sec` server-side before awarding Coins.
  - **RBAC Admin Dashboard:** Server-verified `admin` role required (`403 Forbidden` for regular users); every ban/edit/price change writes an immutable row to `admin_audit_logs`. No admin keys in frontend code.
- **Uzbekistan Payment Providers (`Telegram Stars`, `Click`, `Payme`, `Uzum`):**
  - Server-side HMAC/signature webhook verification only. Track states: `pending`, `paid`, `failed`, `cancelled`, `refunded`.
  - If live merchant keys are absent from `.env`, return `501 Not Configured` — never simulate or fake real-money payment confirmation.

---

## 9. EXECUTION PHASES & VERIFICATION BAR

Execute sequentially, testing and verifying every phase before proceeding:
- **Phase 0:** Architecture, Dynamic Brand Identity, 20-table DB schema & migrations.
- **Phase 1:** Core 3D City (8 districts, road grid, walkways, free camera, smooth day-night, HD/Lite + 2D fallback).
- **Phase 2:** Auth, Profiles, 1–50 Floor Home Editor, Empty Plot Placement, Atomic Landmark Ownership.
- **Phase 3:** Social (Likes, Friends, Referrals, Stories Share), Balanced Coins/Gems Economy, Rankings.
- **Phase 4:** Garage, YHQ Traffic AI, 3D Driving Mode, Taxi, Playable Snake & Bounce with server anti-cheat.
- **Phase 5:** 3D Fireworks (with moderation), President Voting, Payment Webhook Architecture, RBAC Admin Dashboard.
- **Phase 6:** Automated integration tests (home persistence, atomic double-buy prevention, referral anti-abuse, game anti-cheat, 1-vote enforcement, firework moderation, RBAC + audit logs, payment `501` check), mobile QA, and Vercel + PostgreSQL deployment config.
