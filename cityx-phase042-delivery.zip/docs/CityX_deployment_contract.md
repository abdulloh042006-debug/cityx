# CityX deployment contract

The managed project has server and database capabilities enabled, so its publish contract now uses a container rather than an unconfigured static-only build.

- `Dockerfile` installs from the committed pnpm lockfile, builds the Vite app, and starts the production static server.
- `server.cjs` serves the compiled `dist/` output, provides SPA fallback to `index.html`, honors `PORT`, and exposes unauthenticated `GET /__health` for deployment readiness.
- This container publishes the current CityX frontend only. The imported Python backend remains a tested foundation and is not falsely claimed as a production API.
- Durable user state, authentication, ownership settlement, payments, and server-backed games still require the later managed API/database integration phase.
