# CityX — O‘zbekiston 3D Ijtimoiy Virtual Shahri (Phase 0.3.1 + Phase 0.4)

CityX (`cityx.uz`, `@cityx_bot`) — yagona Python FastAPI backend, PostgreSQL bazasi, Telegram Bot/Mini App integratsiyasi, React + TypeScript + Vite + Tailwind CSS frontend hamda Three.js bazaviy 3D sahnasidan iborat integratsiyalashgan loyiha.

## 1. Loyiha tuzilmasi

```text
cityx-phase04-delivery/
├── apps/
│   ├── api/                        # Yagona FastAPI backend + Telegram Bot adapter
│   │   ├── main.py                 # REST API, RBAC admin, /telegram/webhook, /health, /__health
│   │   ├── config.py               # Render PORT, CORS, server-only Visa/Uzcard config, TON hard-lock
│   │   ├── auth/tokens.py          # Telegram initData HMAC, PBKDF2, strict HS256 JWT, signed callbacks
│   │   ├── db/store.py             # PostgreSQL (prod pool) + SQLite (local/CI test) transaction store
│   │   ├── domain/services.py      # Yagona iqtisodiyot, dual-card manual payments, social, places, admin
│   │   ├── payments/receipts.py    # Magic-byte (PNG/JPEG/WebP/PDF, <=5MB) binary receipt validator
│   │   ├── telegram/               # 10 ta HTML widget + QuickJS validator + 9 private topic adapter
│   │   └── requirements.txt
│   └── web/                        # React + TypeScript + Vite + Tailwind + Three.js Frontend
│       ├── package.json
│       ├── tsconfig.json
│       ├── vite.config.ts
│       ├── server.cjs              # Hardened static container server (CSP, /__health, SPA fallback)
│       └── src/
│           ├── api/client.ts       # Real backend API client (zero fake/mocked responses)
│           ├── auth/AuthContext.tsx# JWT session + Telegram Mini App auto-auth
│           ├── i18n/               # O‘zbek (lotin) asosiy + Ruscha + Inglizcha
│           ├── three/              # CitySceneEngine.ts (Three.js foundation + entity sync hooks)
│           ├── components/         # Layout (responsive + mobile menu), City3DViewport, UI
│           ├── pages/              # Barcha 14 talab qilingan bo‘limlar
│           └── __tests__/          # Vitest route & API integration suite
├── backend/service.py              # Saqlab qolingan CityXService moslashuv ko‘prigi (zero legacy webhooks)
├── db/
│   ├── schema.sql                  # Asl 20 jadvalli bazaviy sxema
│   ├── migrations/
│   │   ├── 001_phase03_up.sql      # Phase 0.3 additive PostgreSQL migration + append-only triggers
│   │   ├── 001_phase03_down.sql
│   │   ├── 002_phase031_phase04_up.sql   # Phase 0.3.1/0.4 additive migration (bio, language, recovery, places)
│   │   └── 002_phase031_phase04_down.sql
│   └── sqlite/test_phase04_schema.sql
├── tests/                          # Legacy regression, Phase 0.3 security/concurrency, Phase 0.4 backend & FastAPI
├── prototypes/                     # Asl 7 ta HTML prototip (read-only arxiv)
├── legacy/                         # Asl bot va backend fayllari (read-only arxiv)
├── Dockerfile                      # Frontend production container (Node 20)
├── Dockerfile.api                  # Backend production container (Python 3.11)
├── vercel.json                     # Vercel SPA + security headers config
├── render.yaml                     # Render API Blueprint
├── .env.example                    # Faqat placeholderlar (haqiqiy karta/kalitlar yo‘q)
├── IMPLEMENTATION_STATUS.md
└── TEST_REPORT.md
```

## 2. Xavfsizlik va Qo‘lda To‘lov Siyosati

- **O‘chirilgan tizimlar:** Click, Payme, Uzum avtomatik to‘lovlari, Telegram Stars va TON hamyon to‘liq olib tashlangan; hech qanday chaqiriladigan eski payment webhook qoldirilmagan.
- **Ikki alohida qo‘lda bank kartasi (UZS):**
  - `uzum_visa`: Uzum Bank · Visa · **Abdullox Arslonov**
  - `uzcard`: Uzcard · **Arslonov Abdulloh** (bank nomi tasdiqlanmaguncha bo‘sh qoladi)
- **Karta raqami maxfiyligi:** To‘liq 16 xonali karta raqamlari faqat server muhit o‘zgaruvchilarida (`CITYX_PAYMENT_VISA_CARD_NUMBER`, `CITYX_PAYMENT_UZCARD_CARD_NUMBER`) saqlanadi; frontend, Git, loglar va API javoblarida **hech qachon** to‘liq karta raqami qaytarilmaydi (faqat `**** **** **** XXXX`).
- **Administrator tasdig‘i:** Mablag‘ faqat `role = 'admin'` tasdiqlagandan so‘ng bitta DB tranzaksiyasida bir marta qo‘shiladi; o‘z buyurtmasini tasdiqlash va takroriy qo‘shish bloklangan.

## 3. Lokal ishga tushirish

### Backend (Python 3.10+)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r apps/api/requirements.txt
cp .env.example .env
# .env ichida CITYX_SIGNING_SECRET, BOT_TOKEN va karta placeholderlarini sozlang
set -a && source .env && set +a
uvicorn apps.api.main:create_app --factory --host 0.0.0.0 --port "${PORT:-8080}"
```

### Frontend (Node.js 20+)
```bash
cd apps/web
npm install
export VITE_API_BASE_URL=http://localhost:8080
npm run typecheck
npm run test
npm run build
npm run dev
```

## 4. PostgreSQL Migratsiya (Staging / Production)

Production bazaga qo‘llashdan oldin albatta `pg_dump` oling va staging muhitda tekshiring:
```bash
pg_dump --format=custom --file="backup_pre_phase04_$(date +%Y%m%d_%H%M%S).dump" "$DATABASE_URL"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/schema.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/001_phase03_up.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/002_phase031_phase04_up.sql
```
Rollback:
```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/002_phase031_phase04_down.sql
```
