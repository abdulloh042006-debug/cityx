# CityX — Phase 0.3.1 + Phase 0.4 Implementation Status

## 1. Baseline Inspection & Regression Preservation (COMPLETED)
- Inspected `cityx-phase03-delivery.zip` (29 files) and `cityx-complete-codebase.zip` (15 files), including `db/schema.sql`, `backend/service.py`, `CityX_Telegram_Bot_cleaned.py`, and all 7 HTML prototypes.
- Preserved all existing working CityX gameplay mechanics (homes 1–50 floors, atomic landmark overbid, referrals, game anti-cheat, elections, fireworks, RBAC bans), all 10 Telegram HTML widgets + QuickJS/zlib-9 validator, and archived all 7 HTML prototypes under `prototypes/`.

## 2. Phase 0.3.1 Backend & Security Hardening (IMPLEMENTED & UNIT-TESTED)
- **Zero callable legacy payment handlers:** Permanently removed `verify_payment_webhook` from `backend/service.py`, removed `/stars` and `action == "pay"` branches from `apps/api/telegram/adapter.py`, and kept zero Click/Payme/Uzum/Stars/TON webhook routes in `apps/api/main.py`.
- **Zero full card number exposure:** Removed raw `card_number` from `_build_snapshot_transfer_instructions` and every API response; responses expose only `card_masked` (`**** **** **** XXXX`), `card_last4`, `recipient_name`, `network`, and verified `bank_name` (`"Uzum Bank"` for Visa; `null` for Uzcard).
- **Dual-card isolation & snapshot idempotency:** Verified independent `uzum_visa` (`Abdullox Arslonov`) and `uzcard` (`Arslonov Abdulloh`) flows; retries preserve original order snapshot and detect live config rotation via keyed HMAC fingerprint without silently substituting cards.
- **Hardened auth, RBAC, receipts, concurrency & audit logs:** Strict HS256 JWT signature-first verification, session revocation on logout and password recovery, magic-byte binary receipt validation (PNG/JPEG/WebP/PDF, <=5 MB), deterministic row locks, engine-enforced append-only triggers + SHA-256 hash chaining.
- **Additive DB migrations:** Added `002_phase031_phase04_up.sql` and `002_phase031_phase04_down.sql` on top of `db/schema.sql` and `001_phase03_up.sql` without dropping or discarding existing tables or data.

## 3. Phase 0.4 Complete Frontend & Three.js Foundation (IMPLEMENTED — BUILD/RUNTIME BLOCKED BY SANDBOX)
All 14 required sections are implemented as real React + TypeScript + Vite + Tailwind CSS pages connected to real backend endpoints (zero mocked success responses), with Uzbek Latin primary i18n (`uz`) and Russian (`ru`) + English (`en`) support:
1. Landing page & CityX introduction (`LandingPage.tsx` -> `GET /api/city/overview`)
2. Registration, login & account recovery (`AuthPage.tsx` -> `/api/auth/register`, `/api/auth/login`, `/api/miniapp/auth`, `/api/auth/recovery/*`)
3. User profile, avatar presets & 1–50 floor home editor (`ProfilePage.tsx` -> `/api/profile/me`, `/api/homes/me`)
4. Main CityX dashboard (`DashboardPage.tsx` -> `/api/dashboard`, `/api/economy/daily-claim`)
5. Interactive 8-district city map, taxi & atomic landmarks (`CityMapPage.tsx` -> `/api/city/map`, `/api/city/taxi`, `/api/objects/{id}/acquire`)
6. 3D city entry & exploration interface (`City3DPage.tsx` + `City3DViewport.tsx` + `CitySceneEngine.ts`)
7. Wallet & append-only ledger history (`WalletPage.tsx` -> `/api/wallet`)
8. Manual payment submission with separate Visa & Uzcard cards (`PaymentsPage.tsx` -> `/api/payments/methods`, `/api/payments/packages`, `/api/payments/orders`)
9. Receipt upload & order status tracking (`PaymentsPage.tsx` -> `/api/payments/orders/{id}/receipt`, `/submit`, `/cancel`)
10. User settings (`uz`/`ru`/`en`, classic mode, prefs) & notifications (`SettingsPage.tsx` -> `/api/settings`, `/api/notifications`)
11. Social profiles, citizen discovery, friend requests & home likes (`SocialPage.tsx` -> `/api/social/*`)
12. Places, businesses, services, events RSVP & elections (`PlacesPage.tsx` -> `/api/places`, `/api/events`, `/api/elections`)
13. Role-based Admin Dashboard (`AdminPage.tsx` -> `/api/admin/*`)
14. Responsive navigation bar & mobile drawer (`Layout.tsx`)

### Three.js Honest Scope Note
`apps/web/src/three/CitySceneEngine.ts` and `City3DViewport.tsx` implement a **real Three.js WebGL foundation** (responsive renderer, day/sunset/night PBR lighting, 8-district 1200×1200m base grid, arterial roads, procedural landmark silhouettes, HD/Lite quality toggle, mobile 2D fallback, raycast selection, and `MultiplayerEntityAdapter` hooks for future avatars/buildings/multiplayer). It is **NOT** a finished high-detail 3D metaverse world; high-detail GLB landmarks, user-built 3D houses, vehicles, and multiplayer remain scheduled for Phases 1–6.

## 4. Remaining Blockers & Honest Deployment Status
- **NOT DEPLOYED:** Neither Vercel nor Render nor PostgreSQL has been deployed in this sandbox.
- **Node.js / npm / TypeScript / Vite unavailable in sandbox:** `tsc --noEmit`, `vite build`, and `vitest run` could NOT be executed here and must be executed in a Node 20+ environment.
- **FastAPI / httpx / pytest / PostgreSQL unavailable in sandbox:** `tests/test_phase03_fastapi.py`, `tests/test_phase04_fastapi.py`, and live PostgreSQL `psql` migration rehearsals could NOT be executed here and must be run in a Python 3.10+ / PostgreSQL staging environment.
- **Account recovery email delivery:** `SMTP_HOST` is intentionally unconfigured; `/api/auth/recovery/request` honestly reports `email_delivery_configured: false` and admins can issue audited single-use tokens via `/api/admin/users/{user_id}/recovery-token` until SMTP or Telegram OTP delivery is connected.
- **Card 2 (Uzcard) issuing bank:** Remains `null` (`CITYX_PAYMENT_UZCARD_BANK_NAME=""`) until explicitly verified.
