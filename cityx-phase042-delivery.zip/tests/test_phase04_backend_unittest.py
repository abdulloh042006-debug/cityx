from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from apps.api.auth.tokens import AuthSecurity
from apps.api.config import AppConfig, ManualCardConfig
from apps.api.db.store import CityXStore
from apps.api.domain.services import CityXDomainService, ConflictError, DomainError, ForbiddenError, UnauthorizedError

SYNTHETIC_VISA = "4000000000001111"
SYNTHETIC_UZCARD = "5000000000002222"


class TestPhase04Backend(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp(prefix="cityx_p04_")
        self.db_file = os.path.join(self.tmp, "p04.sqlite3")
        self.cfg = AppConfig(
            environment="development",
            port=8080,
            host="127.0.0.1",
            database_url="",
            sqlite_path=self.db_file,
            bot_token="123456:TEST_BOT_TOKEN",
            bot_username="cityx_bot",
            miniapp_short_name="app",
            web_base_url="https://cityx.uz",
            cors_origins=("https://cityx.uz",),
            signing_secret="phase04_unit_test_secret_32_bytes_ok",
            webhook_url="",
            webhook_secret="phase04_webhook_secret_32_bytes_ok",
            admin_telegram_ids=("900001",),
            receipt_storage_dir=os.path.join(self.tmp, "receipts"),
            manual_payment_support_handle="@cityx_bot",
            smtp_configured=False,
            manual_cards={
                "uzum_visa": ManualCardConfig(
                    code="uzum_visa",
                    display_name="Uzum Bank — Visa",
                    network="Visa",
                    bank_name="Uzum Bank",
                    card_number=SYNTHETIC_VISA,
                    recipient_name="Abdullox Arslonov",
                    enabled=True,
                ),
                "uzcard": ManualCardConfig(
                    code="uzcard",
                    display_name="Uzcard",
                    network="Uzcard",
                    bank_name=None,
                    card_number=SYNTHETIC_UZCARD,
                    recipient_name="Arslonov Abdulloh",
                    enabled=True,
                ),
            },
            ton_wallet_enabled=False,
        )
        self.store = CityXStore(database_url="", sqlite_path=self.db_file)
        self.domain = CityXDomainService(config=self.cfg, store=self.store)
        self.sec = AuthSecurity(bot_token=self.cfg.bot_token, signing_secret=self.cfg.signing_secret)

        self.u1 = self.domain.register_local_user(username="aziz_tashkent", password="Password123!", district_id="downtown")["user"]
        self.u2 = self.domain.register_local_user(username="malika_uz", password="Password456!", district_id="business")["user"]
        self.adm, _ = self.domain.get_or_create_telegram_user({"id": 900001, "username": "root_admin"})

    def tearDown(self) -> None:
        self.store.close()

    def test_01_public_overview_city_map_and_places(self) -> None:
        ov = self.domain.get_public_overview()
        self.assertEqual(ov["districts_count"], 8)
        self.assertEqual(ov["landmarks_count"], 6)
        self.assertEqual(ov["places_count"], 15)
        self.assertEqual(ov["payment_mode"], "manual_bank_transfer_only")
        self.assertEqual(set(ov["active_payment_methods"]), {"uzum_visa", "uzcard"})

        cmap = self.domain.get_city_map(self.u1["id"])
        self.assertEqual(len(cmap["districts"]), 8)
        self.assertEqual(len(cmap["landmarks"]), 6)
        self.assertIsNotNone(cmap["user_home"])

        edu_places = self.domain.list_places(category="education")
        self.assertEqual(len(edu_places), 3)

    def test_02_account_recovery_revokes_sessions_and_updates_password(self) -> None:
        tok, jti, exp = self.sec.issue_jwt(self.u1["id"], "user", ttl_seconds=3600)
        self.domain.create_session(self.u1["id"], jti, exp)
        self.assertIsNotNone(self.domain.get_active_user_for_token(self.u1["id"], jti))

        req = self.domain.request_password_recovery("aziz_tashkent")
        self.assertTrue(req["accepted"])
        self.assertFalse(req["email_delivery_configured"])

        # Non-admin cannot issue recovery tokens
        with self.assertRaises(ForbiddenError):
            self.domain.issue_recovery_token_for_admin(self.u2["id"], self.u1["id"])

        # Admin issues audited single-use recovery token
        issued = self.domain.issue_recovery_token_for_admin(self.adm["id"], self.u1["id"])
        raw_tok = issued["recovery_token"]

        res = self.domain.confirm_password_recovery(raw_tok, "NewStrongPass789!")
        self.assertEqual(res["status"], "password_updated")
        # Old session revoked immediately
        self.assertIsNone(self.domain.get_active_user_for_token(self.u1["id"], jti))
        # Replay of token rejected
        with self.assertRaises(DomainError):
            self.domain.confirm_password_recovery(raw_tok, "AnotherPass999!")
        # Old password fails, new password succeeds
        with self.assertRaises(UnauthorizedError):
            self.domain.authenticate_local_user("aziz_tashkent", "Password123!")
        authed = self.domain.authenticate_local_user("aziz_tashkent", "NewStrongPass789!")
        self.assertEqual(authed["id"], self.u1["id"])

    def test_03_profile_avatar_security_and_settings_notifications(self) -> None:
        with self.assertRaises(DomainError):
            self.domain.update_profile(self.u1["id"], avatar_url="javascript:alert(1)")
        with self.assertRaises(DomainError):
            self.domain.update_profile(self.u1["id"], avatar_url="data:text/html,<script>")

        upd = self.domain.update_profile(
            self.u1["id"],
            display_name="Aziz Architect",
            bio="Toshkent 3D me’mori",
            instagram_handle="@aziz.cityx",
            avatar_url="preset:gold-vip",
        )
        self.assertEqual(upd["display_name"], "Aziz Architect")
        self.assertEqual(upd["bio"], "Toshkent 3D me’mori")
        self.assertEqual(upd["avatar_url"], "preset:gold-vip")

        st = self.domain.update_settings(self.u1["id"], language="ru", classic_mode=True, notify_prefs={"social": False})
        self.assertEqual(st["language"], "ru")
        self.assertTrue(st["classic_mode"])
        self.assertEqual(st["notify_prefs"]["social"], False)

        # Invalid language rejected
        with self.assertRaises(DomainError):
            self.domain.update_settings(self.u1["id"], language="de")

    def test_04_social_discovery_friends_home_likes_events_and_elections(self) -> None:
        found = self.domain.discover_profiles(query="malika")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["username"], "malika_uz")

        fr = self.domain.request_friendship(self.u1["id"], "malika_uz")
        self.assertEqual(fr["status"], "pending")
        # Duplicate friendship blocked
        with self.assertRaises(ConflictError):
            self.domain.request_friendship(self.u2["id"], "aziz_tashkent")
        # Sender cannot accept own request
        with self.assertRaises(ForbiddenError):
            self.domain.accept_friendship(self.u1["id"], fr["id"])
        acc = self.domain.accept_friendship(self.u2["id"], fr["id"])
        self.assertEqual(acc["status"], "accepted")

        # Recipient got notification
        notifs = self.domain.list_notifications(self.u2["id"])
        self.assertGreaterEqual(len(notifs), 1)
        marked = self.domain.mark_notification_read(self.u2["id"], notifs[0]["id"])
        self.assertEqual(int(marked["is_read"]), 1)

        # Home like increments reputation once
        pub = self.domain.get_public_profile("malika_uz")
        home_id = pub["home"]["id"]
        liked = self.domain.like_home(self.u1["id"], home_id)
        self.assertEqual(liked["likes_count"], 1)
        with self.assertRaises(ConflictError):
            self.domain.like_home(self.u1["id"], home_id)

        # Events RSVP toggle
        evs = self.domain.list_events(self.u1["id"])
        self.assertGreaterEqual(len(evs), 1)
        r1 = self.domain.toggle_event_rsvp(self.u1["id"], evs[0]["id"], join=True)
        self.assertTrue(r1["joined"])
        self.assertEqual(r1["attendees_count"], 1)

        # Elections list
        elecs = self.domain.list_elections(self.u1["id"])
        self.assertEqual(len(elecs), 1)
        self.assertEqual(elecs[0]["status"], "open")

    def test_05_zero_full_card_number_exposure_across_all_payment_and_admin_payloads(self) -> None:
        methods = self.domain.list_payment_methods()
        order_res = self.domain.create_manual_payment_order(
            user_id=self.u1["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="no_pan_leak_1",
        )
        oid = order_res["order"]["order_id"]
        self.domain.submit_manual_payment_proof(order_id=oid, user_id=self.u1["id"], submitted_reference="TX-SAFE-1")
        approved = self.domain.approve_manual_payment_order(order_id=oid, admin_user_id=self.adm["id"])
        admin_ov = self.domain.get_admin_overview(self.adm["id"])
        admin_orders = self.domain.list_admin_payment_orders(admin_user_id=self.adm["id"])
        admin_audits = self.domain.list_admin_audit_logs(self.adm["id"])
        wallet = self.domain.get_wallet(self.u1["id"])
        dash = self.domain.get_dashboard_summary(self.u1["id"])

        blob = json.dumps([methods, order_res, approved, admin_ov, admin_orders, admin_audits, wallet, dash])
        self.assertNotIn(SYNTHETIC_VISA, blob)
        self.assertNotIn(SYNTHETIC_UZCARD, blob)
        self.assertEqual(admin_ov["approved_payments"], 1)

        # Non-admin blocked from admin endpoints
        with self.assertRaises(ForbiddenError):
            self.domain.get_admin_overview(self.u1["id"])
        with self.assertRaises(ForbiddenError):
            self.domain.list_admin_users(self.u1["id"])
        with self.assertRaises(ForbiddenError):
            self.domain.list_admin_audit_logs(self.u1["id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
