from __future__ import annotations

import base64
import concurrent.futures
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest
import urllib.parse

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from apps.api.auth.tokens import AuthSecurity, JWT_AUDIENCE, JWT_ISSUER
from apps.api.config import AppConfig, ManualCardConfig, mask_card_number
from apps.api.db.store import CityXStore
from apps.api.domain.services import (
    CityXDomainService,
    ConflictError,
    DomainError,
    ForbiddenError,
)
from apps.api.payments.receipts import MAX_RECEIPT_BYTES, ReceiptValidationError, validate_receipt_bytes
from apps.api.telegram.adapter import SUPPORTED_COMMANDS, TelegramBotAdapter
from apps.api.telegram.widgets import WIDGET_TEMPLATES, validate_all_widget_templates

# Synthetic test-only placeholders (NEVER real card numbers or production secrets)
TEST_BOT_TOKEN = "123456789:TEST_ONLY_BOT_TOKEN"
TEST_SECRET = "unit_test_signing_secret_minimum_32_bytes_ok"
SYNTHETIC_VISA = "4000000000001111"
SYNTHETIC_VISA_ROTATED = "4000000000009999"
SYNTHETIC_UZCARD = "5000000000002222"


def make_test_config(
    *,
    sqlite_path: str = ":memory:",
    visa_card: str = SYNTHETIC_VISA,
    visa_enabled: bool = True,
    uzcard_card: str = SYNTHETIC_UZCARD,
    uzcard_enabled: bool = True,
    receipt_dir: str = "",
) -> AppConfig:
    return AppConfig(
        environment="development",
        port=9123,
        host="127.0.0.1",
        database_url="",
        sqlite_path=sqlite_path,
        bot_token=TEST_BOT_TOKEN,
        bot_username="cityx_bot",
        miniapp_short_name="app",
        web_base_url="https://cityx.uz",
        cors_origins=("https://cityx.uz",),
        signing_secret=TEST_SECRET,
        webhook_url="",
        webhook_secret="test_webhook_secret_32_bytes_long",
        admin_telegram_ids=("900001",),
        receipt_storage_dir=receipt_dir,
        manual_payment_support_handle="@cityx_bot",
        smtp_configured=False,
        manual_cards={
            "uzum_visa": ManualCardConfig(
                code="uzum_visa",
                display_name="Uzum Bank — Visa",
                network="Visa",
                bank_name="Uzum Bank",
                card_number=visa_card,
                recipient_name="Abdullox Arslonov",
                enabled=visa_enabled,
            ),
            "uzcard": ManualCardConfig(
                code="uzcard",
                display_name="Uzcard",
                network="Uzcard",
                bank_name=None,  # Explicitly unverified; never assumed
                card_number=uzcard_card,
                recipient_name="Arslonov Abdulloh",
                enabled=uzcard_enabled,
            ),
        },
        ton_wallet_enabled=False,
    )


def sign_raw_jwt(secret: str, header: object, payload: object) -> str:
    def b64u(obj: object) -> str:
        raw = json.dumps(obj, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")

    h, p = b64u(header), b64u(payload)
    sig = hmac.new(secret.encode("utf-8"), f"{h}.{p}".encode("ascii"), hashlib.sha256).digest()
    s = base64.urlsafe_b64encode(sig).rstrip(b"=").decode("ascii")
    return f"{h}.{p}.{s}"


def build_signed_init_data(tg_user: dict, bot_token: str = TEST_BOT_TOKEN, auth_date: int | None = None) -> str:
    params = {
        "auth_date": str(auth_date if auth_date is not None else int(time.time())),
        "query_id": "AAEAAAE",
        "user": json.dumps(tg_user, separators=(",", ":")),
    }
    check = "\n".join(f"{k}={params[k]}" for k in sorted(params.keys()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256).digest()
    params["hash"] = hmac.new(secret_key, check.encode("utf-8"), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(params)


class FakeTelegramClient:
    """In-memory Telegram Bot API double for adapter integration tests."""

    def __init__(self) -> None:
        self.sent_widgets = []
        self.sent_messages = []
        self.widget_answers = []
        self.callback_answers = []
        self._msg_seq = 100

    def send_widget(self, chat_id, html, **kwargs):
        self._msg_seq += 1
        rec = {"message_id": self._msg_seq, "chat_id": chat_id, "html": html, **kwargs}
        self.sent_widgets.append(rec)
        return {"message_id": self._msg_seq}

    def send_message(self, chat_id, text, **kwargs):
        self._msg_seq += 1
        rec = {"message_id": self._msg_seq, "chat_id": chat_id, "text": text, **kwargs}
        self.sent_messages.append(rec)
        return {"message_id": self._msg_seq}

    def answer_widget_query(self, widget_query_id, text=""):
        self.widget_answers.append((widget_query_id, text))
        return True

    def answer_callback_query(self, callback_query_id, text="", show_alert=False):
        self.callback_answers.append((callback_query_id, text, show_alert))
        return True

    def create_forum_topic(self, chat_id, name):
        self._msg_seq += 1
        return {"message_thread_id": self._msg_seq, "name": name}


class TestPhase03Core(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp_dir = tempfile.mkdtemp(prefix="cityx_test_")
        self.db_file = os.path.join(self.tmp_dir, "cityx_test.sqlite3")
        self.receipt_dir = os.path.join(self.tmp_dir, "receipts")
        self.cfg = make_test_config(sqlite_path=self.db_file, receipt_dir=self.receipt_dir)
        self.store = CityXStore(database_url="", sqlite_path=self.db_file)
        self.domain = CityXDomainService(config=self.cfg, store=self.store)
        self.sec = AuthSecurity(bot_token=TEST_BOT_TOKEN, signing_secret=TEST_SECRET)
        self.user, _ = self.domain.get_or_create_telegram_user({"id": 100001, "username": "buyer_one"})
        self.user2, _ = self.domain.get_or_create_telegram_user({"id": 100002, "username": "buyer_two"})
        self.admin, _ = self.domain.get_or_create_telegram_user({"id": 900001, "username": "cityx_admin"})

    def tearDown(self) -> None:
        self.store.close()

    # 1. Dual-Card Isolation & Masking
    def test_01_dual_card_isolation_and_no_uzcard_bank_assumption(self) -> None:
        methods = {m["code"]: m for m in self.domain.list_payment_methods()}
        self.assertEqual(set(methods.keys()), {"uzum_visa", "uzcard"})

        # Card 1 — Uzum Bank Visa -> Abdullox Arslonov
        self.assertEqual(methods["uzum_visa"]["bank_name"], "Uzum Bank")
        self.assertEqual(methods["uzum_visa"]["network"], "Visa")
        self.assertEqual(methods["uzum_visa"]["recipient_name"], "Abdullox Arslonov")
        self.assertEqual(methods["uzum_visa"]["card_last4"], "1111")

        # Card 2 — Uzcard -> Arslonov Abdulloh, issuing bank strictly None
        self.assertIsNone(methods["uzcard"]["bank_name"])
        self.assertEqual(methods["uzcard"]["network"], "Uzcard")
        self.assertEqual(methods["uzcard"]["recipient_name"], "Arslonov Abdulloh")
        self.assertEqual(methods["uzcard"]["card_last4"], "2222")

        # Card numbers never appear in repr() or masked display
        self.assertNotIn(SYNTHETIC_VISA, repr(self.cfg.manual_cards["uzum_visa"]))
        self.assertNotIn(SYNTHETIC_UZCARD, repr(self.cfg.manual_cards["uzcard"]))
        self.assertEqual(mask_card_number(SYNTHETIC_UZCARD), "****2222")

        # Creating one order per card keeps recipients & banks strictly separate
        o_visa = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="iso_visa_1",
        )
        o_uzc = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzcard",
            idempotency_key="iso_uzcard_1",
        )
        self.assertEqual(o_visa["transfer_instructions"]["recipient_name"], "Abdullox Arslonov")
        self.assertEqual(o_visa["transfer_instructions"]["bank_name"], "Uzum Bank")
        self.assertNotIn("card_number", o_visa["transfer_instructions"])
        self.assertEqual(o_visa["transfer_instructions"]["card_masked"], "**** **** **** 1111")

        self.assertEqual(o_uzc["transfer_instructions"]["recipient_name"], "Arslonov Abdulloh")
        self.assertIsNone(o_uzc["transfer_instructions"]["bank_name"])
        self.assertNotIn("card_number", o_uzc["transfer_instructions"])
        self.assertEqual(o_uzc["transfer_instructions"]["card_masked"], "**** **** **** 2222")

    # 2. Payment Idempotency & Card-Rotation Snapshot Preservation
    def test_02_payment_idempotency_preserves_original_snapshot_after_card_rotation(self) -> None:
        first = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="idem_rotate_01",
        )
        self.assertFalse(first["idempotent_replay"])
        self.assertFalse(first["transfer_instructions"]["card_config_changed"])
        self.assertNotIn("card_number", first["transfer_instructions"])
        self.assertEqual(first["transfer_instructions"]["card_masked"], "**** **** **** 1111")

        # Retry with mismatched parameters MUST fail with 409 Conflict
        with self.assertRaises(ConflictError):
            self.domain.create_manual_payment_order(
                user_id=self.user["id"],
                package_id="gems_500",
                payment_method_code="uzum_visa",
                idempotency_key="idem_rotate_01",
            )
        with self.assertRaises(ConflictError):
            self.domain.create_manual_payment_order(
                user_id=self.user["id"],
                package_id="gems_100",
                payment_method_code="uzcard",
                idempotency_key="idem_rotate_01",
            )

        # Rotate the Visa card in live server config; retry MUST NOT substitute the rotated card!
        rotated_cfg = make_test_config(sqlite_path=self.db_file, visa_card=SYNTHETIC_VISA_ROTATED)
        rotated_domain = CityXDomainService(config=rotated_cfg, store=self.store)
        replay = rotated_domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="idem_rotate_01",
        )
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(replay["order"]["order_id"], first["order"]["order_id"])
        self.assertEqual(replay["transfer_instructions"]["recipient_name"], "Abdullox Arslonov")
        self.assertEqual(replay["transfer_instructions"]["card_last4"], "1111")
        self.assertTrue(replay["transfer_instructions"]["card_config_changed"])
        self.assertNotIn("card_number", replay["transfer_instructions"])
        self.assertNotIn(SYNTHETIC_VISA_ROTATED, json.dumps(replay))

        # Another user can safely use the same idempotency_key (scoped per user_id)
        other = self.domain.create_manual_payment_order(
            user_id=self.user2["id"],
            package_id="gems_100",
            payment_method_code="uzcard",
            idempotency_key="idem_rotate_01",
        )
        self.assertNotEqual(other["order"]["order_id"], first["order"]["order_id"])

    # 3. Manual Approval Only, Zero Pre-Credit, Admin RBAC, No Self-Approval, No Double Credit
    def test_03_manual_approval_workflow_and_zero_pre_credit(self) -> None:
        start_gems = int(self.domain.get_user_view(self.user["id"])["gems"])
        created = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzcard",
            idempotency_key="pay_flow_01",
        )
        order_id = created["order"]["order_id"]

        # Valid receipt upload + proof submission MUST credit ZERO gems
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
        self.domain.upload_manual_payment_receipt(order_id=order_id, user_id=self.user["id"], raw_bytes=png_bytes)
        submitted = self.domain.submit_manual_payment_proof(
            order_id=order_id, user_id=self.user["id"], submitted_reference="UZC-REF-998877"
        )
        self.assertEqual(submitted["status"], "pending_review")
        self.assertEqual(int(self.domain.get_user_view(self.user["id"])["gems"]), start_gems)

        # Non-admin approval MUST fail with ForbiddenError (403)
        with self.assertRaises(ForbiddenError):
            self.domain.approve_manual_payment_order(order_id=order_id, admin_user_id=self.user2["id"])

        # Admin approves -> credits exactly +100 Gems once
        approved = self.domain.approve_manual_payment_order(order_id=order_id, admin_user_id=self.admin["id"])
        self.assertEqual(approved["order"]["status"], "approved")
        self.assertEqual(int(self.domain.get_user_view(self.user["id"])["gems"]), start_gems + 100)

        # Replay approval MUST fail with ConflictError (409) and never double credit
        with self.assertRaises(ConflictError):
            self.domain.approve_manual_payment_order(order_id=order_id, admin_user_id=self.admin["id"])
        self.assertEqual(int(self.domain.get_user_view(self.user["id"])["gems"]), start_gems + 100)

        # Hash chain across order_created -> receipt_uploaded -> reference_submitted -> admin_approved
        self.assertTrue(self.domain.verify_payment_audit_chain(order_id))

        # Admin self-approval MUST fail with ForbiddenError (403)
        own = self.domain.create_manual_payment_order(
            user_id=self.admin["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="admin_self_01",
        )["order"]["order_id"]
        self.domain.submit_manual_payment_proof(order_id=own, user_id=self.admin["id"], submitted_reference="VISA-SELF-1")
        with self.assertRaises(ForbiddenError):
            self.domain.approve_manual_payment_order(order_id=own, admin_user_id=self.admin["id"])

        # Rejection credits 0 currency and records reason
        rej_id = self.domain.create_manual_payment_order(
            user_id=self.user2["id"],
            package_id="gems_500",
            payment_method_code="uzum_visa",
            idempotency_key="rej_flow_01",
        )["order"]["order_id"]
        u2_start = int(self.domain.get_user_view(self.user2["id"])["gems"])
        self.domain.submit_manual_payment_proof(order_id=rej_id, user_id=self.user2["id"], submitted_reference="FAKE-123")
        rejected = self.domain.reject_manual_payment_order(
            order_id=rej_id,
            admin_user_id=self.admin["id"],
            rejection_reason="Transfer not found in Uzum Bank statement",
        )
        self.assertEqual(rejected["status"], "rejected")
        self.assertEqual(int(self.domain.get_user_view(self.user2["id"])["gems"]), u2_start)

    # 4. Taxi Idempotency & Canonical Districts
    def test_04_taxi_idempotency_replay_and_canonical_districts(self) -> None:
        # Legacy invalid district rejected
        with self.assertRaises(DomainError):
            self.domain.book_taxi(self.user["id"], "Harbor", "req_bad_01")

        start_coins = int(self.domain.get_user_view(self.user["id"])["coins"])
        first = self.domain.book_taxi(self.user["id"], "business", "req_taxi_01")
        self.assertFalse(first["idempotent_replay"])
        self.assertEqual(first["fare_coins"], 150)
        self.assertEqual(first["balance_after"], start_coins - 150)

        # Replay with identical request_id returns exact original result with ZERO second charge
        replay = self.domain.book_taxi(self.user["id"], "business", "req_taxi_01")
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(replay["ride_id"], first["ride_id"])
        self.assertEqual(replay["balance_after"], start_coins - 150)
        self.assertEqual(int(self.domain.get_user_view(self.user["id"])["coins"]), start_coins - 150)

        # Reusing request_id for a DIFFERENT district MUST fail with 409 Conflict
        with self.assertRaises(ConflictError):
            self.domain.book_taxi(self.user["id"], "vip", "req_taxi_01")

    # 5. Strict JWT Validation & Session Revocation
    def test_05_strict_jwt_validation_and_session_revocation(self) -> None:
        tok, jti, exp = self.sec.issue_jwt(self.user["id"], "user", ttl_seconds=300)
        self.domain.create_session(self.user["id"], jti, exp)
        claims = self.sec.verify_jwt(tok)
        self.assertEqual(claims["sub"], self.user["id"])
        self.assertIsNotNone(self.domain.get_active_user_for_token(claims["sub"], claims["jti"]))

        # Revoked session rejected
        self.domain.revoke_session(self.user["id"], jti)
        self.assertIsNone(self.domain.get_active_user_for_token(claims["sub"], claims["jti"]))

        now = int(time.time())
        base_hdr = {"alg": "HS256", "typ": "JWT"}
        base_pay = {
            "iss": JWT_ISSUER,
            "aud": JWT_AUDIENCE,
            "sub": self.user["id"],
            "role": "user",
            "iat": now,
            "nbf": now,
            "exp": now + 300,
            "jti": "jti_test",
        }

        malformed_cases = [
            "",
            "not.a.jwt.with.four.parts",
            "a" * 5000,
            tok[:-1] + ("A" if tok[-1] != "A" else "B"),  # tampered sig
            sign_raw_jwt(TEST_SECRET, ["not-a-dict"], base_pay),
            sign_raw_jwt(TEST_SECRET, base_hdr, ["not-a-dict"]),
            sign_raw_jwt(TEST_SECRET, {"alg": "none", "typ": "JWT"}, base_pay),
            sign_raw_jwt(TEST_SECRET, {"alg": "HS256", "typ": "OTHER"}, base_pay),
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "iss": "evil"}),
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "aud": "evil"}),
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "role": "superadmin"}),
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "exp": True}),       # bool-as-int trap
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "iat": False}),      # bool-as-int trap
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "exp": now - 10}),   # expired
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "iat": now + 999}),  # future iat
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "nbf": now + 999}),  # future nbf
            sign_raw_jwt(TEST_SECRET, base_hdr, {**base_pay, "exp": now + 200000}),  # > 24h TTL
        ]
        for bad in malformed_cases:
            with self.assertRaises(ValueError, msg=f"Should reject JWT: {bad[:40]}"):
                self.sec.verify_jwt(bad)

        # Telegram initData HMAC + freshness check preserved
        good_init = build_signed_init_data({"id": 555001, "username": "tg_mini_ok"})
        parsed = self.sec.verify_miniapp_init_data(good_init)
        self.assertEqual(parsed["id"], 555001)
        expired_init = build_signed_init_data({"id": 555001, "username": "tg_mini_ok"}, auth_date=now - 600)
        with self.assertRaises(ValueError):
            self.sec.verify_miniapp_init_data(expired_init)

    # 6. Receipt Upload Security & Unsafe URL Rejection
    def test_06_receipt_magic_byte_validation_and_url_rejection(self) -> None:
        for payload, expected_mime in [
            (b"\x89PNG\r\n\x1a\n" + b"x" * 32, "image/png"),
            (b"\xff\xd8\xff\xe0" + b"x" * 32, "image/jpeg"),
            (b"RIFF\x00\x00\x00\x00WEBP" + b"x" * 32, "image/webp"),
            (b"%PDF-1.7\n" + b"x" * 32, "application/pdf"),
        ]:
            v = validate_receipt_bytes(payload, "CX-ORDER1234")
            self.assertEqual(v.mime_type, expected_mime)
            self.assertTrue(v.object_key.startswith("receipts/CX-ORDER1234/"))

        # Reject empty, >5MB, HTML/XSS/SVG disguised uploads
        for bad in (
            b"",
            b"<script>alert(1)</script>",
            b"<svg onload=alert(1)></svg>",
            b"\x89PNG\r\n\x1a\n" + b"a" * (MAX_RECEIPT_BYTES + 1),
        ):
            with self.assertRaises(ReceiptValidationError):
                validate_receipt_bytes(bad, "CX-ORDER1234")

        # Reject URL/script injection inside submitted_reference
        order_id = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzcard",
            idempotency_key="url_reject_01",
        )["order"]["order_id"]
        for unsafe_ref in ("javascript:alert(1)", "https://evil.example/receipt.png", "data:text/html,xss"):
            with self.assertRaises(DomainError):
                self.domain.submit_manual_payment_proof(
                    order_id=order_id, user_id=self.user["id"], submitted_reference=unsafe_ref
                )

    # 7. Database-Enforced Audit & Ledger Immutability (Real SQLite Triggers)
    def test_07_database_triggers_block_audit_and_ledger_tampering(self) -> None:
        order_id = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="audit_immut_01",
        )["order"]["order_id"]
        self.domain.submit_manual_payment_proof(order_id=order_id, user_id=self.user["id"], submitted_reference="TX-8821")
        self.domain.approve_manual_payment_order(order_id=order_id, admin_user_id=self.admin["id"])

        for stmt in (
            "UPDATE payment_audit_logs SET event_type = 'tampered'",
            "DELETE FROM payment_audit_logs",
            "UPDATE admin_audit_logs SET action = 'tampered'",
            "DELETE FROM admin_audit_logs",
            "UPDATE economy_ledger SET delta = 999999",
            "DELETE FROM economy_ledger",
        ):
            with self.assertRaises(sqlite3.IntegrityError, msg=f"Trigger must block: {stmt}"):
                with self.store.transaction() as tx:
                    tx.execute(stmt)

    # 8. Real Multi-Threaded Concurrency Tests
    def test_08_concurrent_approval_daily_vote_taxi_order_and_landmark(self) -> None:
        # 8a. 8 concurrent admin approvals -> strictly 1 succeeds, 7 fail with ConflictError
        order_id = self.domain.create_manual_payment_order(
            user_id=self.user["id"],
            package_id="gems_100",
            payment_method_code="uzcard",
            idempotency_key="conc_approve_01",
        )["order"]["order_id"]
        self.domain.submit_manual_payment_proof(order_id=order_id, user_id=self.user["id"], submitted_reference="CONC-1")
        before_gems = int(self.domain.get_user_view(self.user["id"])["gems"])

        def try_approve(_: int) -> str:
            try:
                self.domain.approve_manual_payment_order(order_id=order_id, admin_user_id=self.admin["id"])
                return "ok"
            except ConflictError:
                return "conflict"

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(try_approve, range(8)))
        self.assertEqual(results.count("ok"), 1)
        self.assertEqual(results.count("conflict"), 7)
        self.assertEqual(int(self.domain.get_user_view(self.user["id"])["gems"]), before_gems + 100)

        # 8b. Concurrent approve vs reject -> strictly 1 wins
        race_id = self.domain.create_manual_payment_order(
            user_id=self.user2["id"],
            package_id="gems_100",
            payment_method_code="uzum_visa",
            idempotency_key="conc_race_02",
        )["order"]["order_id"]
        self.domain.submit_manual_payment_proof(order_id=race_id, user_id=self.user2["id"], submitted_reference="CONC-2")

        def approve_or_reject(flag: int) -> str:
            try:
                if flag == 0:
                    self.domain.approve_manual_payment_order(order_id=race_id, admin_user_id=self.admin["id"])
                    return "approved"
                self.domain.reject_manual_payment_order(
                    order_id=race_id, admin_user_id=self.admin["id"], rejection_reason="Race reject"
                )
                return "rejected"
            except ConflictError:
                return "conflict"

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            race_res = list(pool.map(approve_or_reject, [0, 1]))
        self.assertEqual(race_res.count("conflict"), 1)
        self.assertEqual(len([x for x in race_res if x in ("approved", "rejected")]), 1)

        # 8c. 8 concurrent daily claims -> strictly 1 succeeds
        before_coins = int(self.domain.get_user_view(self.user["id"])["coins"])
        def try_daily(_: int) -> str:
            try:
                self.domain.claim_daily_reward(self.user["id"])
                return "ok"
            except ConflictError:
                return "conflict"

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            d_res = list(pool.map(try_daily, range(8)))
        self.assertEqual(d_res.count("ok"), 1)
        self.assertEqual(d_res.count("conflict"), 7)
        self.assertEqual(int(self.domain.get_user_view(self.user["id"])["coins"]), before_coins + 150)

        # 8d. 8 concurrent election votes -> strictly 1 succeeds
        def try_vote(_: int) -> str:
            try:
                self.domain.cast_election_vote(self.user["id"], "elec_2026_q4", "cand_aziza")
                return "ok"
            except ConflictError:
                return "conflict"

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            v_res = list(pool.map(try_vote, range(8)))
        self.assertEqual(v_res.count("ok"), 1)
        self.assertEqual(v_res.count("conflict"), 7)

        # 8e. 8 concurrent identical taxi retries -> strictly 1 charge, all succeed cleanly
        coins_before_taxi = int(self.domain.get_user_view(self.user2["id"])["coins"])
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            t_res = list(pool.map(lambda _: self.domain.book_taxi(self.user2["id"], "business", "conc_taxi_99"), range(8)))
        ride_ids = {r["ride_id"] for r in t_res}
        self.assertEqual(len(ride_ids), 1)
        self.assertEqual(int(self.domain.get_user_view(self.user2["id"])["coins"]), coins_before_taxi - 150)

        # 8f. 8 concurrent identical payment order creates -> strictly 1 order_id created
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            o_res = list(
                pool.map(
                    lambda _: self.domain.create_manual_payment_order(
                        user_id=self.user["id"],
                        package_id="gems_100",
                        payment_method_code="uzum_visa",
                        idempotency_key="conc_order_create_88",
                    ),
                    range(8),
                )
            )
        self.assertEqual(len({r["order"]["order_id"] for r in o_res}), 1)

        # 8g. 8 concurrent landmark acquisitions at expected_version=1 -> strictly 1 wins
        buyers = [
            self.domain.register_local_user(username=f"racer_{i}", password="StrongPassword123!")["user"]
            for i in range(8)
        ]

        def try_buy(u: dict) -> str:
            try:
                self.domain.acquire_object(u["id"], "obj_tvtower", expected_version=1)
                return "ok"
            except ConflictError:
                return "conflict"

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            b_res = list(pool.map(try_buy, buyers))
        self.assertEqual(b_res.count("ok"), 1)
        self.assertEqual(b_res.count("conflict"), 7)


    # 9. Telegram Adapter & All 10 Widgets Preservation + Shared DB
    def test_09_telegram_adapter_preserves_widgets_and_shares_unified_db(self) -> None:
        report = validate_all_widget_templates()
        self.assertEqual(len(report), 10)
        self.assertIn("Awaiting Admin Review", WIDGET_TEMPLATES["cityx_transaction"])
        self.assertNotIn("Awaiting Webhook", WIDGET_TEMPLATES["cityx_transaction"])
        self.assertIn("P.status!=='open'", WIDGET_TEMPLATES["cityx_election"])

        fake_tg = FakeTelegramClient()
        adapter = TelegramBotAdapter(config=self.cfg, domain=self.domain, security=self.sec, client=fake_tg)
        self.assertFalse(adapter.caps.enabled("telegram_stars"))
        self.assertFalse(adapter.caps.enabled("ton_wallet"))
        self.assertIn("/topup", SUPPORTED_COMMANDS)

        tg_sender = {"id": 777001, "username": "tg_citizen"}
        for cmd in ("/start", "/dashboard", "/property", "/garage", "/racing", "/battle", "/event", "/taxi", "/election"):
            adapter.handle_update({"message": {"chat": {"id": 777001, "type": "private"}, "from": tg_sender, "text": cmd}})
        self.assertEqual(len(fake_tg.sent_widgets), 9)

        # /stars handler removed completely — produces zero invoice/payment responses
        before_msgs = len(fake_tg.sent_messages)
        adapter.handle_update({"message": {"chat": {"id": 777001, "type": "private"}, "from": tg_sender, "text": "/stars"}})
        self.assertEqual(len(fake_tg.sent_messages), before_msgs)

        # /topup displays both independent manual cards without merging recipients
        adapter.handle_update({"message": {"chat": {"id": 777001, "type": "private"}, "from": tg_sender, "text": "/topup"}})
        topup_msg = fake_tg.sent_messages[-1]["text"]
        self.assertIn("Uzum Bank", topup_msg)
        self.assertIn("Abdullox Arslonov", topup_msg)
        self.assertIn("Uzcard", topup_msg)
        self.assertIn("Arslonov Abdulloh", topup_msg)

        # Widget daily claim via Telegram mutates the EXACT SAME unified DB user visible to API
        adapter.handle_update(
            {
                "widget_query": {
                    "id": "wq_daily_1",
                    "from": tg_sender,
                    "data": "d:claim",
                    "message": {"chat": {"id": 777001, "type": "private"}, "message_id": fake_tg.sent_widgets[1]["message_id"]},
                }
            }
        )
        tg_user, is_new = self.domain.get_or_create_telegram_user(tg_sender)
        self.assertFalse(is_new)
        self.assertEqual(int(tg_user["coins"]), 1150)  # 1000 starter + 150 daily claim


if __name__ == "__main__":
    unittest.main(verbosity=2)
