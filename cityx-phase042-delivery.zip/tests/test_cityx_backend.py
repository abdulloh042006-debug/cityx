import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from backend.service import CityXService


class TestCityXBackend(unittest.TestCase):
    def setUp(self):
        self.svc = CityXService(":memory:", secret_key="unit-test-secret-32-chars-minimum")
        _, self.u1 = self.svc.register_user("muu.student", "StrongPass123!", "muu.student", "residential")
        _, self.u2 = self.svc.register_user("sanjar1040", "StrongPass456!", "sanjar.1040", "downtown")
        _, self.adm = self.svc.register_user("cityx_admin", "AdminSecret999!", "", "vip", role="admin")

    def tearDown(self):
        self.svc.store.close()

    def test_01_home_persistence(self):
        code, home = self.svc.update_home(self.u1["user_id"], floors=18, has_pool=True, has_helipad=True)
        self.assertEqual(code, 200)
        self.assertEqual(home["floors"], 18)
        self.assertEqual(home["has_helipad"], 1)

    def test_02_atomic_ownership_prevents_double_buy(self):
        c1, r1 = self.svc.acquire_object(self.u1["user_id"], "obj_tvtower", expected_version=1)
        self.assertEqual(c1, 200)
        self.assertEqual(r1["new_version"], 2)
        c2, _ = self.svc.acquire_object(self.u2["user_id"], "obj_tvtower", expected_version=1)
        self.assertEqual(c2, 409)
        c3, r3 = self.svc.acquire_object(self.u2["user_id"], "obj_tvtower", expected_version=2)
        self.assertEqual(c3, 200)
        self.assertEqual(r3["owner_user_id"], self.u2["user_id"])

    def test_03_referral_anti_abuse(self):
        c_self, _ = self.svc.claim_referral(self.u1["user_id"], self.u1["user_id"])
        self.assertEqual(c_self, 400)
        c_ok, r_ok = self.svc.claim_referral(self.u1["user_id"], self.u2["user_id"])
        self.assertEqual(c_ok, 200)
        self.assertEqual(r_ok["bonus_floors"], 1)
        c_dup, _ = self.svc.claim_referral(self.u1["user_id"], self.u2["user_id"])
        self.assertEqual(c_dup, 409)

    def test_04_game_anticheat(self):
        c_cheat, _ = self.svc.submit_game_score(self.u1["user_id"], "snake", score=99999, duration_sec=3.0)
        self.assertEqual(c_cheat, 400)
        c_ok, r_ok = self.svc.submit_game_score(self.u1["user_id"], "snake", score=120, duration_sec=20.0)
        self.assertEqual(c_ok, 200)
        self.assertGreater(r_ok["coins_awarded"], 0)

    def test_05_election_single_vote(self):
        c1, _ = self.svc.cast_vote(self.u1["user_id"], self.u2["user_id"], "2026-11")
        self.assertEqual(c1, 200)
        c2, _ = self.svc.cast_vote(self.u1["user_id"], self.u2["user_id"], "2026-11")
        self.assertEqual(c2, 409)

    def test_06_firework_moderation(self):
        c_bad, _ = self.svc.launch_firework(self.u1["user_id"], "Free hack spam")
        self.assertEqual(c_bad, 400)
        c_ok, _ = self.svc.launch_firework(self.u1["user_id"], "Tugilgan kuning muborak")
        self.assertEqual(c_ok, 201)

    def test_07_admin_rbac_and_audit_log(self):
        c_unauth, _ = self.svc.admin_ban_user(self.u1["token"], self.u2["user_id"], "test")
        self.assertEqual(c_unauth, 403)
        c_ok, _ = self.svc.admin_ban_user(self.adm["token"], self.u2["user_id"], "Rule violation")
        self.assertEqual(c_ok, 200)
        log = self.svc.conn.execute(
            "SELECT * FROM admin_audit_logs WHERE target_entity = ?", (self.u2["user_id"],)
        ).fetchone()
        self.assertIsNotNone(log)
        self.assertEqual(log["action"], "BAN_USER")

    def test_08_no_callable_legacy_payment_webhook_handler_remains(self):
        # Phase 0.3.1 requirement: zero callable legacy payment handlers remain
        self.assertFalse(hasattr(self.svc, "verify_payment_webhook"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
