"""
HTTP-layer FastAPI integration tests (requires `pip install -r apps/api/requirements.txt`).
Covers:
- Strict CORS allowlist & OPTIONS preflight
- Removed Click/Payme/Uzum webhook routes returning 404
- Mini App initData -> JWT auth + protected endpoint enforcement (401/403)
- Dual-card manual payment order creation, multipart receipt upload, proof submission, admin approve/reject
- Strict extra-field rejection (arbitrary receipt_url rejected with 422)
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
import urllib.parse

import pytest
from fastapi.testclient import TestClient

from apps.api.config import AppConfig
from apps.api.db.store import CityXStore
from apps.api.main import create_app

TEST_BOT_TOKEN = "123456789:TEST_ONLY_BOT_TOKEN"
TEST_SIGNING_SECRET = "fastapi_test_signing_secret_32_bytes_minimum"
SYNTHETIC_VISA = "4000000000001111"
SYNTHETIC_UZCARD = "5000000000002222"


def build_init_data(tg_user: dict) -> str:
    params = {
        "auth_date": str(int(time.time())),
        "query_id": "AAEAAAE",
        "user": json.dumps(tg_user, separators=(",", ":")),
    }
    check = "\n".join(f"{k}={params[k]}" for k in sorted(params.keys()))
    secret_key = hmac.new(b"WebAppData", TEST_BOT_TOKEN.encode("utf-8"), hashlib.sha256).digest()
    params["hash"] = hmac.new(secret_key, check.encode("utf-8"), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(params)


@pytest.fixture()
def client(monkeypatch: pytest.MonkeyPatch, tmp_path) -> TestClient:
    monkeypatch.setenv("CITYX_ENV", "development")
    monkeypatch.setenv("PORT", "9123")
    monkeypatch.setenv("BOT_TOKEN", TEST_BOT_TOKEN)
    monkeypatch.setenv("CITYX_SIGNING_SECRET", TEST_SIGNING_SECRET)
    monkeypatch.setenv("WEBHOOK_SECRET", "test_webhook_secret_32_bytes_minimum")
    monkeypatch.setenv("CITYX_WEB_URL", "https://cityx.uz")
    monkeypatch.setenv("CITYX_ADMIN_TELEGRAM_IDS", "900001")
    monkeypatch.setenv("CITYX_RECEIPT_STORAGE_DIR", str(tmp_path / "receipts"))
    monkeypatch.setenv("CITYX_PAYMENT_VISA_ENABLED", "true")
    monkeypatch.setenv("CITYX_PAYMENT_VISA_BANK_NAME", "Uzum Bank")
    monkeypatch.setenv("CITYX_PAYMENT_VISA_CARD_NUMBER", SYNTHETIC_VISA)
    monkeypatch.setenv("CITYX_PAYMENT_VISA_RECIPIENT", "Abdullox Arslonov")
    monkeypatch.setenv("CITYX_PAYMENT_UZCARD_ENABLED", "true")
    monkeypatch.delenv("CITYX_PAYMENT_UZCARD_BANK_NAME", raising=False)
    monkeypatch.setenv("CITYX_PAYMENT_UZCARD_CARD_NUMBER", SYNTHETIC_UZCARD)
    monkeypatch.setenv("CITYX_PAYMENT_UZCARD_RECIPIENT", "Arslonov Abdulloh")

    cfg = AppConfig.from_env()
    store = CityXStore(database_url="", sqlite_path=str(tmp_path / "api_test.sqlite3"))
    return TestClient(create_app(config=cfg, store=store))


def auth_headers(client: TestClient, tg_id: int, username: str) -> dict:
    r = client.post("/api/miniapp/auth", json={"initData": build_init_data({"id": tg_id, "username": username})})
    assert r.status_code == 200
    return {"Authorization": f"Bearer {r.json()['accessToken']}"}


def test_removed_payment_webhooks_return_404_and_cors_strict(client: TestClient) -> None:
    for path in ("/webhooks/click", "/webhooks/payme", "/webhooks/uzum"):
        assert client.post(path, json={}).status_code == 404

    ok_cors = client.options(
        "/api/miniapp/auth",
        headers={"Origin": "https://cityx.uz", "Access-Control-Request-Method": "POST"},
    )
    assert ok_cors.headers.get("access-control-allow-origin") == "https://cityx.uz"

    bad_cors = client.options(
        "/api/miniapp/auth",
        headers={"Origin": "https://evil.example", "Access-Control-Request-Method": "POST"},
    )
    assert bad_cors.headers.get("access-control-allow-origin") is None


def test_http_dual_card_multipart_receipt_and_admin_rbac(client: TestClient) -> None:
    u_hdr = auth_headers(client, 100010, "http_buyer")
    a_hdr = auth_headers(client, 900001, "http_admin")

    res = client.post(
        "/api/payments/orders",
        headers=u_hdr,
        json={"package_id": "gems_100", "payment_method_code": "uzum_visa", "idempotency_key": "http_pay_1"},
    )
    assert res.status_code == 201
    oid = res.json()["order"]["order_id"]

    # Reject arbitrary extra receipt_url field (extra="forbid" -> 422)
    bad_sub = client.post(
        f"/api/payments/orders/{oid}/submit",
        headers=u_hdr,
        json={"submitted_reference": "REF-123", "receipt_url": "https://evil.example/a.png"},
    )
    assert bad_sub.status_code == 422

    # Valid PNG multipart upload succeeds; spoofed HTML upload fails with 400
    bad_up = client.post(
        f"/api/payments/orders/{oid}/receipt",
        headers=u_hdr,
        files={"file": ("fake.png", b"<html>xss</html>", "image/png")},
    )
    assert bad_up.status_code == 400

    ok_up = client.post(
        f"/api/payments/orders/{oid}/receipt",
        headers=u_hdr,
        files={"file": ("receipt.png", b"\x89PNG\r\n\x1a\n" + b"0" * 64, "image/png")},
    )
    assert ok_up.status_code == 200

    sub = client.post(
        f"/api/payments/orders/{oid}/submit",
        headers=u_hdr,
        json={"submitted_reference": "UZUM-REF-5566"},
    )
    assert sub.status_code == 200
    assert sub.json()["order"]["status"] == "pending_review"

    assert client.post(f"/api/admin/payments/{oid}/approve", headers=u_hdr).status_code == 403
    assert client.post(f"/api/admin/payments/{oid}/approve", headers=a_hdr).status_code == 200
    assert client.post(f"/api/admin/payments/{oid}/approve", headers=a_hdr).status_code == 409
