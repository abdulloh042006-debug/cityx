"""
FastAPI HTTP integration suite for Phase 0.3.1 + Phase 0.4.
Requires: `pip install -r apps/api/requirements.txt`
Run: `PYTHONPATH=. pytest -v tests/test_phase04_fastapi.py`
"""
from __future__ import annotations

import json
import pytest
from fastapi.testclient import TestClient

from apps.api.config import AppConfig
from apps.api.db.store import CityXStore
from apps.api.main import create_app

SYNTHETIC_VISA = "4000000000001111"
SYNTHETIC_UZCARD = "5000000000002222"


@pytest.fixture()
def client(monkeypatch: pytest.MonkeyPatch, tmp_path) -> TestClient:
    monkeypatch.setenv("CITYX_ENV", "development")
    monkeypatch.setenv("PORT", "9124")
    monkeypatch.setenv("BOT_TOKEN", "123456:TEST_BOT_TOKEN")
    monkeypatch.setenv("CITYX_SIGNING_SECRET", "fastapi_p04_signing_secret_32_bytes_ok")
    monkeypatch.setenv("WEBHOOK_SECRET", "fastapi_p04_webhook_secret_32_bytes_ok")
    monkeypatch.setenv("CITYX_WEB_URL", "https://cityx.uz")
    monkeypatch.setenv("CITYX_ADMIN_TELEGRAM_IDS", "900001")
    monkeypatch.setenv("CITYX_RECEIPT_STORAGE_DIR", str(tmp_path / "receipts"))
    monkeypatch.setenv("CITYX_PAYMENT_VISA_ENABLED", "true")
    monkeypatch.setenv("CITYX_PAYMENT_VISA_BANK_NAME", "Uzum Bank")
    monkeypatch.setenv("CITYX_PAYMENT_VISA_CARD_NUMBER", SYNTHETIC_VISA)
    monkeypatch.setenv("CITYX_PAYMENT_VISA_RECIPIENT", "Abdullox Arslonov")
    monkeypatch.setenv("CITYX_PAYMENT_UZCARD_ENABLED", "true")
    monkeypatch.delenv("CITYX_PAYMENT_UZCARD_BANK_NAME", raising=False)
    monkeypatch.setenv("CITYX_PAYMENT_UZCARD_CARD_NUMBER", SYNTHETIC_UZCARD)
    monkeypatch.setenv("CITYX_PAYMENT_UZCARD_RECIPIENT", "Arslonov Abdulloh")

    cfg = AppConfig.from_env()
    store = CityXStore(database_url="", sqlite_path=str(tmp_path / "p04_api.sqlite3"))
    return TestClient(create_app(config=cfg, store=store))


def test_public_and_authenticated_phase04_endpoints(client: TestClient) -> None:
    assert client.get("/health").status_code == 200
    assert client.get("/api/city/overview").json()["overview"]["districts_count"] == 8
    assert len(client.get("/api/places").json()["places"]) == 15

    # Register + login + logout flow
    reg = client.post(
        "/api/auth/register",
        json={"username": "http_citizen", "password": "StrongPassword123!", "district_id": "downtown"},
    )
    assert reg.status_code == 201
    token = reg.json()["accessToken"]
    hdrs = {"Authorization": f"Bearer {token}"}

    # Verify payment order response NEVER leaks full synthetic card numbers
    ord_res = client.post(
        "/api/payments/orders",
        headers=hdrs,
        json={"package_id": "gems_100", "payment_method_code": "uzum_visa", "idempotency_key": "http_noleak_1"},
    )
    assert ord_res.status_code == 201
    raw_json = json.dumps(ord_res.json())
    assert SYNTHETIC_VISA not in raw_json
    assert "card_number" not in ord_res.json()["transfer_instructions"]

    # Non-admin blocked from /api/admin/overview
    assert client.get("/api/admin/overview", headers=hdrs).status_code == 403

    # Logout revokes session
    assert client.post("/api/auth/logout", headers=hdrs).status_code == 200
    assert client.get("/api/wallet", headers=hdrs).status_code == 401
