-- ============================================================================
-- CityX Migration 001 (UP): Phase 0.3 Unified Identity, Economy Ledger,
-- Dual-Card Manual Bank-Transfer Payments, Taxi Idempotency, Elections,
-- Telegram Persistence & Database-Enforced Append-Only Audit Integrity.
--
-- Prerequisites:
--   1. Existing 20-table base schema (db/schema.sql) applied or fresh PostgreSQL DB.
--   2. Take a pg_dump backup BEFORE applying to staging or production.
--   3. Do NOT execute directly against production without staging rehearsal.
-- ============================================================================

BEGIN;

-- Ensure base 20 tables exist if running on an empty PostgreSQL database
-- (Additive only: never drops or truncates existing tables/records)

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password_hash TEXT,
    auth_provider TEXT NOT NULL DEFAULT 'local',
    telegram_id TEXT UNIQUE,
    role TEXT NOT NULL DEFAULT 'user',
    is_banned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS districts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    description TEXT,
    total_points INTEGER NOT NULL DEFAULT 0
);

ALTER TABLE districts ADD COLUMN IF NOT EXISTS center_x INTEGER NOT NULL DEFAULT 0;
ALTER TABLE districts ADD COLUMN IF NOT EXISTS center_z INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS profiles (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name TEXT NOT NULL,
    instagram_handle TEXT,
    avatar_url TEXT,
    district_id TEXT NOT NULL DEFAULT 'residential',
    coins INTEGER NOT NULL DEFAULT 1000,
    gems INTEGER NOT NULL DEFAULT 10,
    reputation_score INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS level INTEGER NOT NULL DEFAULT 2;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS streak INTEGER NOT NULL DEFAULT 1;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_daily_claim TEXT NOT NULL DEFAULT '';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS classic_mode INTEGER NOT NULL DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS notify_prefs TEXT NOT NULL DEFAULT '{"properties":true,"quests":true,"social":true,"events":true,"garage":true,"district":true}';

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_users_role') THEN
        ALTER TABLE users ADD CONSTRAINT chk_users_role CHECK (role IN ('user', 'moderator', 'admin'));
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_profiles_coins_nonneg') THEN
        ALTER TABLE profiles ADD CONSTRAINT chk_profiles_coins_nonneg CHECK (coins >= 0);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_profiles_gems_nonneg') THEN
        ALTER TABLE profiles ADD CONSTRAINT chk_profiles_gems_nonneg CHECK (gems >= 0);
    END IF;
END $$;

-- Seed/backfill canonical 8 districts matching Master Prompt Section 3 grid
INSERT INTO districts (id, name, code, description, center_x, center_z) VALUES
    ('residential',   'Residential District',   'RES', 'Foydalanuvchilar uylari va mahallalar', -400,  400),
    ('university',    'University District',    'UNI', 'TATU, OzMU, Inha universitetlari',         0,  400),
    ('business',      'Business District',      'BIZ', 'Savdo markazlari va dokonlar',           400,  400),
    ('nature',        'Nature District',        'NAT', 'Yangi Ozbekiston bogi, kol va chinorlar',-400,   0),
    ('downtown',      'Downtown',               'DTW', 'Nest One va biznes osmonoparlari',         0,    0),
    ('entertainment', 'Entertainment District', 'ENT', 'Humo Arena, Magic City va oyin zali',    400,    0),
    ('transport',     'Transport District',     'TRN', 'Halqa yoli metrosi, vokzal va aeroport', -400, -400),
    ('vip',           'VIP District',           'VIP', 'Islom Sivilizatsiyasi Markazi va noyob binolar', 0, -400)
ON CONFLICT (id) DO UPDATE SET
    center_x = EXCLUDED.center_x,
    center_z = EXCLUDED.center_z;

-- Normalize any legacy free-text district values before FK enforcement
UPDATE profiles SET district_id = 'downtown'
WHERE district_id NOT IN (SELECT id FROM districts);

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_profiles_district') THEN
        ALTER TABLE profiles ADD CONSTRAINT fk_profiles_district FOREIGN KEY (district_id) REFERENCES districts(id);
    END IF;
END $$;

-- Preserve & extend vehicles for unified Web + Bot Garage
CREATE TABLE IF NOT EXISTS vehicles (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    model_code TEXT NOT NULL,
    color_hex TEXT NOT NULL DEFAULT '#0f172a',
    tuning_level INTEGER NOT NULL DEFAULT 1,
    is_equipped INTEGER NOT NULL DEFAULT 0
);
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT 'CityX Vehicle';
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS vehicle_class TEXT NOT NULL DEFAULT 'STANDARD';
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS rating INTEGER NOT NULL DEFAULT 500;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS upgrade_pct INTEGER NOT NULL DEFAULT 25;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS energy_pct INTEGER NOT NULL DEFAULT 100;

-- Preserve & extend events + RSVPs
CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL DEFAULT 'festival',
    starts_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ends_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'active'
);
ALTER TABLE events ADD COLUMN IF NOT EXISTS location TEXT NOT NULL DEFAULT 'Central Plaza 3D Arena';
ALTER TABLE events ADD COLUMN IF NOT EXISTS start_ts BIGINT NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS event_rsvps (
    event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at BIGINT NOT NULL,
    PRIMARY KEY (event_id, user_id)
);

-- Unified multi-provider identity linking (Web, Mini App, Telegram Bot)
CREATE TABLE IF NOT EXISTS user_identities (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL CHECK (provider IN ('telegram', 'google', 'web_email', 'local')),
    external_id TEXT NOT NULL,
    verified_at BIGINT NOT NULL,
    UNIQUE (provider, external_id)
);
CREATE INDEX IF NOT EXISTS idx_user_identities_user_id ON user_identities(user_id);

-- Backfill existing users.telegram_id into user_identities without losing records
INSERT INTO user_identities (user_id, provider, external_id, verified_at)
SELECT id, 'telegram', telegram_id, EXTRACT(EPOCH FROM NOW())::BIGINT
FROM users
WHERE telegram_id IS NOT NULL AND telegram_id <> ''
ON CONFLICT (provider, external_id) DO NOTHING;

-- Revocable JWT session registry
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_jti TEXT NOT NULL UNIQUE,
    expires_at BIGINT NOT NULL,
    revoked_at BIGINT,
    created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_exp ON sessions(user_id, expires_at);

-- Server-authoritative append-only virtual currency ledger
CREATE TABLE IF NOT EXISTS economy_ledger (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    currency TEXT NOT NULL CHECK (currency IN ('coins', 'gems')),
    delta BIGINT NOT NULL CHECK (delta <> 0),
    balance_after BIGINT NOT NULL CHECK (balance_after >= 0),
    reason TEXT NOT NULL,
    ref_type TEXT NOT NULL DEFAULT '',
    ref_id TEXT NOT NULL DEFAULT '',
    idempotency_key TEXT NOT NULL UNIQUE,
    prev_hash CHAR(64) NOT NULL,
    entry_hash CHAR(64) NOT NULL,
    created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_economy_ledger_user_created ON economy_ledger(user_id, created_at DESC);

-- Server-defined UZS virtual currency packages (client cannot forge price/reward)
CREATE TABLE IF NOT EXISTS payment_packages (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    reward_currency TEXT NOT NULL CHECK (reward_currency IN ('coins', 'gems')),
    reward_amount INTEGER NOT NULL CHECK (reward_amount > 0),
    price_uzs BIGINT NOT NULL CHECK (price_uzs > 0),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

INSERT INTO payment_packages (id, title, reward_currency, reward_amount, price_uzs, is_active) VALUES
    ('gems_100',    '100 CityX Gems',     'gems',   100,  25000, TRUE),
    ('gems_500',    '500 CityX Gems',     'gems',   500, 115000, TRUE),
    ('coins_10000', '10,000 CityX Coins', 'coins', 10000, 20000, TRUE)
ON CONFLICT (id) DO NOTHING;

-- Dual-card manual bank-transfer orders (NO raw card numbers stored in DB)
CREATE TABLE IF NOT EXISTS payment_orders (
    order_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    package_id TEXT NOT NULL REFERENCES payment_packages(id),
    payment_method_code TEXT NOT NULL CHECK (payment_method_code IN ('uzum_visa', 'uzcard')),
    payment_network_snapshot TEXT NOT NULL,
    payment_bank_snapshot TEXT,
    recipient_name_snapshot TEXT NOT NULL,
    card_last4_snapshot CHAR(4) NOT NULL,
    card_fingerprint_hmac CHAR(64) NOT NULL,
    expected_amount_uzs BIGINT NOT NULL CHECK (expected_amount_uzs > 0),
    reward_currency TEXT NOT NULL CHECK (reward_currency IN ('coins', 'gems')),
    reward_amount INTEGER NOT NULL CHECK (reward_amount > 0),
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'pending_review', 'approved', 'rejected', 'cancelled')),
    submitted_reference TEXT NOT NULL DEFAULT '',
    receipt_object_key TEXT NOT NULL DEFAULT '',
    receipt_mime_type TEXT NOT NULL DEFAULT '',
    receipt_sha256 TEXT NOT NULL DEFAULT '',
    receipt_size_bytes INTEGER NOT NULL DEFAULT 0
        CHECK (receipt_size_bytes >= 0 AND receipt_size_bytes <= 5242880),
    submitted_at BIGINT,
    reviewed_by_admin_id TEXT REFERENCES users(id),
    reviewed_at BIGINT,
    rejection_reason TEXT NOT NULL DEFAULT '',
    credited_ledger_id TEXT UNIQUE REFERENCES economy_ledger(id),
    idempotency_key TEXT NOT NULL,
    created_at BIGINT NOT NULL,
    updated_at BIGINT NOT NULL,
    CONSTRAINT uq_payment_orders_user_idem UNIQUE (user_id, idempotency_key),
    CONSTRAINT chk_payment_no_self_approve CHECK (
        reviewed_by_admin_id IS NULL OR reviewed_by_admin_id <> user_id
    )
);
CREATE INDEX IF NOT EXISTS idx_payment_orders_review
    ON payment_orders(status, payment_method_code, submitted_at);

-- Tamper-evident append-only payment audit trail
CREATE TABLE IF NOT EXISTS payment_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES payment_orders(order_id),
    actor_user_id TEXT NOT NULL REFERENCES users(id),
    event_type TEXT NOT NULL,
    details_json TEXT NOT NULL,
    prev_hash CHAR(64) NOT NULL,
    entry_hash CHAR(64) NOT NULL,
    created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payment_audit_order ON payment_audit_logs(order_id, id);

-- Preserve & harden admin_audit_logs from db/schema.sql
CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id TEXT PRIMARY KEY,
    admin_user_id TEXT NOT NULL REFERENCES users(id),
    action TEXT NOT NULL,
    target_entity TEXT NOT NULL,
    details_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS target_type TEXT NOT NULL DEFAULT '';
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS before_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS after_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS reason TEXT NOT NULL DEFAULT '';
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS prev_hash CHAR(64) NOT NULL DEFAULT repeat('0', 64);
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS entry_hash CHAR(64) NOT NULL DEFAULT '';
ALTER TABLE admin_audit_logs ADD COLUMN IF NOT EXISTS created_ts BIGINT NOT NULL DEFAULT 0;

-- Replay-safe Taxi idempotency table
CREATE TABLE IF NOT EXISTS taxi_rides (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    request_id TEXT NOT NULL,
    destination_district_id TEXT NOT NULL REFERENCES districts(id),
    district_name TEXT NOT NULL,
    fare_coins INTEGER NOT NULL CHECK (fare_coins > 0),
    eta_min INTEGER NOT NULL CHECK (eta_min > 0),
    balance_after BIGINT NOT NULL CHECK (balance_after >= 0),
    ledger_id TEXT NOT NULL UNIQUE REFERENCES economy_ledger(id),
    created_at BIGINT NOT NULL,
    CONSTRAINT uq_taxi_rides_user_req UNIQUE (user_id, request_id)
);

-- Elections with explicit non-deadlocking state machine
CREATE TABLE IF NOT EXISTS elections (
    election_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('draft', 'open', 'closed', 'published')),
    candidates_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS election_votes (
    election_id TEXT NOT NULL REFERENCES elections(election_id),
    user_id TEXT NOT NULL REFERENCES users(id),
    candidate_id TEXT NOT NULL,
    voted_at BIGINT NOT NULL,
    PRIMARY KEY (election_id, user_id)
);

-- District battle participants (FK to canonical districts)
CREATE TABLE IF NOT EXISTS district_participants (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    district_id TEXT NOT NULL REFERENCES districts(id),
    points BIGINT NOT NULL DEFAULT 0 CHECK (points >= 0)
);

-- Telegram bot persistent state tables (replaces ephemeral SQLite on Render)
CREATE TABLE IF NOT EXISTS telegram_user_topics (
    telegram_user_id BIGINT NOT NULL,
    topic_key TEXT NOT NULL,
    message_thread_id BIGINT NOT NULL,
    PRIMARY KEY (telegram_user_id, topic_key)
);

CREATE TABLE IF NOT EXISTS telegram_widget_instances (
    chat_id BIGINT NOT NULL,
    message_id BIGINT NOT NULL,
    widget_id TEXT NOT NULL,
    owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_id TEXT NOT NULL DEFAULT '',
    state_json TEXT NOT NULL DEFAULT '{}',
    updated_at BIGINT NOT NULL,
    PRIMARY KEY (chat_id, message_id)
);

CREATE TABLE IF NOT EXISTS moderation_logs (
    log_id BIGSERIAL PRIMARY KEY,
    chat_id BIGINT NOT NULL,
    target_telegram_id BIGINT NOT NULL,
    action TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
    idem_key TEXT PRIMARY KEY,
    created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_idempotency_keys_created ON idempotency_keys(created_at);

-- ============================================================================
-- DATABASE-ENFORCED APPEND-ONLY AUDIT & LEDGER PROTECTION
-- ============================================================================

CREATE OR REPLACE FUNCTION cityx_prevent_append_only_mutation()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Append-only integrity violation: table % cannot be updated or deleted', TG_TABLE_NAME
        USING ERRCODE = '55000';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_economy_ledger_no_mutate ON economy_ledger;
CREATE TRIGGER trg_economy_ledger_no_mutate
    BEFORE UPDATE OR DELETE ON economy_ledger
    FOR EACH ROW EXECUTE FUNCTION cityx_prevent_append_only_mutation();

DROP TRIGGER IF EXISTS trg_payment_audit_no_mutate ON payment_audit_logs;
CREATE TRIGGER trg_payment_audit_no_mutate
    BEFORE UPDATE OR DELETE ON payment_audit_logs
    FOR EACH ROW EXECUTE FUNCTION cityx_prevent_append_only_mutation();

DROP TRIGGER IF EXISTS trg_admin_audit_no_mutate ON admin_audit_logs;
CREATE TRIGGER trg_admin_audit_no_mutate
    BEFORE UPDATE OR DELETE ON admin_audit_logs
    FOR EACH ROW EXECUTE FUNCTION cityx_prevent_append_only_mutation();

-- Apply least-privilege grants automatically if a dedicated runtime role 'cityx_app' exists.
-- In production, run migrations as 'cityx_migrator' (table owner) and run FastAPI as 'cityx_app'.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cityx_app') THEN
        REVOKE UPDATE, DELETE, TRUNCATE ON economy_ledger, payment_audit_logs, admin_audit_logs FROM cityx_app;
        GRANT SELECT, INSERT ON economy_ledger, payment_audit_logs, admin_audit_logs TO cityx_app;
        GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO cityx_app;
    END IF;
END $$;

COMMIT;
