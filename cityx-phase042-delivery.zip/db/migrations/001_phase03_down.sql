-- ============================================================================
-- CityX Migration 001 (DOWN / ROLLBACK)
--
-- SAFETY WARNING:
--   1. NEVER run this rollback if real production manual payment orders or
--      audit records exist; instead roll back application code only or restore
--      from the pre-migration pg_dump backup.
--   2. This script removes ONLY objects newly added by 001_phase03_up.sql.
--      It does NOT drop any of the original 20 base tables from db/schema.sql.
-- ============================================================================

BEGIN;

-- 1. Remove append-only triggers and trigger function
DROP TRIGGER IF EXISTS trg_economy_ledger_no_mutate ON economy_ledger;
DROP TRIGGER IF EXISTS trg_payment_audit_no_mutate ON payment_audit_logs;
DROP TRIGGER IF EXISTS trg_admin_audit_no_mutate ON admin_audit_logs;
DROP FUNCTION IF EXISTS cityx_prevent_append_only_mutation();

-- 2. Drop newly added Phase 0.3 tables (reverse dependency order)
DROP TABLE IF EXISTS idempotency_keys;
DROP TABLE IF EXISTS moderation_logs;
DROP TABLE IF EXISTS telegram_widget_instances;
DROP TABLE IF EXISTS telegram_user_topics;
DROP TABLE IF EXISTS district_participants;
DROP TABLE IF EXISTS election_votes;
DROP TABLE IF EXISTS elections;
DROP TABLE IF EXISTS taxi_rides;
DROP TABLE IF EXISTS payment_audit_logs;
DROP TABLE IF EXISTS payment_orders;
DROP TABLE IF EXISTS payment_packages;
DROP TABLE IF EXISTS economy_ledger;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS user_identities;
DROP TABLE IF EXISTS event_rsvps;

-- 3. Drop newly added columns & constraints on preserved base tables
ALTER TABLE admin_audit_logs
    DROP COLUMN IF EXISTS target_type,
    DROP COLUMN IF EXISTS before_json,
    DROP COLUMN IF EXISTS after_json,
    DROP COLUMN IF EXISTS reason,
    DROP COLUMN IF EXISTS prev_hash,
    DROP COLUMN IF EXISTS entry_hash,
    DROP COLUMN IF EXISTS created_ts;

ALTER TABLE events
    DROP COLUMN IF EXISTS location,
    DROP COLUMN IF EXISTS start_ts;

ALTER TABLE vehicles
    DROP COLUMN IF EXISTS display_name,
    DROP COLUMN IF EXISTS vehicle_class,
    DROP COLUMN IF EXISTS rating,
    DROP COLUMN IF EXISTS upgrade_pct,
    DROP COLUMN IF EXISTS energy_pct;

ALTER TABLE profiles
    DROP CONSTRAINT IF EXISTS fk_profiles_district,
    DROP CONSTRAINT IF EXISTS chk_profiles_coins_nonneg,
    DROP CONSTRAINT IF EXISTS chk_profiles_gems_nonneg,
    DROP COLUMN IF EXISTS level,
    DROP COLUMN IF EXISTS streak,
    DROP COLUMN IF EXISTS last_daily_claim,
    DROP COLUMN IF EXISTS classic_mode,
    DROP COLUMN IF EXISTS notify_prefs;

ALTER TABLE districts
    DROP COLUMN IF EXISTS center_x,
    DROP COLUMN IF EXISTS center_z;

ALTER TABLE users
    DROP CONSTRAINT IF EXISTS chk_users_role;

COMMIT;
