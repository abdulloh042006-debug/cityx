-- ============================================================================
-- CityX Migration 002 (UP): Phase 0.3.1 Hardening + Phase 0.4 Frontend Support
-- Strictly additive migration built on top of db/schema.sql + 001_phase03_up.sql.
-- Never drops tables or discards existing records.
-- ============================================================================

BEGIN;

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS bio TEXT NOT NULL DEFAULT '';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS language TEXT NOT NULL DEFAULT 'uz';

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'chk_profiles_language') THEN
        ALTER TABLE profiles ADD CONSTRAINT chk_profiles_language CHECK (language IN ('uz', 'ru', 'en'));
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at BIGINT NOT NULL,
    used_at BIGINT,
    created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_password_reset_user_exp ON password_reset_tokens(user_id, expires_at);

CREATE TABLE IF NOT EXISTS city_places (
    id TEXT PRIMARY KEY,
    district_id TEXT NOT NULL REFERENCES districts(id),
    name TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('landmark', 'business', 'education', 'service', 'entertainment', 'nature', 'transport')),
    description TEXT NOT NULL DEFAULT '',
    address_label TEXT NOT NULL DEFAULT '',
    pos_x REAL NOT NULL DEFAULT 0,
    pos_z REAL NOT NULL DEFAULT 0,
    is_open BOOLEAN NOT NULL DEFAULT TRUE,
    created_at BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_city_places_district_cat ON city_places(district_id, category);

INSERT INTO city_places (id, district_id, name, category, description, address_label, pos_x, pos_z, is_open) VALUES
    ('plc_tvtower',   'downtown',      'Toshkent Teleminorasi',           'landmark',      '375 metrli markaziy kuzatuv minorasi va ramziy inshoot', 'Downtown, Markaziy aylanma',       0,    0, TRUE),
    ('plc_nestone',   'downtown',      'Nest One Biznes Markazi',         'business',      '51 qavatli zamonaviy osmonopar va ofis majmuasi',        'Downtown, Tashkent City',         38,  -38, TRUE),
    ('plc_tcmall',    'downtown',      'Tashkent City Mall',              'business',      'Savdo, ovqatlanish va dam olish majmuasi',               'Downtown, Markaziy xiyobon',     -28,   30, TRUE),
    ('plc_chorsu',    'business',      'Chorsu Bozori',                   'business',      'Firuza gumbazli tarixiy savdo markazi',                  'Business, Eski shahar qismi',    400,  400, TRUE),
    ('plc_humo',      'entertainment', 'Humo Arena',                      'entertainment', 'Konsert, sport va muz saroyi majmuasi',                  'Entertainment, Markaziy maydon', 400,    0, TRUE),
    ('plc_magiccity', 'entertainment', 'Magic City Parki',                'entertainment', 'Oilaviy madaniy va ko‘ngilochar hudud',                  'Entertainment, Janubiy qism',    440,   45, TRUE),
    ('plc_tatu',      'university',    'TATU Kampusi',                    'education',     'Axborot texnologiyalari universiteti va talabalar bog‘i','University, Shimoliy xiyobon',     0,  400, TRUE),
    ('plc_uzmu',      'university',    'O‘zMU Kampusi',                   'education',     'Milliy universitet o‘quv va ilmiy majmuasi',             'University, G‘arbiy qism',       -45,  420, TRUE),
    ('plc_inha',      'university',    'Inha Universiteti',               'education',     'Muhandislik va dasturiy ta’minot fakulteti',             'University, Sharqiy qism',        50,  420, TRUE),
    ('plc_lake',      'nature',        'Chinorlar Bog‘i va Sun’iy Ko‘l',  'nature',        'Piyodalar ko‘prigi, choyxona va dam olish maskani',      'Nature, G‘arbiy sohil',         -400,    0, TRUE),
    ('plc_minor',     'vip',           'Minor Masjidi',                   'landmark',      'Oq marmar va firuza gumbazli me’moriy ansambl',          'VIP, Anhor bo‘yi',               -38, -400, TRUE),
    ('plc_cic',       'vip',           'Islom Sivilizatsiyasi Markazi',   'landmark',      '65 metrli mozaika gumbazli madaniy markaz',              'VIP, Hazrati Imom hududi',         0, -400, TRUE),
    ('plc_metrohub',  'transport',     'Toshkent Yerusti Metro Bekati',   'transport',     '4 yo‘nalishli tezkor metro va avtobus tuguni',           'Transport, Halqa yo‘li',        -400, -400, TRUE),
    ('plc_taxihub',   'transport',     'CityX Taksi va Xizmat Markazi',   'service',       'Tumanlararo tezkor qatnov va shahar xizmatlari',         'Transport, Markaziy bekat',     -360, -370, TRUE),
    ('plc_mahalla',   'residential',   'Yangi Mahalla Fuqarolar Markazi', 'service',       'Uchastka ro‘yxatga olish va mahalla xizmatlari',         'Residential, A-02 hududi',      -400,  400, TRUE)
ON CONFLICT (id) DO NOTHING;

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cityx_app') THEN
        REVOKE UPDATE, DELETE, TRUNCATE ON economy_ledger, payment_audit_logs, admin_audit_logs FROM cityx_app;
        GRANT SELECT, INSERT ON economy_ledger, payment_audit_logs, admin_audit_logs TO cityx_app;
        GRANT SELECT, INSERT, UPDATE, DELETE ON password_reset_tokens, city_places TO cityx_app;
    END IF;
END $$;

COMMIT;
