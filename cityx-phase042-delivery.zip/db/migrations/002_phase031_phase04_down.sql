-- CityX Migration 002 (DOWN / ROLLBACK) — removes only Phase 0.4 additive objects.
BEGIN;
DROP TABLE IF EXISTS city_places;
DROP TABLE IF EXISTS password_reset_tokens;
ALTER TABLE profiles
    DROP CONSTRAINT IF EXISTS chk_profiles_language,
    DROP COLUMN IF EXISTS language,
    DROP COLUMN IF EXISTS bio;
COMMIT;
