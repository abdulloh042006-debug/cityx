-- ============================================================================
-- CityX SQLite Test Schema (Isolated Local / CI Testing ONLY)
-- Reconciles all 20 base tables from db/schema.sql + Phase 0.3 tables +
-- SQLite engine-level BEFORE UPDATE / BEFORE DELETE append-only triggers.
-- NEVER use SQLite for Render production deployment.
-- ============================================================================

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS districts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    description TEXT,
    total_points INTEGER NOT NULL DEFAULT 0 CHECK (total_points >= 0),
    center_x INTEGER NOT NULL DEFAULT 0,
    center_z INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password_hash TEXT,
    auth_provider TEXT NOT NULL DEFAULT 'local',
    telegram_id TEXT UNIQUE,
    role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'moderator', 'admin')),
    is_banned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS profiles (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name TEXT NOT NULL,
    instagram_handle TEXT,
    avatar_url TEXT,
    district_id TEXT NOT NULL DEFAULT 'residential' REFERENCES districts(id),
    coins INTEGER NOT NULL DEFAULT 1000 CHECK (coins >= 0),
    gems INTEGER NOT NULL DEFAULT 25 CHECK (gems >= 0),
    reputation_score INTEGER NOT NULL DEFAULT 0,
    bio TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT 'uz' CHECK (language IN ('uz', 'ru', 'en')),
    level INTEGER NOT NULL DEFAULT 2 CHECK (level >= 1),
    streak INTEGER NOT NULL DEFAULT 1 CHECK (streak >= 0),
    last_daily_claim TEXT NOT NULL DEFAULT '',
    classic_mode INTEGER NOT NULL DEFAULT 0,
    notify_prefs TEXT NOT NULL DEFAULT '{"properties":true,"quests":true,"social":true,"events":true,"garage":true,"district":true}',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS homes (
    id TEXT PRIMARY KEY,
    user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    district_id TEXT NOT NULL REFERENCES districts(id),
    plot_code TEXT UNIQUE NOT NULL,
    floors INTEGER NOT NULL DEFAULT 2 CHECK (floors >= 1 AND floors <= 50),
    architecture_style TEXT NOT NULL DEFAULT 'uzbek_villa',
    facade_color TEXT NOT NULL DEFAULT '#f8fafc',
    has_pool INTEGER NOT NULL DEFAULT 0,
    has_fence INTEGER NOT NULL DEFAULT 1,
    has_garage INTEGER NOT NULL DEFAULT 1,
    has_helipad INTEGER NOT NULL DEFAULT 0,
    pet_type TEXT NOT NULL DEFAULT 'none',
    active_vehicle_id TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS city_objects (
    id TEXT PRIMARY KEY,
    district_id TEXT NOT NULL REFERENCES districts(id),
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT,
    is_unique INTEGER NOT NULL DEFAULT 1,
    base_price_coins INTEGER NOT NULL,
    current_price_coins INTEGER NOT NULL,
    pos_x REAL NOT NULL,
    pos_y REAL NOT NULL DEFAULT 0,
    pos_z REAL NOT NULL,
    version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS ownerships (
    id TEXT PRIMARY KEY,
    object_id TEXT UNIQUE NOT NULL REFERENCES city_objects(id) ON DELETE CASCADE,
    owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    acquired_price_coins INTEGER NOT NULL,
    acquired_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_type TEXT NOT NULL,
    item_code TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    acquired_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    model_code TEXT NOT NULL,
    color_hex TEXT NOT NULL DEFAULT '#0f172a',
    tuning_level INTEGER NOT NULL DEFAULT 1,
    is_equipped INTEGER NOT NULL DEFAULT 0,
    display_name TEXT NOT NULL DEFAULT 'CityX Vehicle',
    vehicle_class TEXT NOT NULL DEFAULT 'STANDARD',
    rating INTEGER NOT NULL DEFAULT 500,
    upgrade_pct INTEGER NOT NULL DEFAULT 25 CHECK (upgrade_pct >= 0 AND upgrade_pct <= 100),
    energy_pct INTEGER NOT NULL DEFAULT 100 CHECK (energy_pct >= 0 AND energy_pct <= 100)
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL,
    currency TEXT NOT NULL,
    amount INTEGER NOT NULL,
    status TEXT NOT NULL,
    external_ref TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS referrals (
    id TEXT PRIMARY KEY,
    referrer_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ip_hash TEXT,
    reward_granted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (referrer_user_id != referred_user_id)
);

CREATE TABLE IF NOT EXISTS likes (
    id TEXT PRIMARY KEY,
    from_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_home_id TEXT NOT NULL REFERENCES homes(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (from_user_id, target_home_id)
);

CREATE TABLE IF NOT EXISTS friendships (
    id TEXT PRIMARY KEY,
    user_a TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_b TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_a, user_b)
);

CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL DEFAULT 'festival',
    starts_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ends_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'active',
    location TEXT NOT NULL DEFAULT 'Central Plaza 3D Arena',
    start_ts INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS event_rsvps (
    event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at INTEGER NOT NULL,
    PRIMARY KEY (event_id, user_id)
);

CREATE TABLE IF NOT EXISTS votes (
    id TEXT PRIMARY KEY,
    election_cycle TEXT NOT NULL,
    voter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    candidate_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (election_cycle, voter_user_id)
);

CREATE TABLE IF NOT EXISTS fireworks (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    pos_x REAL NOT NULL DEFAULT 0,
    pos_z REAL NOT NULL DEFAULT 0,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS games (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    max_score_per_sec REAL NOT NULL DEFAULT 25.0
);

CREATE TABLE IF NOT EXISTS game_scores (
    id TEXT PRIMARY KEY,
    game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    duration_sec REAL NOT NULL,
    coins_awarded INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    reporter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_identities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL CHECK (provider IN ('telegram', 'google', 'web_email', 'local')),
    external_id TEXT NOT NULL,
    verified_at INTEGER NOT NULL,
    UNIQUE (provider, external_id)
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_jti TEXT NOT NULL UNIQUE,
    expires_at INTEGER NOT NULL,
    revoked_at INTEGER,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS economy_ledger (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    currency TEXT NOT NULL CHECK (currency IN ('coins', 'gems')),
    delta INTEGER NOT NULL CHECK (delta <> 0),
    balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
    reason TEXT NOT NULL,
    ref_type TEXT NOT NULL DEFAULT '',
    ref_id TEXT NOT NULL DEFAULT '',
    idempotency_key TEXT NOT NULL UNIQUE,
    prev_hash TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS payment_packages (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    reward_currency TEXT NOT NULL CHECK (reward_currency IN ('coins', 'gems')),
    reward_amount INTEGER NOT NULL CHECK (reward_amount > 0),
    price_uzs INTEGER NOT NULL CHECK (price_uzs > 0),
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS payment_orders (
    order_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    package_id TEXT NOT NULL REFERENCES payment_packages(id),
    payment_method_code TEXT NOT NULL CHECK (payment_method_code IN ('uzum_visa', 'uzcard')),
    payment_network_snapshot TEXT NOT NULL,
    payment_bank_snapshot TEXT,
    recipient_name_snapshot TEXT NOT NULL,
    card_last4_snapshot TEXT NOT NULL,
    card_fingerprint_hmac TEXT NOT NULL,
    expected_amount_uzs INTEGER NOT NULL CHECK (expected_amount_uzs > 0),
    reward_currency TEXT NOT NULL CHECK (reward_currency IN ('coins', 'gems')),
    reward_amount INTEGER NOT NULL CHECK (reward_amount > 0),
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'pending_review', 'approved', 'rejected', 'cancelled')),
    submitted_reference TEXT NOT NULL DEFAULT '',
    receipt_object_key TEXT NOT NULL DEFAULT '',
    receipt_mime_type TEXT NOT NULL DEFAULT '',
    receipt_sha256 TEXT NOT NULL DEFAULT '',
    receipt_size_bytes INTEGER NOT NULL DEFAULT 0
        CHECK (receipt_size_bytes >= 0 AND receipt_size_bytes <= 5242880),
    submitted_at INTEGER,
    reviewed_by_admin_id TEXT REFERENCES users(id),
    reviewed_at INTEGER,
    rejection_reason TEXT NOT NULL DEFAULT '',
    credited_ledger_id TEXT UNIQUE REFERENCES economy_ledger(id),
    idempotency_key TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    UNIQUE (user_id, idempotency_key),
    CHECK (reviewed_by_admin_id IS NULL OR reviewed_by_admin_id <> user_id)
);

CREATE TABLE IF NOT EXISTS payment_audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL REFERENCES payment_orders(order_id),
    actor_user_id TEXT NOT NULL REFERENCES users(id),
    event_type TEXT NOT NULL,
    details_json TEXT NOT NULL,
    prev_hash TEXT NOT NULL,
    entry_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id TEXT PRIMARY KEY,
    admin_user_id TEXT NOT NULL REFERENCES users(id),
    action TEXT NOT NULL,
    target_entity TEXT NOT NULL,
    details_json TEXT,
    target_type TEXT NOT NULL DEFAULT '',
    before_json TEXT NOT NULL DEFAULT '{}',
    after_json TEXT NOT NULL DEFAULT '{}',
    reason TEXT NOT NULL DEFAULT '',
    prev_hash TEXT NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000',
    entry_hash TEXT NOT NULL DEFAULT '',
    created_ts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS taxi_rides (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    request_id TEXT NOT NULL,
    destination_district_id TEXT NOT NULL REFERENCES districts(id),
    district_name TEXT NOT NULL,
    fare_coins INTEGER NOT NULL CHECK (fare_coins > 0),
    eta_min INTEGER NOT NULL CHECK (eta_min > 0),
    balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
    ledger_id TEXT NOT NULL UNIQUE REFERENCES economy_ledger(id),
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, request_id)
);

CREATE TABLE IF NOT EXISTS elections (
    election_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('draft', 'open', 'closed', 'published')),
    candidates_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS election_votes (
    election_id TEXT NOT NULL REFERENCES elections(election_id),
    user_id TEXT NOT NULL REFERENCES users(id),
    candidate_id TEXT NOT NULL,
    voted_at INTEGER NOT NULL,
    PRIMARY KEY (election_id, user_id)
);

CREATE TABLE IF NOT EXISTS district_participants (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    district_id TEXT NOT NULL REFERENCES districts(id),
    points INTEGER NOT NULL DEFAULT 0 CHECK (points >= 0)
);

CREATE TABLE IF NOT EXISTS telegram_user_topics (
    telegram_user_id INTEGER NOT NULL,
    topic_key TEXT NOT NULL,
    message_thread_id INTEGER NOT NULL,
    PRIMARY KEY (telegram_user_id, topic_key)
);

CREATE TABLE IF NOT EXISTS telegram_widget_instances (
    chat_id INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    widget_id TEXT NOT NULL,
    owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_id TEXT NOT NULL DEFAULT '',
    state_json TEXT NOT NULL DEFAULT '{}',
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (chat_id, message_id)
);

CREATE TABLE IF NOT EXISTS moderation_logs (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    target_telegram_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
    idem_key TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL
);

-- SQLite Engine-Level Append-Only Triggers (mirrors PostgreSQL BEFORE UPDATE/DELETE triggers)
CREATE TRIGGER IF NOT EXISTS trg_economy_ledger_no_update
BEFORE UPDATE ON economy_ledger
BEGIN
    SELECT RAISE(ABORT, 'Append-only violation: economy_ledger cannot be updated');
END;

CREATE TRIGGER IF NOT EXISTS trg_economy_ledger_no_delete
BEFORE DELETE ON economy_ledger
BEGIN
    SELECT RAISE(ABORT, 'Append-only violation: economy_ledger cannot be deleted');
END;

CREATE TRIGGER IF NOT EXISTS trg_payment_audit_no_update
BEFORE UPDATE ON payment_audit_logs
BEGIN
    SELECT RAISE(ABORT, 'Append-only violation: payment_audit_logs cannot be updated');
END;

CREATE TRIGGER IF NOT EXISTS trg_payment_audit_no_delete
BEFORE DELETE ON payment_audit_logs
BEGIN
    SELECT RAISE(ABORT, 'Append-only violation: payment_audit_logs cannot be deleted');
END;

CREATE TRIGGER IF NOT EXISTS trg_admin_audit_no_update
BEFORE UPDATE ON admin_audit_logs
BEGIN
    SELECT RAISE(ABORT, 'Append-only violation: admin_audit_logs cannot be updated');
END;

CREATE TRIGGER IF NOT EXISTS trg_admin_audit_no_delete
BEFORE DELETE ON admin_audit_logs
BEGIN
    SELECT RAISE(ABORT, 'Append-only violation: admin_audit_logs cannot be deleted');
END;


CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    expires_at INTEGER NOT NULL,
    used_at INTEGER,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS city_places (
    id TEXT PRIMARY KEY,
    district_id TEXT NOT NULL REFERENCES districts(id),
    name TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('landmark', 'business', 'education', 'service', 'entertainment', 'nature', 'transport')),
    description TEXT NOT NULL DEFAULT '',
    address_label TEXT NOT NULL DEFAULT '',
    pos_x REAL NOT NULL DEFAULT 0,
    pos_z REAL NOT NULL DEFAULT 0,
    is_open INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL DEFAULT 0
);
