-- CityX 3D Social Metaverse Platform — 20-Table Relational Schema
-- Compatible with SQLite (local dev/tests) and PostgreSQL / Supabase (production)

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password_hash TEXT,
    auth_provider TEXT NOT NULL DEFAULT 'local', -- telegram | google | email | local
    telegram_id TEXT UNIQUE,
    role TEXT NOT NULL DEFAULT 'user', -- user | moderator | admin
    is_banned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS profiles (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name TEXT NOT NULL,
    instagram_handle TEXT, -- Public display handle only; NEVER store IG passwords
    avatar_url TEXT,
    district_id TEXT NOT NULL DEFAULT 'residential',
    coins INTEGER NOT NULL DEFAULT 1000,
    gems INTEGER NOT NULL DEFAULT 10,
    reputation_score INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS districts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    description TEXT,
    total_points INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS homes (
    id TEXT PRIMARY KEY,
    user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    district_id TEXT NOT NULL REFERENCES districts(id),
    plot_code TEXT UNIQUE NOT NULL,
    floors INTEGER NOT NULL DEFAULT 2 CHECK (floors >= 1 AND floors <= 50),
    architecture_style TEXT NOT NULL DEFAULT 'uzbek_villa',
    facade_color TEXT NOT NULL DEFAULT '#f8fafc',
    has_pool INTEGER NOT NULL DEFAULT 0,
    has_fence INTEGER NOT NULL DEFAULT 1,
    has_garage INTEGER NOT NULL DEFAULT 1,
    has_helipad INTEGER NOT NULL DEFAULT 0,
    pet_type TEXT NOT NULL DEFAULT 'none',
    active_vehicle_id TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS city_objects (
    id TEXT PRIMARY KEY,
    district_id TEXT NOT NULL REFERENCES districts(id),
    name TEXT NOT NULL,
    category TEXT NOT NULL, -- landmark | university | stadium | metro | commercial | decor
    description TEXT,
    is_unique INTEGER NOT NULL DEFAULT 1,
    base_price_coins INTEGER NOT NULL,
    current_price_coins INTEGER NOT NULL,
    pos_x REAL NOT NULL,
    pos_y REAL NOT NULL DEFAULT 0,
    pos_z REAL NOT NULL,
    version INTEGER NOT NULL DEFAULT 1 -- Optimistic concurrency lock
);

CREATE TABLE IF NOT EXISTS ownerships (
    id TEXT PRIMARY KEY,
    object_id TEXT UNIQUE NOT NULL REFERENCES city_objects(id) ON DELETE CASCADE,
    owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    acquired_price_coins INTEGER NOT NULL,
    acquired_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_type TEXT NOT NULL, -- decor | building | badge | powerup
    item_code TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    acquired_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    model_code TEXT NOT NULL, -- cobalt | malibu_xl | gelik_g63 | supercar | moto
    color_hex TEXT NOT NULL DEFAULT '#0f172a',
    tuning_level INTEGER NOT NULL DEFAULT 1,
    is_equipped INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL, -- internal_coins | telegram_stars | click | payme | uzum
    currency TEXT NOT NULL, -- COINS | GEMS | UZS | XTR
    amount INTEGER NOT NULL,
    status TEXT NOT NULL, -- pending | paid | failed | cancelled | refunded
    external_ref TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS referrals (
    id TEXT PRIMARY KEY,
    referrer_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ip_hash TEXT,
    reward_granted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (referrer_user_id != referred_user_id)
);

CREATE TABLE IF NOT EXISTS likes (
    id TEXT PRIMARY KEY,
    from_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_home_id TEXT NOT NULL REFERENCES homes(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (from_user_id, target_home_id)
);

CREATE TABLE IF NOT EXISTS friendships (
    id TEXT PRIMARY KEY,
    user_a TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_b TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending', -- pending | accepted | blocked
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_a, user_b)
);

CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL, -- fireworks | racing | architecture | festival
    starts_at TEXT NOT NULL,
    ends_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS votes (
    id TEXT PRIMARY KEY,
    election_cycle TEXT NOT NULL,
    voter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    candidate_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (election_cycle, voter_user_id)
);

CREATE TABLE IF NOT EXISTS fireworks (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    pos_x REAL NOT NULL DEFAULT 0,
    pos_z REAL NOT NULL DEFAULT 0,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS games (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL, -- snake | bounce | racing
    name TEXT NOT NULL,
    max_score_per_sec REAL NOT NULL DEFAULT 25.0
);

CREATE TABLE IF NOT EXISTS game_scores (
    id TEXT PRIMARY KEY,
    game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    duration_sec REAL NOT NULL,
    coins_awarded INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    reporter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id TEXT PRIMARY KEY,
    admin_user_id TEXT NOT NULL REFERENCES users(id),
    action TEXT NOT NULL,
    target_entity TEXT NOT NULL,
    details_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
