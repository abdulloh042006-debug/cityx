"""
CityX Legacy Backend Compatibility Bridge (Phase 0.3.1 Hardened)
Preserves CityXService public gameplay/auth/RBAC methods backed by the unified
CityXStore and CityXDomainService.
All automated payment handlers (Click, Payme, Uzum, Telegram Stars, TON) have
been permanently removed; no callable legacy payment webhook methods remain.
"""
from __future__ import annotations

import os
import uuid
from typing import Any, Dict, Tuple

from apps.api.auth.tokens import AuthSecurity
from apps.api.config import AppConfig, ManualCardConfig
from apps.api.db.store import CityXStore, is_unique_violation
from apps.api.domain.services import CityXDomainService, DomainError


class CityXService:
    def __init__(self, db_path: str = ":memory:", secret_key: str | None = None) -> None:
        self.db_path = db_path
        secret = secret_key or os.environ.get("CITYX_JWT_SECRET") or "dev-only-change-in-prod-32bytes"
        if len(secret) < 16:
            secret = secret.ljust(16, "_")

        cfg = AppConfig(
            environment="development",
            port=8080,
            host="127.0.0.1",
            database_url="",
            sqlite_path=db_path,
            bot_token="legacy-bridge-token",
            bot_username="cityx_bot",
            miniapp_short_name="app",
            web_base_url="https://cityx.uz",
            cors_origins=("https://cityx.uz",),
            signing_secret=secret,
            webhook_url="",
            webhook_secret="",
            admin_telegram_ids=(),
            receipt_storage_dir="",
            manual_payment_support_handle="@cityx_bot",
            smtp_configured=False,
            manual_cards={
                "uzum_visa": ManualCardConfig(
                    code="uzum_visa",
                    display_name="Uzum Bank — Visa",
                    network="Visa",
                    bank_name="Uzum Bank",
                    card_number="4000000000000001",
                    recipient_name="Abdullox Arslonov",
                    enabled=False,
                ),
                "uzcard": ManualCardConfig(
                    code="uzcard",
                    display_name="Uzcard",
                    network="Uzcard",
                    bank_name=None,
                    card_number="5000000000000002",
                    recipient_name="Arslonov Abdulloh",
                    enabled=False,
                ),
            },
            ton_wallet_enabled=False,
        )
        self.store = CityXStore(database_url="", sqlite_path=db_path)
        self.conn = self.store._sqlite_conn
        self.security = AuthSecurity(bot_token=cfg.bot_token, signing_secret=secret)
        self.domain = CityXDomainService(config=cfg, store=self.store)

    def create_token(self, user_id: str, role: str) -> str:
        token, jti, exp = self.security.issue_jwt(user_id, role, ttl_seconds=3600)
        self.domain.create_session(user_id, jti, exp)
        return token

    def verify_token(self, token: str):
        try:
            claims = self.security.verify_jwt(token)
            user = self.domain.get_active_user_for_token(claims["sub"], claims["jti"])
            return claims if user else None
        except ValueError:
            return None

    def register_user(
        self,
        username: str,
        password: str,
        instagram_handle: str = "",
        district_id: str = "residential",
        role: str = "user",
    ) -> Tuple[int, Dict[str, Any]]:
        try:
            res = self.domain.register_local_user(
                username=username,
                password=password,
                instagram_handle=instagram_handle,
                district_id=district_id,
                role=role,
            )
            uid = res["user"]["id"]
            token = self.create_token(uid, role)
            return 201, {
                "user_id": uid,
                "username": res["user"]["username"],
                "home_id": res["home_id"],
                "plot_code": res["plot_code"],
                "token": token,
            }
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}

    def update_home(self, user_id: str, floors: int, has_pool: bool = False, has_helipad: bool = False):
        try:
            return 200, self.domain.update_home(user_id, floors, has_pool, has_helipad)
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}

    def acquire_object(self, user_id: str, object_id: str, expected_version: int):
        try:
            return 200, self.domain.acquire_object(user_id, object_id, expected_version)
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}

    def claim_referral(self, referrer_id: str, referred_id: str, ip_hash: str = ""):
        try:
            return 200, self.domain.claim_referral(referrer_id, referred_id, ip_hash)
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}

    def submit_game_score(self, user_id: str, game_code: str, score: int, duration_sec: float):
        try:
            return 200, self.domain.submit_game_score(user_id, game_code, score, duration_sec)
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}

    def cast_vote(self, voter_id: str, candidate_id: str, cycle: str = "2026-11"):
        try:
            with self.store.transaction() as tx:
                tx.execute(
                    "INSERT INTO votes (id, election_cycle, voter_user_id, candidate_user_id) VALUES (?, ?, ?, ?)",
                    (f"vot_{uuid.uuid4().hex[:10]}", cycle, voter_id, candidate_id),
                )
            return 200, {"status": "vote_recorded", "cycle": cycle}
        except Exception as exc:
            if is_unique_violation(exc):
                return 409, {"error": "User has already voted in this election cycle"}
            return 500, {"error": str(exc)}

    def launch_firework(self, user_id: str, message: str):
        try:
            return 201, self.domain.launch_firework(user_id, message)
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}

    def admin_ban_user(self, actor_token: str, target_user_id: str, reason: str):
        claims = self.verify_token(actor_token)
        if not claims or claims.get("role") != "admin":
            return 403, {"error": "Admin role required (verified server-side)"}
        try:
            return 200, self.domain.admin_ban_user(claims["sub"], target_user_id, reason)
        except DomainError as exc:
            return exc.status_code, {"error": str(exc)}
